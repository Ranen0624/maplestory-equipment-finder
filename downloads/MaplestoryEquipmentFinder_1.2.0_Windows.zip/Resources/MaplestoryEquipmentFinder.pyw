# -*- coding: utf-8 -*-
"""
MapleStory Equipment Finder GUI v3
Robust long-run version:
- Adaptive rate limiting / Retry-After support
- Automatic checkpoint
- Resume interrupted scans
- Avoid rescanning completed candidates
- Results/errors saved incrementally
- No third-party packages required
"""

import csv
import hashlib
import json
import os
import queue
import re
import threading
import time
from collections import Counter
from datetime import datetime, timedelta, timezone
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.parse import urlencode
from urllib.request import Request, urlopen

import tkinter as tk
from tkinter import ttk, filedialog, messagebox

BASE = "https://open.api.nexon.com/maplestory/v1"
KST = timezone(timedelta(hours=9))

JOB_GROUPS = {
    "전사": [
        "히어로", "팔라딘", "다크나이트",
        "소울마스터", "미하일", "아란",
        "블래스터", "데몬슬레이어", "데몬어벤져",
        "카이저", "제로", "아델", "렌",
    ],
    "마법사": [
        "아크메이지(불,독)", "아크메이지(썬,콜)", "비숍",
        "플레임위자드", "에반", "루미너스", "배틀메이지",
        "키네시스", "일리움", "라라", "레테",
    ],
    "궁수": [
        "보우마스터", "신궁", "패스파인더",
        "윈드브레이커", "메르세데스", "와일드헌터", "카인",
    ],
    "도적": [
        "나이트로드", "섀도어", "듀얼블레이더",
        "나이트워커", "팬텀", "카데나", "호영", "칼리",
    ],
    "해적": [
        "바이퍼", "캡틴", "캐논마스터",
        "스트라이커", "은월", "메카닉", "엔젤릭버스터", "아크",
    ],
    "도적/해적": ["제논"],
}
JOB_API_FILTER = {
    "히어로": "전사-히어로",
    "팔라딘": "전사-팔라딘",
    "다크나이트": "전사-다크나이트",

    "아크메이지(불,독)": "마법사-아크메이지(불독)",
    "아크메이지(썬,콜)": "마법사-아크메이지(썬콜)",
    "비숍": "마법사-비숍",

    "보우마스터": "궁수-보우마스터",
    "신궁": "궁수-신궁",
    "패스파인더": "궁수-패스파인더",

    "나이트로드": "도적-나이트로드",
    "섀도어": "도적-섀도어",
    "듀얼블레이더": "도적-듀얼블레이더",

    "바이퍼": "해적-바이퍼",
    "캡틴": "해적-캡틴",
    "캐논마스터": "해적-캐논마스터",

    "소울마스터": "기사단-소울마스터",
    "플레임위자드": "기사단-플레임위자드",
    "윈드브레이커": "기사단-윈드브레이커",
    "나이트워커": "기사단-나이트워커",
    "스트라이커": "기사단-스트라이커",
    "미하일": "기사단-미하일",

    "아란": "아란-전체 전직",
    "에반": "에반-전체 전직",
    "메르세데스": "메르세데스-전체 전직",
    "팬텀": "팬텀-전체 전직",
    "루미너스": "루미너스-전체 전직",
    "은월": "은월-전체 전직",

    "배틀메이지": "레지스탕스-배틀메이지",
    "와일드헌터": "레지스탕스-와일드헌터",
    "메카닉": "레지스탕스-메카닉",
    "데몬슬레이어": "레지스탕스-데몬슬레이어",
    "데몬어벤져": "레지스탕스-데몬어벤져",
    "제논": "레지스탕스-제논",
    "블래스터": "레지스탕스-블래스터",

    "카이저": "카이저-전체 전직",
    "엔젤릭버스터": "엔젤릭버스터-전체 전직",
    "카데나": "카데나-전체 전직",
    "카인": "카인-전체 전직",

    "제로": "초월자-제로",
    "키네시스": "프렌즈 월드-키네시스",

    "일리움": "일리움-전체 전직",
    "아크": "아크-전체 전직",
    "아델": "아델-전체 전직",
    "칼리": "칼리-전체 전직",

    "호영": "호영-전체 전직",
    "라라": "라라-전체 전직",
    "렌": "렌-전체 전직",

    "레테": "레테-전체 전직",
}

EQUIP_LIST_KEYS = [
    ("현재 장비", "item_equipment"),
    ("프리셋 1", "item_equipment_preset_1"),
    ("프리셋 2", "item_equipment_preset_2"),
    ("프리셋 3", "item_equipment_preset_3"),
]
GRADES = ["무관", "레어", "에픽", "유니크", "레전드리"]


def yesterday_kst():
    return (datetime.now(KST).date() - timedelta(days=1)).isoformat()


def clean_text(s):
    return (s or "").strip()


def normalize_option(text):
    s = clean_text(text)
    if not s:
        return ""
    s = re.sub(r"\s+", "", s).replace("+", "").replace(":", "").replace(",", "").replace("％", "%")
    aliases = [
        (r"^마(\d+)%?$", r"마력\1%"),
        (r"^공(\d+)%?$", r"공격력\1%"),
        (r"^보공(\d+)%?$", r"보스몬스터공격시데미지\1%"),
        (r"^방무(\d+)%?$", r"몬스터방어율무시\1%"),
        (r"^올스탯(\d+)%?$", r"올스탯\1%"),
        (r"^올(\d+)%?$", r"올스탯\1%"),
        (r"^힘(\d+)%?$", r"STR\1%"),
        (r"^덱(\d+)%?$", r"DEX\1%"),
        (r"^인(\d+)%?$", r"INT\1%"),
        (r"^럭(\d+)%?$", r"LUK\1%"),
    ]
    for pat, repl in aliases:
        if re.match(pat, s, flags=re.I):
            s = re.sub(pat, repl, s, flags=re.I)
            break
    s = s.replace("보공", "보스몬스터공격시데미지").replace("방무", "몬스터방어율무시")
    return s.upper()


def options_match(actual_lines, wanted_lines):
    wanted = [normalize_option(x) for x in wanted_lines if clean_text(x)]
    if not wanted:
        return True
    actual = [normalize_option(x) for x in actual_lines if clean_text(x)]
    ca, cw = Counter(actual), Counter(wanted)
    return all(ca[k] >= v for k, v in cw.items())


def item_name_match(actual, wanted, mode):
    wanted = clean_text(wanted)
    if not wanted:
        return True
    actual = clean_text(actual)
    return wanted in actual if mode == "이름 포함" else actual == wanted


def safe_filename(s):
    s = re.sub(r'[\\/:*?"<>|]+', "_", s)
    s = re.sub(r"\s+", "_", s.strip())
    return s[:100] or "result"


def atomic_write_json(path, obj):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    with tmp.open("w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=2)
    os.replace(tmp, path)


def search_fingerprint(cfg):
    # Never include API key in a checkpoint ID.
    fields = {
        k: cfg[k] for k in (
            "date","min_level","max_level","job_group","job","world_types",
            "include_presets","item_name","item_name_mode","starforce",
            "potential_grade","potential_lines","additional_grade","additional_lines",
            "max_pages",
        )
    }
    raw = json.dumps(fields, ensure_ascii=False, sort_keys=True).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()[:16]



class EquipmentCatalog:
    """Local equipment-name catalog used for autocomplete."""
    def __init__(self, bundled_path, user_path):
        self.bundled_path = Path(bundled_path)
        self.user_path = Path(user_path)
        self._lock = threading.Lock()
        self.items = set()
        self._load_file(self.bundled_path)
        self._load_file(self.user_path)

    def _extract_items(self, data):
        if isinstance(data, list):
            return [str(x).strip() for x in data if str(x).strip()]
        if isinstance(data, dict):
            if isinstance(data.get("items"), list):
                return [str(x).strip() for x in data["items"] if str(x).strip()]
        return []

    def _load_file(self, path):
        if not path.exists():
            return
        try:
            if path.suffix.lower() == ".json":
                data = json.loads(path.read_text(encoding="utf-8"))
                values = self._extract_items(data)
            else:
                values = [
                    line.strip()
                    for line in path.read_text(encoding="utf-8-sig").splitlines()
                    if line.strip()
                ]
            self.items.update(values)
        except Exception:
            pass

    @staticmethod
    def _norm(value):
        return re.sub(r"\s+", "", str(value or "")).casefold()

    def suggest(self, query, limit=30):
        query = str(query or "").strip()
        if not query:
            return []
        nq = self._norm(query)
        with self._lock:
            values = list(self.items)

        def score(name):
            nn = self._norm(name)
            if nn == nq:
                rank = 0
            elif nn.startswith(nq):
                rank = 1
            elif any(self._norm(part).startswith(nq) for part in name.split()):
                rank = 2
            elif nq in nn:
                rank = 3
            else:
                rank = 99
            return (rank, len(name), name)

        matched = [x for x in values if nq in self._norm(x)]
        matched.sort(key=score)
        return matched[:limit]

    def learn_many(self, names):
        clean = {
            str(name).strip()
            for name in (names or [])
            if name and str(name).strip()
        }
        if not clean:
            return 0

        changed = 0
        with self._lock:
            before = len(self.items)
            self.items.update(clean)
            changed = len(self.items) - before
            if changed:
                self.user_path.parent.mkdir(parents=True, exist_ok=True)
                payload = {
                    "updated_at": datetime.now().isoformat(timespec="seconds"),
                    "items": sorted(self.items),
                }
                tmp = self.user_path.with_suffix(".tmp")
                tmp.write_text(
                    json.dumps(payload, ensure_ascii=False, indent=2),
                    encoding="utf-8",
                )
                os.replace(tmp, self.user_path)
        return changed

    def import_file(self, path):
        path = Path(path)
        if not path.exists():
            return 0
        try:
            if path.suffix.lower() == ".json":
                data = json.loads(path.read_text(encoding="utf-8"))
                names = self._extract_items(data)
            else:
                names = [
                    line.strip()
                    for line in path.read_text(encoding="utf-8-sig").splitlines()
                    if line.strip()
                ]
        except Exception as e:
            raise ValueError(f"장비 목록 파일을 읽을 수 없습니다: {e}")
        return self.learn_many(names)

    def learn_from_cache(self, cache_dir):
        """Learn item_name values from existing cached item-equipment responses."""
        cache_dir = Path(cache_dir)
        if not cache_dir.exists():
            return 0
        found = set()

        def walk(obj):
            if isinstance(obj, dict):
                value = obj.get("item_name")
                if value:
                    found.add(str(value).strip())
                for child in obj.values():
                    walk(child)
            elif isinstance(obj, list):
                for child in obj:
                    walk(child)

        for path in cache_dir.glob("*.json"):
            try:
                data = json.loads(path.read_text(encoding="utf-8"))
                if "item-equipment" not in str(data.get("url", "")):
                    continue
                walk(data.get("data"))
            except Exception:
                continue
        return self.learn_many(found)

    def __len__(self):
        with self._lock:
            return len(self.items)


class AutocompleteEntry(tk.Frame):
    def __init__(self, parent, variable, suggestion_func, on_select=None,
                 bg="#121925", max_rows=8):
        super().__init__(parent, bg=bg)
        self.variable = variable
        self.suggestion_func = suggestion_func
        self.on_select = on_select
        self.max_rows = max_rows
        self._trace_lock = False
        self.current = []

        self.entry = ttk.Entry(self, textvariable=variable)
        self.entry.pack(fill="x")

        self.listbox = tk.Listbox(
            self,
            height=1,
            bg="#0B111A",
            fg="#E6ECF5",
            selectbackground="#273650",
            selectforeground="#FFFFFF",
            borderwidth=1,
            relief="solid",
            highlightthickness=0,
            activestyle="none",
            font=("맑은 고딕", 9),
        )

        self.entry.bind("<KeyRelease>", self._on_keyrelease)
        self.entry.bind("<Down>", self._focus_list)
        self.entry.bind("<Escape>", lambda e: self.hide())
        self.entry.bind("<FocusOut>", self._delayed_hide)
        self.listbox.bind("<ButtonRelease-1>", self._choose_mouse)
        self.listbox.bind("<Return>", self._choose_keyboard)
        self.listbox.bind("<Escape>", lambda e: self.hide())
        self.listbox.bind("<FocusOut>", self._delayed_hide)

    def _on_keyrelease(self, event):
        if event.keysym in ("Up", "Down", "Return", "Escape", "Tab"):
            return
        self.refresh()

    def refresh(self):
        query = self.variable.get().strip()
        if not query:
            self.hide()
            return
        values = self.suggestion_func(query)
        if not values:
            self.hide()
            return

        self.current = values
        self.listbox.delete(0, "end")
        for value in values:
            self.listbox.insert("end", value)
        self.listbox.configure(height=min(self.max_rows, len(values)))
        if not self.listbox.winfo_ismapped():
            self.listbox.pack(fill="x", pady=(4, 0))

    def hide(self):
        if self.listbox.winfo_ismapped():
            self.listbox.pack_forget()

    def _focus_list(self, event=None):
        if not self.listbox.winfo_ismapped():
            self.refresh()
        if self.listbox.winfo_ismapped() and self.listbox.size():
            self.listbox.focus_set()
            self.listbox.selection_clear(0, "end")
            self.listbox.selection_set(0)
            self.listbox.activate(0)
            return "break"

    def _choose_index(self, index):
        if index < 0 or index >= len(self.current):
            return
        value = self.current[index]
        self.variable.set(value)
        self.hide()
        self.entry.icursor("end")
        self.entry.focus_set()
        if self.on_select:
            self.on_select(value)

    def _choose_mouse(self, event):
        sel = self.listbox.curselection()
        if sel:
            self._choose_index(sel[0])

    def _choose_keyboard(self, event):
        sel = self.listbox.curselection()
        if sel:
            self._choose_index(sel[0])
        return "break"

    def _delayed_hide(self, event=None):
        self.after(160, self._hide_if_unfocused)

    def _hide_if_unfocused(self):
        focus = self.focus_get()
        if focus not in (self.entry, self.listbox):
            self.hide()

class AdaptiveApiClient:
    """
    Long-run API client.

    429 policy:
    - 429 never becomes a fatal error by itself.
    - If Retry-After exists, respect it.
    - Otherwise use increasingly long cooldowns.
    - User can always stop from the GUI.

    Cache policy:
    - /id responses: persistent cache (OCID mapping is reused).
    - Responses with a past 'date' parameter: persistent cache.
    - Current-day/no-date game data is not persistently cached.
    """
    def __init__(
        self,
        api_key,
        cancel_event,
        log_cb=None,
        base_interval=0.75,
        cache_dir=None,
        cooldown_cb=None,
    ):
        self.api_key = api_key
        self.cancel_event = cancel_event
        self.log_cb = log_cb or (lambda x: None)
        self.cooldown_cb = cooldown_cb or (lambda seconds: None)

        self.base_interval = max(0.25, float(base_interval))
        self.current_interval = self.base_interval
        self.max_interval = 5.0
        self._last_request_time = 0.0
        self.success_streak = 0
        self.total_429 = 0
        self.consecutive_429 = 0

        self.cache_dir = Path(cache_dir) if cache_dir else None
        if self.cache_dir:
            self.cache_dir.mkdir(parents=True, exist_ok=True)
        self.cache_hits = 0
        self.cache_writes = 0

    def check_cancel(self):
        if self.cancel_event.is_set():
            raise InterruptedError("사용자가 검색을 중지했습니다.")

    def _pace(self):
        self.check_cancel()
        now = time.monotonic()
        wait = self.current_interval - (now - self._last_request_time)
        if wait > 0:
            self._sleep_cancelable(wait)
        self._last_request_time = time.monotonic()

    def _sleep_cancelable(self, seconds):
        seconds = max(0.0, float(seconds))
        end = time.monotonic() + seconds
        last_report = None

        while True:
            self.check_cancel()
            remaining = end - time.monotonic()
            if remaining <= 0:
                self.cooldown_cb(0)
                return

            shown = int(remaining + 0.999)
            if shown != last_report:
                self.cooldown_cb(shown)
                last_report = shown

            time.sleep(min(1.0, remaining))

    def _on_success(self):
        was_limited = self.consecutive_429 > 0
        self.consecutive_429 = 0
        self.success_streak += 1

        if was_limited:
            self.log_cb("API 제한 해제 확인. 검색을 자동 재개합니다.")

        # After a long stable streak, gently return toward user's base interval.
        if self.success_streak >= 40 and self.current_interval > self.base_interval:
            old = self.current_interval
            self.current_interval = max(
                self.base_interval,
                self.current_interval * 0.90,
            )
            self.success_streak = 0
            if old - self.current_interval >= 0.10:
                self.log_cb(
                    f"API 호출 간격 완화: {old:.2f}초 → "
                    f"{self.current_interval:.2f}초"
                )

    def _cooldown_seconds(self, retry_after):
        if retry_after is not None:
            return max(1.0, float(retry_after))

        # Conservative schedule when Nexon does not provide a reset time.
        schedule = [10, 30, 60, 120, 300, 600, 900]
        idx = min(max(self.consecutive_429 - 1, 0), len(schedule) - 1)
        return float(schedule[idx])

    def _cacheable(self, path, params):
        if not self.cache_dir:
            return False

        # Character name -> OCID is especially useful to keep.
        if path == "id":
            return True

        params = params or {}
        date = params.get("date")
        if not date:
            return False

        try:
            requested = datetime.strptime(str(date), "%Y-%m-%d").date()
            return requested < datetime.now(KST).date()
        except Exception:
            return False

    def _cache_path(self, url):
        digest = hashlib.sha256(url.encode("utf-8")).hexdigest()
        return self.cache_dir / f"{digest}.json"

    def _read_cache(self, path, params, url):
        if not self._cacheable(path, params):
            return None
        p = self._cache_path(url)
        if not p.exists():
            return None
        try:
            with p.open("r", encoding="utf-8") as f:
                wrapper = json.load(f)
            if wrapper.get("url") != url:
                return None
            self.cache_hits += 1
            return wrapper.get("data")
        except Exception:
            return None

    def _write_cache(self, path, params, url, data):
        if not self._cacheable(path, params):
            return
        p = self._cache_path(url)
        tmp = p.with_suffix(".tmp")
        wrapper = {
            "saved_at": datetime.now().isoformat(timespec="seconds"),
            "url": url,
            "data": data,
        }
        try:
            with tmp.open("w", encoding="utf-8") as f:
                json.dump(wrapper, f, ensure_ascii=False)
            os.replace(tmp, p)
            self.cache_writes += 1
        except Exception:
            try:
                if tmp.exists():
                    tmp.unlink()
            except Exception:
                pass

    def get_json(self, path, params=None, retries=8):
        url = f"{BASE}/{path}"
        if params:
            url += "?" + urlencode(params)

        cached = self._read_cache(path, params, url)
        if cached is not None:
            return cached

        other_error_attempt = 0
        transient_delay = 1.0

        while True:
            self.check_cancel()
            self._pace()

            req = Request(
                url,
                headers={
                    "accept": "application/json",
                    "x-nxopen-api-key": self.api_key,
                    "User-Agent": "MapleEquipmentFinderGUI/4.0",
                },
                method="GET",
            )

            try:
                with urlopen(req, timeout=30) as resp:
                    data = json.loads(resp.read().decode("utf-8"))
                    self._on_success()
                    self._write_cache(path, params, url, data)
                    return data

            except HTTPError as e:
                body = ""
                try:
                    body = e.read().decode("utf-8", "replace")
                except Exception:
                    pass

                if e.code == 429:
                    self.total_429 += 1
                    self.consecutive_429 += 1
                    self.success_streak = 0

                    # Once 429 appears, also slow normal requests after recovery.
                    old_interval = self.current_interval
                    self.current_interval = min(
                        self.max_interval,
                        max(
                            self.current_interval * 1.35,
                            self.base_interval + 0.5,
                        ),
                    )

                    retry_after = None
                    header = e.headers.get("Retry-After")
                    if header:
                        try:
                            retry_after = float(header)
                        except ValueError:
                            retry_after = None

                    wait = self._cooldown_seconds(retry_after)

                    if self.consecutive_429 == 1:
                        self.log_cb(
                            "API 호출량 제한(429) 감지. "
                            "요청을 멈추고 쿨다운합니다."
                        )
                    elif self.consecutive_429 == 3:
                        self.log_cb(
                            "429가 계속되어 장기 쿨다운 모드로 전환합니다. "
                            "프로그램은 종료하지 않고 제한 해제까지 기다립니다."
                        )

                    source = (
                        "Retry-After"
                        if retry_after is not None
                        else "자동 쿨다운"
                    )
                    self.log_cb(
                        f"429 연속 {self.consecutive_429}회 / "
                        f"{source} {wait:.0f}초 / "
                        f"호출 간격 {old_interval:.2f}→"
                        f"{self.current_interval:.2f}초"
                    )
                    self._sleep_cancelable(wait)
                    # IMPORTANT: 429 does not consume the normal retry count.
                    continue

                # A successful non-429 response will reset this later.
                if 500 <= e.code < 600 or "OPENAPI00009" in body:
                    other_error_attempt += 1
                    if other_error_attempt < retries:
                        self.log_cb(
                            f"API 임시 오류 HTTP {e.code}: "
                            f"{transient_delay:.1f}초 후 재시도"
                        )
                        self._sleep_cancelable(transient_delay)
                        transient_delay = min(transient_delay * 2, 30)
                        continue

                raise RuntimeError(
                    f"HTTP {e.code}\nURL: {url}\n응답: {body[:1000]}"
                ) from e

            except URLError as e:
                other_error_attempt += 1
                if other_error_attempt < retries:
                    self.log_cb(
                        f"네트워크 오류: {transient_delay:.1f}초 후 재시도"
                    )
                    self._sleep_cancelable(transient_delay)
                    transient_delay = min(transient_delay * 2, 30)
                    continue
                raise RuntimeError(f"네트워크 오류: {e}") from e

def iter_items(equipment_json, include_presets):
    keys = EQUIP_LIST_KEYS if include_presets else EQUIP_LIST_KEYS[:1]
    for label, key in keys:
        for item in equipment_json.get(key) or []:
            yield label, item


def item_matches(item, cfg):
    if not item_name_match(item.get("item_name"), cfg["item_name"], cfg["item_name_mode"]):
        return False

    if cfg["starforce"]:
        try:
            if int(item.get("starforce") or 0) != int(cfg["starforce"]):
                return False
        except ValueError:
            return False

    if cfg["potential_grade"] != "무관":
        if clean_text(item.get("potential_option_grade")) != cfg["potential_grade"]:
            return False

    if not options_match(
        [item.get("potential_option_1"), item.get("potential_option_2"), item.get("potential_option_3")],
        cfg["potential_lines"],
    ):
        return False

    if cfg["additional_grade"] != "무관":
        if clean_text(item.get("additional_potential_option_grade")) != cfg["additional_grade"]:
            return False

    if not options_match(
        [item.get("additional_potential_option_1"), item.get("additional_potential_option_2"), item.get("additional_potential_option_3")],
        cfg["additional_lines"],
    ):
        return False
    return True


def make_result_row(candidate, source, item):
    return {
        "닉네임": candidate.get("character_name", ""),
        "월드": candidate.get("world_name", ""),
        "레벨": candidate.get("level", ""),
        "직업": candidate.get("class_name", ""),
        "길드": candidate.get("guild_name", ""),
        "랭킹": candidate.get("ranking", ""),
        "장비출처": source,
        "장비명": item.get("item_name", ""),
        "부위": item.get("item_equipment_slot", "") or item.get("item_equipment_part", ""),
        "스타포스": item.get("starforce", ""),
        "잠재등급": item.get("potential_option_grade", ""),
        "잠재1": item.get("potential_option_1", ""),
        "잠재2": item.get("potential_option_2", ""),
        "잠재3": item.get("potential_option_3", ""),
        "에디등급": item.get("additional_potential_option_grade", ""),
        "에디1": item.get("additional_potential_option_1", ""),
        "에디2": item.get("additional_potential_option_2", ""),
        "에디3": item.get("additional_potential_option_3", ""),
    }


class Checkpoint:
    def __init__(self, app_dir, cfg):
        self.cfg = cfg
        self.fp = search_fingerprint(cfg)
        self.dir = Path(app_dir) / "checkpoints"
        self.path = self.dir / f"{self.fp}.json"
        self.results_csv = self.dir / f"{self.fp}_results.csv"
        self.errors_txt = self.dir / f"{self.fp}_errors.txt"
        self.data = {
            "version": 3,
            "fingerprint": self.fp,
            "created_at": datetime.now().isoformat(timespec="seconds"),
            "updated_at": datetime.now().isoformat(timespec="seconds"),
            "config": {k:v for k,v in cfg.items() if k != "api_key"},
            "phase": "new",
            "candidates": [],
            "completed": {},   # key -> status
            "results": [],
            "errors": [],
        }

    def exists(self):
        return self.path.exists()

    def load(self):
        with self.path.open("r", encoding="utf-8") as f:
            self.data = json.load(f)
        return self.data

    def save(self):
        self.data["updated_at"] = datetime.now().isoformat(timespec="seconds")
        atomic_write_json(self.path, self.data)
        self._write_results_csv()
        self._write_errors()

    def _write_results_csv(self):
        rows = self.data.get("results") or []
        self.results_csv.parent.mkdir(parents=True, exist_ok=True)
        fields = [
            "닉네임","월드","레벨","직업","길드","랭킹","장비출처","장비명","부위",
            "스타포스","잠재등급","잠재1","잠재2","잠재3",
            "에디등급","에디1","에디2","에디3"
        ]
        with self.results_csv.open("w", encoding="utf-8-sig", newline="") as f:
            w = csv.DictWriter(f, fieldnames=fields)
            w.writeheader()
            for row in rows:
                w.writerow({k: row.get(k, "") for k in fields})

    def _write_errors(self):
        self.errors_txt.parent.mkdir(parents=True, exist_ok=True)
        with self.errors_txt.open("w", encoding="utf-8") as f:
            for e in self.data.get("errors") or []:
                f.write(f"{e.get('character_name','')}\t{e.get('message','')}\n")

    @staticmethod
    def ckey(c):
        return f"{c.get('world_name','')}|{c.get('character_name','')}"

    def mark_completed(self, candidate, status, error=None):
        key = self.ckey(candidate)
        self.data["completed"][key] = {
            "status": status,
            "at": datetime.now().isoformat(timespec="seconds"),
        }
        if error:
            self.data["errors"].append({
                "character_name": candidate.get("character_name", ""),
                "world_name": candidate.get("world_name", ""),
                "message": error,
            })

    def is_completed(self, candidate):
        return self.ckey(candidate) in self.data.get("completed", {})


def collect_candidates(client, cfg, log_cb, progress_cb):
    selected_job = cfg["job"]
    api_filter = JOB_API_FILTER.get(selected_job) if selected_job != "전체" else None
    candidates = []
    seen = set()

    def run_pages(world_type, class_filter):
        rows_out = []
        for page in range(1, cfg["max_pages"] + 1):
            client.check_cancel()
            params = {"date": cfg["date"], "world_type": world_type, "page": page}
            if class_filter:
                params["class"] = class_filter

            try:
                data = client.get_json("ranking/overall", params)
            except RuntimeError as e:
                msg = str(e)
                if page == 1 and class_filter and ("HTTP 400" in msg or "OPENAPI00004" in msg):
                    raise ValueError("CLASS_FILTER_INVALID") from e
                if page > 1 and "HTTP 400" in msg:
                    log_cb(f"  page {page}: 더 이상 조회할 페이지가 없어 종료")
                    break
                raise

            ranking = data.get("ranking") or []
            if not ranking:
                break

            levels = []
            kept = 0
            for r in ranking:
                try:
                    lv = int(r.get("character_level", -1))
                except Exception:
                    continue
                levels.append(lv)

                if selected_job != "전체":
                    rank_class = clean_text(r.get("class_name"))
                    rank_sub = clean_text(r.get("sub_class_name"))
                    if selected_job not in (rank_class, rank_sub):
                        continue

                if cfg["min_level"] <= lv <= cfg["max_level"]:
                    key = (r.get("character_name"), r.get("world_name"))
                    if key in seen:
                        continue
                    seen.add(key)
                    rows_out.append({
                        "character_name": r.get("character_name", ""),
                        "world_name": r.get("world_name", ""),
                        "level": lv,
                        "class_name": clean_text(r.get("sub_class_name")) or clean_text(r.get("class_name")),
                        "guild_name": r.get("character_guildname") or "",
                        "ranking": r.get("ranking", ""),
                        "world_type": world_type,
                    })
                    kept += 1

            hi = max(levels) if levels else "?"
            lo = min(levels) if levels else "?"
            log_cb(f"  page {page}: Lv.{hi}~{lo} / 후보 +{kept}")
            progress_cb("rank", page, cfg["max_pages"])

            if levels and min(levels) < cfg["min_level"]:
                break

        return rows_out

    for world_type in cfg["world_types"]:
        label = "일반 월드" if world_type == 0 else "에오스/핼리오스"
        log_cb(f"\n[랭킹 수집] {label}")
        log_cb(f"직업 API 필터: {api_filter or '없음'}")
        try:
            candidates.extend(run_pages(world_type, api_filter))
        except ValueError as e:
            if str(e) != "CLASS_FILTER_INVALID":
                raise
            log_cb("[주의] 직업 API 필터가 거부되어 직업 필터 없이 조회 후 재필터링합니다.")
            candidates.extend(run_pages(world_type, None))

    candidates.sort(key=lambda x: (-x["level"], x["world_name"], x["character_name"]))
    return candidates


def scan_candidates(client, cfg, checkpoint, log_cb, progress_cb, result_cb, catalog_cb=None):
    candidates = checkpoint.data["candidates"]
    total = len(candidates)
    completed_before = sum(1 for c in candidates if checkpoint.is_completed(c))
    if completed_before:
        log_cb(f"이어하기: 이미 완료된 {completed_before}명은 건너뜁니다.")

    dirty = 0
    for idx, cand in enumerate(candidates, 1):
        client.check_cancel()

        if checkpoint.is_completed(cand):
            progress_cb("scan", idx, total)
            continue

        name = cand["character_name"]
        progress_cb("scan", idx, total)
        log_cb(f"[{idx}/{total}] {name} / {cand['world_name']} / Lv.{cand['level']}")

        try:
            ocid_data = client.get_json("id", {"character_name": name})
            ocid = ocid_data.get("ocid")
            if not ocid:
                checkpoint.mark_completed(cand, "no_ocid")
                log_cb("  - OCID 없음")
                dirty += 1
                continue

            equip = client.get_json("character/item-equipment", {"ocid": ocid, "date": cfg["date"]})

            # Every fetched equipment name becomes future autocomplete data.
            if catalog_cb:
                try:
                    catalog_cb([
                        item.get("item_name")
                        for _, item in iter_items(equip, True)
                        if item.get("item_name")
                    ])
                except Exception:
                    pass

            matched_here = 0
            dedupe = set()
            for source, item in iter_items(equip, cfg["include_presets"]):
                if not item_matches(item, cfg):
                    continue
                key = (
                    item.get("item_name"), item.get("starforce"), item.get("potential_option_grade"),
                    item.get("potential_option_1"), item.get("potential_option_2"), item.get("potential_option_3"),
                    item.get("additional_potential_option_grade"),
                    item.get("additional_potential_option_1"), item.get("additional_potential_option_2"),
                    item.get("additional_potential_option_3"),
                )
                if key in dedupe:
                    continue
                dedupe.add(key)

                row = make_result_row(cand, source, item)
                checkpoint.data["results"].append(row)
                result_cb(row)
                matched_here += 1

            checkpoint.mark_completed(cand, "matched" if matched_here else "no_match")
            log_cb(f"  >>> 일치 {matched_here}건" if matched_here else "  -")
            dirty += 1

        except InterruptedError:
            raise
        except Exception as e:
            msg = str(e).splitlines()[0][:400]
            checkpoint.mark_completed(cand, "error", error=msg)
            log_cb(f"  [조회 오류] {msg}")
            dirty += 1

        # Save frequently; at most ~3 characters of work are lost on power-off/crash.
        if dirty >= 3:
            checkpoint.data["phase"] = "scanning"
            checkpoint.save()
            dirty = 0

    checkpoint.data["phase"] = "done"
    checkpoint.save()
    return checkpoint.data["results"]


class App(tk.Tk):
    # Palette
    BG = "#0B0F16"
    PANEL = "#121925"
    PANEL_2 = "#172131"
    PANEL_3 = "#0F1621"
    BORDER = "#263247"
    TEXT = "#F4F7FB"
    MUTED = "#9EABBE"
    ACCENT = "#FFB74D"
    ACCENT_DARK = "#D99125"
    BLUE = "#7EA5FF"
    GREEN = "#68D69A"
    DANGER = "#FF7F8A"

    def __init__(self):
        super().__init__()
        self.title("메이플스토리 장비 찾기")
        self.geometry("1360x900")
        self.minsize(1120, 760)
        self.configure(bg=self.BG)

        script_dir = Path(__file__).resolve().parent
        self.app_dir = script_dir.parent if script_dir.name.lower() == "resources" else script_dir

        self.catalog = EquipmentCatalog(
            self.app_dir / "Resources" / "equipment_catalog.json",
            self.app_dir / "data" / "equipment_catalog_user.json",
        )
        try:
            self.catalog.learn_from_cache(self.app_dir / "api_cache")
        except Exception:
            pass

        # Window/taskbar icon
        try:
            icon_file = self.app_dir / "Resources" / "app_icon.png"
            self.window_icon = tk.PhotoImage(file=str(icon_file))
            self.iconphoto(True, self.window_icon)
        except Exception:
            self.window_icon = None
        self.event_q = queue.Queue()
        self.cancel_event = threading.Event()
        self.worker = None
        self.results = []
        self.last_cfg = None

        self._make_vars()
        self._configure_styles()
        self._build_ui()
        self._load_defaults()
        self.after(100, self._poll_events)

    def _make_vars(self):
        self.api_key_var = tk.StringVar()
        self.show_key_var = tk.BooleanVar(value=False)
        self.date_var = tk.StringVar(value=yesterday_kst())
        self.min_level_var = tk.StringVar(value="295")
        self.max_level_var = tk.StringVar(value="295")
        self.job_group_var = tk.StringVar(value="마법사")
        self.job_var = tk.StringVar(value="비숍")
        self.world_normal_var = tk.BooleanVar(value=True)
        self.world_reboot_var = tk.BooleanVar(value=True)
        self.include_presets_var = tk.BooleanVar(value=True)

        self.item_name_var = tk.StringVar(value="")
        self.item_name_mode_var = tk.StringVar(value="정확히 일치")
        self.starforce_var = tk.StringVar(value="")
        self.pot_grade_var = tk.StringVar(value="무관")
        self.pot_vars = [tk.StringVar() for _ in range(3)]
        self.add_grade_var = tk.StringVar(value="무관")
        self.add_vars = [tk.StringVar() for _ in range(3)]

        self.base_interval_var = tk.StringVar(value="0.75")
        self.max_pages_var = tk.StringVar(value="300")
        self.status_var = tk.StringVar(value="검색 준비 완료")
        self.count_var = tk.StringVar(value="0")
        self.progress_var = tk.DoubleVar(value=0.0)

    def _configure_styles(self):
        style = ttk.Style(self)
        try:
            style.theme_use("clam")
        except Exception:
            pass

        style.configure(".", font=("맑은 고딕", 9))
        style.configure("App.TFrame", background=self.BG)
        style.configure("Sidebar.TFrame", background="#0D131D")
        style.configure("Card.TFrame", background=self.PANEL, relief="flat")
        style.configure("Card2.TFrame", background=self.PANEL_2, relief="flat")
        style.configure("Toolbar.TFrame", background=self.PANEL_3)

        style.configure("TLabel", background=self.BG, foreground=self.TEXT)
        style.configure("Title.TLabel", background=self.BG, foreground=self.TEXT,
                        font=("맑은 고딕", 22, "bold"))
        style.configure("Sub.TLabel", background=self.BG, foreground=self.MUTED,
                        font=("맑은 고딕", 9))
        style.configure("CardTitle.TLabel", background=self.PANEL, foreground=self.TEXT,
                        font=("맑은 고딕", 11, "bold"))
        style.configure("CardText.TLabel", background=self.PANEL, foreground=self.MUTED)
        style.configure("SidebarTitle.TLabel", background="#0D131D", foreground=self.TEXT,
                        font=("맑은 고딕", 13, "bold"))
        style.configure("SidebarText.TLabel", background="#0D131D", foreground=self.MUTED)
        style.configure("Metric.TLabel", background=self.PANEL_2, foreground=self.TEXT,
                        font=("맑은 고딕", 18, "bold"))
        style.configure("MetricLabel.TLabel", background=self.PANEL_2, foreground=self.MUTED,
                        font=("맑은 고딕", 8))

        style.configure(
            "TEntry",
            fieldbackground="#0B111A",
            foreground=self.TEXT,
            insertcolor=self.TEXT,
            bordercolor=self.BORDER,
            lightcolor=self.BORDER,
            darkcolor=self.BORDER,
            padding=7,
        )
        style.configure(
            "TCombobox",
            fieldbackground="#0B111A",
            background="#0B111A",
            foreground=self.TEXT,
            arrowcolor=self.MUTED,
            bordercolor=self.BORDER,
            lightcolor=self.BORDER,
            darkcolor=self.BORDER,
            padding=6,
        )
        style.map(
            "TCombobox",
            fieldbackground=[("readonly", "#0B111A")],
            foreground=[("readonly", self.TEXT)],
            selectbackground=[("readonly", "#0B111A")],
            selectforeground=[("readonly", self.TEXT)],
        )

        style.configure("TCheckbutton", background=self.PANEL, foreground=self.TEXT)
        style.map("TCheckbutton", background=[("active", self.PANEL)])

        style.configure(
            "Accent.TButton",
            background=self.ACCENT,
            foreground="#271807",
            borderwidth=0,
            focusthickness=0,
            padding=(17, 10),
            font=("맑은 고딕", 10, "bold"),
        )
        style.map(
            "Accent.TButton",
            background=[("active", "#FFC66A"), ("disabled", "#6C604B")],
            foreground=[("disabled", "#C7BBA7")],
        )
        style.configure(
            "Ghost.TButton",
            background=self.PANEL_2,
            foreground=self.TEXT,
            bordercolor=self.BORDER,
            padding=(13, 9),
            font=("맑은 고딕", 9, "bold"),
        )
        style.map("Ghost.TButton", background=[("active", "#202B3D")])
        style.configure(
            "Danger.TButton",
            background="#3A1E27",
            foreground="#FFABB2",
            bordercolor="#63303A",
            padding=(13, 9),
            font=("맑은 고딕", 9, "bold"),
        )
        style.map("Danger.TButton", background=[("active", "#4A242E")])

        style.configure(
            "App.Horizontal.TProgressbar",
            troughcolor="#18202D",
            background=self.ACCENT,
            bordercolor="#18202D",
            lightcolor=self.ACCENT,
            darkcolor=self.ACCENT,
            thickness=8,
        )

        style.configure(
            "App.Treeview",
            background="#0E151F",
            fieldbackground="#0E151F",
            foreground="#DFE6F1",
            bordercolor=self.BORDER,
            rowheight=29,
            font=("맑은 고딕", 8),
        )
        style.map("App.Treeview", background=[("selected", "#273650")])
        style.configure(
            "App.Treeview.Heading",
            background="#182231",
            foreground="#C8D2E0",
            relief="flat",
            font=("맑은 고딕", 8, "bold"),
            padding=(7, 7),
        )
        style.map("App.Treeview.Heading", background=[("active", "#202D40")])

        style.configure("App.TNotebook", background=self.BG, borderwidth=0)
        style.configure(
            "App.TNotebook.Tab",
            background="#111925",
            foreground=self.MUTED,
            padding=(15, 8),
            font=("맑은 고딕", 9, "bold"),
        )
        style.map(
            "App.TNotebook.Tab",
            background=[("selected", self.PANEL_2), ("active", "#172131")],
            foreground=[("selected", self.TEXT), ("active", self.TEXT)],
        )

    def _card(self, parent, title, subtitle=None):
        outer = tk.Frame(parent, bg=self.PANEL, highlightthickness=1,
                         highlightbackground=self.BORDER, bd=0)
        header = tk.Frame(outer, bg=self.PANEL)
        header.pack(fill="x", padx=16, pady=(14, 8))
        tk.Label(header, text=title, bg=self.PANEL, fg=self.TEXT,
                 font=("맑은 고딕", 11, "bold")).pack(anchor="w")
        if subtitle:
            tk.Label(header, text=subtitle, bg=self.PANEL, fg=self.MUTED,
                     font=("맑은 고딕", 8)).pack(anchor="w", pady=(2, 0))
        body = tk.Frame(outer, bg=self.PANEL)
        body.pack(fill="both", expand=True, padx=16, pady=(0, 16))
        return outer, body

    def _field_label(self, parent, text, row, col, **kwargs):
        lbl = tk.Label(parent, text=text, bg=self.PANEL, fg=self.MUTED,
                       font=("맑은 고딕", 8, "bold"))
        lbl.grid(row=row, column=col, sticky="w", pady=(8, 3), **kwargs)
        return lbl

    def _build_ui(self):
        # Root grid
        self.grid_rowconfigure(0, weight=1)
        self.grid_columnconfigure(1, weight=1)

        # Sidebar
        sidebar = tk.Frame(self, bg="#0D131D", width=235)
        sidebar.grid(row=0, column=0, sticky="nsw")
        sidebar.grid_propagate(False)

        brand = tk.Frame(sidebar, bg="#0D131D")
        brand.pack(fill="x", padx=14, pady=(17, 18))
        try:
            brand_file = self.app_dir / "Resources" / "brand_logo_sidebar.png"
            self.brand_logo = tk.PhotoImage(file=str(brand_file))
            tk.Label(
                brand,
                image=self.brand_logo,
                bg="#0D131D",
                bd=0,
            ).pack(anchor="center")
        except Exception:
            tk.Label(
                brand,
                text="메이플스토리 장비 찾기",
                bg="#0D131D",
                fg=self.TEXT,
                font=("맑은 고딕", 11, "bold"),
            ).pack(anchor="center")

        tk.Label(sidebar, text="SEARCH", bg="#0D131D", fg="#65758D",
                 font=("맑은 고딕", 7, "bold")).pack(anchor="w", padx=20, pady=(0, 6))
        nav_search = tk.Label(
            sidebar, text="  ◉  장비 조건 검색", bg="#172131", fg=self.ACCENT,
            anchor="w", padx=12, pady=10, font=("맑은 고딕", 9, "bold")
        )
        nav_search.pack(fill="x", padx=12)

        tk.Label(sidebar, text="STATUS", bg="#0D131D", fg="#65758D",
                 font=("맑은 고딕", 7, "bold")).pack(anchor="w", padx=20, pady=(24, 6))

        side_info = tk.Frame(sidebar, bg="#0D131D")
        side_info.pack(fill="x", padx=20)
        tk.Label(side_info, text="API Key", bg="#0D131D", fg=self.MUTED,
                 font=("맑은 고딕", 8)).pack(anchor="w")
        tk.Label(side_info, text="로컬 메모리 사용", bg="#0D131D", fg=self.GREEN,
                 font=("맑은 고딕", 9, "bold")).pack(anchor="w", pady=(1, 12))
        tk.Label(side_info, text="검색 진행상황", bg="#0D131D", fg=self.MUTED,
                 font=("맑은 고딕", 8)).pack(anchor="w")
        self.side_status = tk.Label(side_info, textvariable=self.status_var,
                                    bg="#0D131D", fg=self.TEXT,
                                    wraplength=190, justify="left",
                                    font=("맑은 고딕", 9, "bold"))
        self.side_status.pack(anchor="w", pady=(1, 12))

        sidebar_bottom = tk.Frame(sidebar, bg="#0D131D")
        sidebar_bottom.pack(side="bottom", fill="x", padx=16, pady=18)
        tk.Label(
            sidebar_bottom,
            text="NEXON Open API 기반\n공개 장비 검색 도구",
            bg="#101823", fg=self.MUTED, justify="left",
            padx=12, pady=9, font=("맑은 고딕", 8)
        ).pack(fill="x")
        tk.Label(
            sidebar_bottom,
            text="Version 1.2.0",
            bg="#0D131D", fg="#5F6D82",
            font=("맑은 고딕", 7)
        ).pack(anchor="w", padx=4, pady=(6, 0))

        # Main
        main = tk.Frame(self, bg=self.BG)
        main.grid(row=0, column=1, sticky="nsew")
        main.grid_rowconfigure(2, weight=1)
        main.grid_columnconfigure(0, weight=1)

        # Header
        header = tk.Frame(main, bg=self.BG)
        header.grid(row=0, column=0, sticky="ew", padx=26, pady=(22, 12))
        title_wrap = tk.Frame(header, bg=self.BG)
        title_wrap.pack(side="left", fill="x", expand=True)
        tk.Label(title_wrap, text="메이플스토리 장비 찾기", bg=self.BG, fg=self.TEXT,
                 font=("맑은 고딕", 20, "bold")).pack(anchor="w")
        tk.Label(
            title_wrap,
            text="원하는 캐릭터와 장비 조건을 설정해 공개 장비 정보를 빠르게 찾아보세요.",
            bg=self.BG, fg=self.MUTED, font=("맑은 고딕", 9)
        ).pack(anchor="w", pady=(3, 0))

        self.start_btn = ttk.Button(header, text="검색 시작", style="Accent.TButton",
                                    command=self._start_search)
        self.start_btn.pack(side="right")
        self.cancel_btn = ttk.Button(header, text="중지", style="Danger.TButton",
                                     command=self._cancel_search, state="disabled")
        self.cancel_btn.pack(side="right", padx=(0, 8))

        # Metric cards
        metrics = tk.Frame(main, bg=self.BG)
        metrics.grid(row=1, column=0, sticky="ew", padx=26, pady=(0, 14))
        for c in range(4):
            metrics.grid_columnconfigure(c, weight=1)

        metric_data = [
            ("RESULTS", self.count_var, "일치 결과"),
            ("LEVEL", None, "검색 레벨"),
            ("JOB", None, "선택 직업"),
            ("MODE", None, "검색 방식"),
        ]
        self.metric_level = None
        self.metric_job = None
        self.metric_mode = None

        for i, (cap, var, sub) in enumerate(metric_data):
            card = tk.Frame(metrics, bg=self.PANEL_2, highlightthickness=1,
                            highlightbackground=self.BORDER)
            card.grid(row=0, column=i, sticky="ew", padx=(0 if i == 0 else 5, 0 if i == 3 else 5))
            tk.Label(card, text=cap, bg=self.PANEL_2, fg="#6D7C91",
                     font=("맑은 고딕", 7, "bold")).pack(anchor="w", padx=13, pady=(10, 2))
            if var is not None:
                value = tk.Label(card, textvariable=var, bg=self.PANEL_2, fg=self.TEXT,
                                 font=("맑은 고딕", 16, "bold"))
            else:
                value = tk.Label(card, text="-", bg=self.PANEL_2, fg=self.TEXT,
                                 font=("맑은 고딕", 13, "bold"))
            value.pack(anchor="w", padx=13)
            tk.Label(card, text=sub, bg=self.PANEL_2, fg=self.MUTED,
                     font=("맑은 고딕", 7)).pack(anchor="w", padx=13, pady=(0, 10))
            if cap == "LEVEL":
                self.metric_level = value
            elif cap == "JOB":
                self.metric_job = value
            elif cap == "MODE":
                self.metric_mode = value

        # Notebook
        self.notebook = ttk.Notebook(main, style="App.TNotebook")
        self.notebook.grid(row=2, column=0, sticky="nsew", padx=26, pady=(0, 10))

        search_tab = tk.Frame(self.notebook, bg=self.BG)
        result_tab = tk.Frame(self.notebook, bg=self.BG)
        log_tab = tk.Frame(self.notebook, bg=self.BG)
        self.notebook.add(search_tab, text="  검색 조건  ")
        self.notebook.add(result_tab, text="  결과  ")
        self.notebook.add(log_tab, text="  진행 로그  ")

        # Search tab scroll-like layout
        search_tab.grid_columnconfigure(0, weight=1)
        search_tab.grid_columnconfigure(1, weight=1)

        # Card: API / character
        card1, body1 = self._card(search_tab, "검색 대상", "캐릭터 범위와 직업을 먼저 지정합니다.")
        card1.grid(row=0, column=0, sticky="nsew", padx=(0, 7), pady=(10, 7))
        body1.grid_columnconfigure(1, weight=1)
        body1.grid_columnconfigure(3, weight=1)

        self._field_label(body1, "NEXON API Key", 0, 0)
        self.key_entry = ttk.Entry(body1, textvariable=self.api_key_var, show="●")
        self.key_entry.grid(row=1, column=0, columnspan=3, sticky="ew", padx=(0, 7))
        ttk.Checkbutton(body1, text="표시", variable=self.show_key_var,
                        command=self._toggle_key).grid(row=1, column=3, sticky="w")

        self._field_label(body1, "조회 날짜", 2, 0)
        ttk.Entry(body1, textvariable=self.date_var).grid(row=3, column=0, columnspan=2, sticky="ew", padx=(0, 7))
        self._field_label(body1, "레벨 범위", 2, 2)
        level_wrap = tk.Frame(body1, bg=self.PANEL)
        level_wrap.grid(row=3, column=2, columnspan=2, sticky="ew")
        level_wrap.grid_columnconfigure(0, weight=1)
        level_wrap.grid_columnconfigure(2, weight=1)
        ttk.Entry(level_wrap, textvariable=self.min_level_var, width=8).grid(row=0, column=0, sticky="ew")
        tk.Label(level_wrap, text="~", bg=self.PANEL, fg=self.MUTED).grid(row=0, column=1, padx=7)
        ttk.Entry(level_wrap, textvariable=self.max_level_var, width=8).grid(row=0, column=2, sticky="ew")

        self._field_label(body1, "직업 대분류", 4, 0)
        self._field_label(body1, "세부 직업", 4, 2)
        self.group_combo = ttk.Combobox(
            body1, textvariable=self.job_group_var,
            values=["전체"] + list(JOB_GROUPS.keys()), state="readonly"
        )
        self.group_combo.grid(row=5, column=0, columnspan=2, sticky="ew", padx=(0, 7))
        self.group_combo.bind("<<ComboboxSelected>>", self._on_group_changed)
        self.job_combo = ttk.Combobox(body1, textvariable=self.job_var, state="readonly")
        self.job_combo.grid(row=5, column=2, columnspan=2, sticky="ew")

        self._field_label(body1, "월드 유형", 6, 0)
        world_wrap = tk.Frame(body1, bg=self.PANEL)
        world_wrap.grid(row=7, column=0, columnspan=4, sticky="w")
        ttk.Checkbutton(world_wrap, text="일반 월드", variable=self.world_normal_var).pack(side="left")
        ttk.Checkbutton(world_wrap, text="에오스 / 핼리오스", variable=self.world_reboot_var).pack(side="left", padx=(12, 0))
        ttk.Checkbutton(world_wrap, text="프리셋 1~3 포함", variable=self.include_presets_var).pack(side="left", padx=(12, 0))

        # Card: equipment
        card2, body2 = self._card(search_tab, "장비 조건", "장비 이름과 강화 수치를 지정합니다.")
        card2.grid(row=0, column=1, sticky="nsew", padx=(7, 0), pady=(10, 7))
        body2.grid_columnconfigure(0, weight=1)
        body2.grid_columnconfigure(1, weight=1)

        self._field_label(body2, "장비명", 0, 0)
        self._field_label(body2, "일치 방식", 0, 1)
        self.item_autocomplete = AutocompleteEntry(
            body2,
            self.item_name_var,
            self._equipment_suggestions,
            on_select=self._equipment_selected,
            bg=self.PANEL,
            max_rows=8,
        )
        self.item_autocomplete.grid(row=1, column=0, sticky="ew", padx=(0, 7))
        ttk.Combobox(
            body2, textvariable=self.item_name_mode_var,
            values=["정확히 일치", "이름 포함"], state="readonly"
        ).grid(row=1, column=1, sticky="ew")

        self._field_label(body2, "스타포스", 2, 0)
        ttk.Entry(body2, textvariable=self.starforce_var).grid(row=3, column=0, sticky="ew", padx=(0, 7))
        tk.Label(body2, text="비우면 강화 수치는 무관으로 검색합니다.",
                 bg=self.PANEL, fg=self.MUTED, font=("맑은 고딕", 8)).grid(row=3, column=1, sticky="w")

        catalog_bar = tk.Frame(body2, bg=self.PANEL)
        catalog_bar.grid(row=4, column=0, columnspan=2, sticky="ew", pady=(12, 0))
        catalog_bar.grid_columnconfigure(0, weight=1)
        self.catalog_status_label = tk.Label(
            catalog_bar,
            text=f"장비 추천 데이터 {len(self.catalog):,}개 · 검색할수록 자동 추가",
            bg=self.PANEL,
            fg=self.MUTED,
            font=("맑은 고딕", 8),
        )
        self.catalog_status_label.grid(row=0, column=0, sticky="w")
        ttk.Button(
            catalog_bar,
            text="장비 목록 추가",
            style="Ghost.TButton",
            command=self._import_equipment_catalog,
        ).grid(row=0, column=1, sticky="e")

        # Potential card
        card3, body3 = self._card(search_tab, "잠재능력", "옵션 순서는 무관하며 빈 칸은 검색 조건에서 제외됩니다.")
        card3.grid(row=1, column=0, sticky="nsew", padx=(0, 7), pady=7)
        body3.grid_columnconfigure(0, weight=1)
        body3.grid_columnconfigure(1, weight=1)
        body3.grid_columnconfigure(2, weight=1)

        tk.Label(body3, text="등급", bg=self.PANEL, fg=self.MUTED,
                 font=("맑은 고딕", 8, "bold")).grid(row=0, column=0, sticky="w")
        ttk.Combobox(body3, textvariable=self.pot_grade_var, values=GRADES,
                     state="readonly").grid(row=1, column=0, sticky="ew", padx=(0, 7))
        tk.Label(body3, text="줄임 입력 가능: 마12 · 공12 · 보공30 · 방무40 · 올6",
                 bg=self.PANEL, fg=self.ACCENT, font=("맑은 고딕", 8, "bold")).grid(
                     row=1, column=1, columnspan=2, sticky="w"
                 )
        for i, var in enumerate(self.pot_vars):
            tk.Label(body3, text=f"옵션 {i+1}", bg=self.PANEL, fg=self.MUTED,
                     font=("맑은 고딕", 8, "bold")).grid(row=2, column=i, sticky="w", pady=(10, 3))
            ttk.Entry(body3, textvariable=var).grid(row=3, column=i, sticky="ew",
                                                    padx=(0 if i == 0 else 4, 0 if i == 2 else 4))

        # Additional potential
        card4, body4 = self._card(search_tab, "에디셔널 잠재", "필요한 경우에만 조건을 지정하면 됩니다.")
        card4.grid(row=1, column=1, sticky="nsew", padx=(7, 0), pady=7)
        body4.grid_columnconfigure(0, weight=1)
        body4.grid_columnconfigure(1, weight=1)
        body4.grid_columnconfigure(2, weight=1)

        tk.Label(body4, text="등급", bg=self.PANEL, fg=self.MUTED,
                 font=("맑은 고딕", 8, "bold")).grid(row=0, column=0, sticky="w")
        ttk.Combobox(body4, textvariable=self.add_grade_var, values=GRADES,
                     state="readonly").grid(row=1, column=0, sticky="ew", padx=(0, 7))
        tk.Label(body4, text="에디를 보지 않으려면 등급을 '무관'으로 둡니다.",
                 bg=self.PANEL, fg=self.MUTED, font=("맑은 고딕", 8)).grid(
                     row=1, column=1, columnspan=2, sticky="w"
                 )
        for i, var in enumerate(self.add_vars):
            tk.Label(body4, text=f"옵션 {i+1}", bg=self.PANEL, fg=self.MUTED,
                     font=("맑은 고딕", 8, "bold")).grid(row=2, column=i, sticky="w", pady=(10, 3))
            ttk.Entry(body4, textvariable=var).grid(row=3, column=i, sticky="ew",
                                                    padx=(0 if i == 0 else 4, 0 if i == 2 else 4))

        # Advanced settings
        card5, body5 = self._card(search_tab, "고급 설정", "대부분은 기본값 그대로 사용하면 됩니다.")
        card5.grid(row=2, column=0, columnspan=2, sticky="ew", pady=(7, 10))
        body5.grid_columnconfigure(1, weight=1)
        body5.grid_columnconfigure(3, weight=1)

        self._field_label(body5, "API 기본 호출 간격(초)", 0, 0)
        ttk.Entry(body5, textvariable=self.base_interval_var, width=10).grid(row=1, column=0, sticky="ew", padx=(0, 10))
        self._field_label(body5, "최대 랭킹 페이지", 0, 1)
        ttk.Entry(body5, textvariable=self.max_pages_var, width=10).grid(row=1, column=1, sticky="ew", padx=(0, 10))
        tk.Label(
            body5,
            text="429가 발생하면 자동으로 장기 쿨다운하고, 검색 진행상황은 체크포인트에 저장됩니다.",
            bg=self.PANEL, fg=self.MUTED, font=("맑은 고딕", 8)
        ).grid(row=1, column=2, columnspan=2, sticky="w")

        # Bottom search controls
        controls = tk.Frame(search_tab, bg=self.BG)
        controls.grid(row=3, column=0, columnspan=2, sticky="ew", pady=(4, 12))
        ttk.Button(controls, text="검색 시작", style="Accent.TButton",
                   command=self._start_search).pack(side="left")
        ttk.Button(controls, text="기본값 복원", style="Ghost.TButton",
                   command=self._load_defaults).pack(side="left", padx=8)
        ttk.Button(controls, text="결과 CSV 저장", style="Ghost.TButton",
                   command=self._export_csv).pack(side="left")

        # Results tab
        result_tab.grid_rowconfigure(1, weight=1)
        result_tab.grid_columnconfigure(0, weight=1)

        result_header = tk.Frame(result_tab, bg=self.BG)
        result_header.grid(row=0, column=0, sticky="ew", pady=(10, 8))
        tk.Label(result_header, text="일치 결과", bg=self.BG, fg=self.TEXT,
                 font=("맑은 고딕", 13, "bold")).pack(side="left")
        tk.Label(result_header, text="잠재/에디 옵션은 가로 스크롤로 모두 확인할 수 있습니다.",
                 bg=self.BG, fg=self.MUTED, font=("맑은 고딕", 8)).pack(side="left", padx=12)

        result_frame = tk.Frame(result_tab, bg=self.PANEL, highlightthickness=1,
                                highlightbackground=self.BORDER)
        result_frame.grid(row=1, column=0, sticky="nsew", pady=(0, 10))
        result_frame.grid_rowconfigure(0, weight=1)
        result_frame.grid_columnconfigure(0, weight=1)

        columns = (
            "닉네임","월드","레벨","직업","길드","장비명","스타포스",
            "잠재등급","잠재1","잠재2","잠재3",
            "에디등급","에디1","에디2","에디3","장비출처"
        )
        self.tree = ttk.Treeview(result_frame, columns=columns, show="headings",
                                 style="App.Treeview")
        widths = {
            "닉네임":110,"월드":80,"레벨":55,"직업":115,"길드":95,
            "장비명":185,"스타포스":65,"잠재등급":75,
            "잠재1":185,"잠재2":185,"잠재3":185,
            "에디등급":75,"에디1":175,"에디2":175,"에디3":175,"장비출처":80,
        }
        for col in columns:
            self.tree.heading(col, text=col)
            self.tree.column(col, width=widths.get(col, 100), anchor="center")
        ybar = ttk.Scrollbar(result_frame, orient="vertical", command=self.tree.yview)
        xbar = ttk.Scrollbar(result_frame, orient="horizontal", command=self.tree.xview)
        self.tree.configure(yscrollcommand=ybar.set, xscrollcommand=xbar.set)
        self.tree.grid(row=0, column=0, sticky="nsew")
        ybar.grid(row=0, column=1, sticky="ns")
        xbar.grid(row=1, column=0, sticky="ew")

        # Log tab
        log_tab.grid_rowconfigure(1, weight=1)
        log_tab.grid_columnconfigure(0, weight=1)

        log_header = tk.Frame(log_tab, bg=self.BG)
        log_header.grid(row=0, column=0, sticky="ew", pady=(10, 8))
        tk.Label(log_header, text="진행 로그", bg=self.BG, fg=self.TEXT,
                 font=("맑은 고딕", 13, "bold")).pack(side="left")
        tk.Label(log_header, text="429 대기 및 체크포인트 상태를 여기에서 확인합니다.",
                 bg=self.BG, fg=self.MUTED, font=("맑은 고딕", 8)).pack(side="left", padx=12)

        log_wrap = tk.Frame(log_tab, bg="#0A1018", highlightthickness=1,
                            highlightbackground=self.BORDER)
        log_wrap.grid(row=1, column=0, sticky="nsew", pady=(0, 10))
        self.log_text = tk.Text(
            log_wrap, wrap="word", bg="#0A1018", fg="#C8D2E0",
            insertbackground=self.TEXT, relief="flat", borderwidth=0,
            font=("Consolas", 9), padx=12, pady=12
        )
        log_scroll = ttk.Scrollbar(log_wrap, orient="vertical", command=self.log_text.yview)
        self.log_text.configure(yscrollcommand=log_scroll.set)
        self.log_text.pack(side="left", fill="both", expand=True)
        log_scroll.pack(side="right", fill="y")

        # Bottom status bar
        statusbar = tk.Frame(main, bg=self.PANEL_3, height=52)
        statusbar.grid(row=3, column=0, sticky="ew")
        statusbar.grid_columnconfigure(1, weight=1)

        tk.Label(statusbar, text="STATUS", bg=self.PANEL_3, fg="#65758D",
                 font=("맑은 고딕", 7, "bold")).grid(row=0, column=0, padx=(26, 10), pady=(9, 0), sticky="w")
        tk.Label(statusbar, textvariable=self.status_var, bg=self.PANEL_3, fg=self.TEXT,
                 font=("맑은 고딕", 8, "bold")).grid(row=1, column=0, padx=(26, 10), pady=(0, 8), sticky="w")

        self.progress = ttk.Progressbar(
            statusbar, variable=self.progress_var, maximum=100,
            style="App.Horizontal.TProgressbar"
        )
        self.progress.grid(row=0, column=1, rowspan=2, sticky="ew", padx=(10, 14), pady=18)

        ttk.Button(statusbar, text="결과 보기", style="Ghost.TButton",
                   command=lambda: self.notebook.select(1)).grid(
                       row=0, column=2, rowspan=2, padx=(0, 8), pady=9
                   )
        ttk.Button(statusbar, text="로그 보기", style="Ghost.TButton",
                   command=lambda: self.notebook.select(2)).grid(
                       row=0, column=3, rowspan=2, padx=(0, 20), pady=9
                   )

        self._on_group_changed()

        # Live summary bindings.
        for var in (self.min_level_var, self.max_level_var, self.job_group_var,
                    self.job_var, self.item_name_var):
            var.trace_add("write", lambda *_: self._update_metrics())
        self._update_metrics()

    def _update_metrics(self):
        try:
            lv1 = self.min_level_var.get().strip()
            lv2 = self.max_level_var.get().strip()
            level_txt = f"{lv1}" if lv1 == lv2 else f"{lv1}~{lv2}"
            if self.metric_level is not None:
                self.metric_level.configure(text=level_txt or "-")
            if self.metric_job is not None:
                job = self.job_var.get().strip() or self.job_group_var.get().strip()
                self.metric_job.configure(text=job or "-")
            if self.metric_mode is not None:
                mode = "프리셋 포함" if self.include_presets_var.get() else "현재 장비"
                self.metric_mode.configure(text=mode)
        except Exception:
            pass

    def _equipment_suggestions(self, query):
        return self.catalog.suggest(query, limit=100)

    def _equipment_selected(self, name):
        self.item_name_mode_var.set("정확히 일치")

    def _refresh_catalog_label(self):
        if hasattr(self, "catalog_status_label"):
            self.catalog_status_label.configure(
                text=f"장비 추천 데이터 {len(self.catalog):,}개 · 검색할수록 자동 추가"
            )

    def _import_equipment_catalog(self):
        path = filedialog.askopenfilename(
            title="장비 이름 목록 추가",
            filetypes=[
                ("장비 목록", "*.json *.txt"),
                ("JSON 파일", "*.json"),
                ("텍스트 파일", "*.txt"),
                ("모든 파일", "*.*"),
            ],
        )
        if not path:
            return
        try:
            added = self.catalog.import_file(path)
            self._refresh_catalog_label()
            messagebox.showinfo(
                "장비 목록 추가",
                f"새 장비 이름 {added:,}개를 추가했습니다.\\n"
                f"현재 추천 데이터: {len(self.catalog):,}개",
            )
        except Exception as e:
            messagebox.showerror("장비 목록 오류", str(e))

    def _load_defaults(self):
        self.date_var.set(yesterday_kst()); self.min_level_var.set("295"); self.max_level_var.set("295")
        self.job_group_var.set("마법사"); self._on_group_changed(); self.job_var.set("비숍")
        self.world_normal_var.set(True); self.world_reboot_var.set(True); self.include_presets_var.set(True)
        self.item_name_var.set(""); self.item_name_mode_var.set("정확히 일치"); self.starforce_var.set("")
        self.pot_grade_var.set("무관")
        for v in self.pot_vars: v.set("")
        self.add_grade_var.set("무관")
        for v in self.add_vars: v.set("")
        self.max_pages_var.set("300"); self.base_interval_var.set("0.75")
        if hasattr(self, "_update_metrics"): self._update_metrics()

    def _toggle_key(self):
        self.key_entry.configure(show="" if self.show_key_var.get() else "●")

    def _on_group_changed(self,event=None):
        g=self.job_group_var.get()
        vals=["전체"] if g=="전체" else JOB_GROUPS.get(g,[])
        self.job_combo["values"]=vals
        if self.job_var.get() not in vals:
            self.job_var.set(vals[0] if vals else "")
        if hasattr(self, "_update_metrics"): self._update_metrics()

    def _get_cfg(self):
        key=clean_text(self.api_key_var.get())
        if not key: raise ValueError("NEXON API Key를 입력하세요.")
        try:
            mn=int(self.min_level_var.get()); mx=int(self.max_level_var.get())
        except: raise ValueError("레벨은 숫자로 입력하세요.")
        if mn<1 or mx<mn: raise ValueError("레벨 범위를 확인하세요.")
        date=clean_text(self.date_var.get())
        try: datetime.strptime(date,"%Y-%m-%d")
        except: raise ValueError("날짜는 YYYY-MM-DD 형식으로 입력하세요.")
        w=[]
        if self.world_normal_var.get(): w.append(0)
        if self.world_reboot_var.get(): w.append(1)
        if not w: raise ValueError("월드 유형을 하나 이상 선택하세요.")
        star=clean_text(self.starforce_var.get())
        if star:
            try:
                if int(star)<0: raise ValueError
            except: raise ValueError("스타포스는 숫자 또는 빈칸이어야 합니다.")
        try:
            pages=int(self.max_pages_var.get())
            if not 1<=pages<=1000: raise ValueError
        except: raise ValueError("최대 랭킹 페이지는 1~1000입니다.")
        try:
            interval=float(self.base_interval_var.get())
            if not 0.25<=interval<=5.0: raise ValueError
        except: raise ValueError("API 호출 간격은 0.25~5.0초 사이로 입력하세요.")
        g=self.job_group_var.get(); job="전체" if g=="전체" else self.job_var.get()
        return {
            "api_key":key,"date":date,"min_level":mn,"max_level":mx,"job_group":g,"job":job,
            "world_types":w,"include_presets":self.include_presets_var.get(),
            "item_name":clean_text(self.item_name_var.get()),"item_name_mode":self.item_name_mode_var.get(),
            "starforce":star,"potential_grade":self.pot_grade_var.get(),
            "potential_lines":[v.get() for v in self.pot_vars],
            "additional_grade":self.add_grade_var.get(),"additional_lines":[v.get() for v in self.add_vars],
            "max_pages":pages,"base_interval":interval,
        }

    def _start_search(self):
        if self.worker and self.worker.is_alive(): return
        try: cfg=self._get_cfg()
        except ValueError as e:
            messagebox.showerror("입력 확인",str(e)); return

        cp=Checkpoint(self.app_dir,cfg)
        resume=False
        if cp.exists():
            try:
                cp.load()
                done=len(cp.data.get("completed",{})); total=len(cp.data.get("candidates",[]))
                phase=cp.data.get("phase","")
                if phase=="done":
                    choice=messagebox.askyesnocancel(
                        "이전 검색 발견",
                        f"같은 조건의 완료된 검색이 있습니다.\n후보 {total}명 / 완료 {done}명\n\n"
                        "예 = 기존 결과 열기\n아니오 = 처음부터 다시 검색\n취소 = 돌아가기"
                    )
                    if choice is None: return
                    if choice is True:
                        self._load_checkpoint_into_ui(cp)
                        self.status_var.set(f"완료된 체크포인트 불러옴 - 결과 {len(self.results)}건")
                        return
                    else:
                        try: cp.path.unlink()
                        except: pass
                else:
                    choice=messagebox.askyesno(
                        "이어하기 가능",
                        f"같은 조건의 미완료 검색이 있습니다.\n후보 {total}명 / 완료 {done}명\n\n"
                        "이어하시겠습니까?\n(아니오를 누르면 처음부터 다시 시작)"
                    )
                    if choice:
                        resume=True
                    else:
                        try: cp.path.unlink()
                        except: pass
            except Exception:
                pass

        self.last_cfg=cfg; self.cancel_event.clear(); self.results.clear()
        for iid in self.tree.get_children(): self.tree.delete(iid)
        self.count_var.set("0"); self.log_text.delete("1.0","end"); self.progress_var.set(0)
        self.status_var.set("준비 중..."); self.start_btn.configure(state="disabled"); self.cancel_btn.configure(state="normal")
        self.worker=threading.Thread(target=self._worker_main,args=(cfg,resume),daemon=True); self.worker.start()

    def _load_checkpoint_into_ui(self,cp):
        self.results=list(cp.data.get("results") or [])
        for iid in self.tree.get_children(): self.tree.delete(iid)
        for row in self.results: self._insert_result(row)
        self.count_var.set(str(len(self.results)))
        self.last_cfg={**cp.data.get("config",{}),"api_key":self.api_key_var.get()}

    def _cancel_search(self):
        self.cancel_event.set(); self.status_var.set("중지 요청 중... 체크포인트 저장 후 종료합니다.")

    def _worker_main(self,cfg,resume):
        def log(msg): self.event_q.put(("log",msg))
        def progress(stage,cur,total): self.event_q.put(("progress",stage,cur,total))
        def result(row): self.event_q.put(("result",row))
        def cooldown(seconds): self.event_q.put(("cooldown",seconds))

        client=AdaptiveApiClient(
            cfg["api_key"],
            self.cancel_event,
            log_cb=log,
            base_interval=cfg["base_interval"],
            cache_dir=self.app_dir / "api_cache",
            cooldown_cb=cooldown,
        )
        cp=Checkpoint(self.app_dir,cfg)

        try:
            if resume and cp.exists():
                cp.load()
                log("=== 이전 검색 이어하기 ===")
                # replay already-found results into the UI
                for row in cp.data.get("results") or []: result(row)
            else:
                log("=== 새 검색 시작 ===")
                log(f"날짜: {cfg['date']} / 레벨: {cfg['min_level']}~{cfg['max_level']}")
                log(f"직업: {cfg['job_group']} > {cfg['job']}")
                log(f"장비: {cfg['item_name'] or '(무관)'} / 스타포스: {cfg['starforce'] or '(무관)'}")
                log(f"API 기본 호출 간격: {cfg['base_interval']:.2f}초")

            if not cp.data.get("candidates"):
                candidates=collect_candidates(client,cfg,log,progress)
                cp.data["candidates"]=candidates
                cp.data["phase"]="scanning"
                cp.save()
                log(f"\n후보 수집 완료: {len(candidates)}명")
                if candidates:
                    preview=", ".join(f"{c['character_name']}({c['world_name']}, Lv.{c['level']})" for c in candidates[:10])
                    log(f"후보 예시: {preview}")
            else:
                candidates=cp.data["candidates"]
                log(f"저장된 후보 목록 사용: {len(candidates)}명")

            if not candidates:
                self.event_q.put(("done",cp,client.total_429,"후보가 없습니다.")); return

            results=scan_candidates(client,cfg,cp,log,progress,result,self.catalog.learn_many)
            log(
                f"API 캐시: 적중 {client.cache_hits}건 / "
                f"새 저장 {client.cache_writes}건"
            )
            self.event_q.put(("done",cp,client.total_429,None))

        except InterruptedError:
            try: cp.save()
            except: pass
            log(
                f"API 캐시: 적중 {client.cache_hits}건 / "
                f"새 저장 {client.cache_writes}건"
            )
            self.event_q.put(("cancelled",cp,client.total_429))
        except Exception as e:
            try: cp.save()
            except: pass
            self.event_q.put(("error",str(e),cp,client.total_429))

    def _poll_events(self):
        try:
            while True:
                ev=self.event_q.get_nowait(); kind=ev[0]
                if kind=="log":
                    self._append_log(ev[1])
                elif kind=="cooldown":
                    remaining=ev[1]
                    if remaining > 0:
                        self.status_var.set(
                            f"API 호출량 제한 해제 대기 중... {remaining}초 "
                            "(중지 버튼으로 안전 종료 가능)"
                        )
                    else:
                        self.status_var.set("API 재시도 중...")
                elif kind=="progress":
                    _,stage,cur,total=ev
                    if total: self.progress_var.set(min(100,cur*100/total))
                    self.status_var.set(f"랭킹 수집 중... page {cur}" if stage=="rank" else f"장비 조회 중... {cur}/{total}")
                elif kind=="result":
                    row=ev[1]
                    # avoid duplicate UI rows on resumed checkpoint replay
                    sig=(row.get("닉네임"),row.get("월드"),row.get("장비명"),row.get("스타포스"),
                         row.get("잠재1"),row.get("잠재2"),row.get("잠재3"),
                         row.get("에디1"),row.get("에디2"),row.get("에디3"))
                    existing={(r.get("닉네임"),r.get("월드"),r.get("장비명"),r.get("스타포스"),
                               r.get("잠재1"),r.get("잠재2"),r.get("잠재3"),
                               r.get("에디1"),r.get("에디2"),r.get("에디3")) for r in self.results}
                    if sig not in existing:
                        self.results.append(row); self._insert_result(row)
                    self.count_var.set(str(len(self.results)))
                elif kind=="done":
                    _,cp,n429,note=ev
                    self.progress_var.set(100); self.start_btn.configure(state="normal"); self.cancel_btn.configure(state="disabled")
                    done=len(cp.data.get("completed",{})); total=len(cp.data.get("candidates",[]))
                    self.status_var.set(f"검색 완료 - {done}/{total}명 검사 / 결과 {len(cp.data.get('results',[]))}건")
                    self._append_log(f"\n=== 검색 완료 ===\n완료 {done}/{total}명")
                    self._append_log(f"체크포인트: {cp.path}")
                    self._append_log(f"결과 CSV: {cp.results_csv}")
                    self._refresh_catalog_label()
                    messagebox.showinfo("검색 완료",f"후보 {total}명 검사가 완료되었습니다.\n일치하는 결과는 {len(cp.data.get('results',[]))}건입니다.")
                elif kind=="cancelled":
                    _,cp,n429=ev
                    self.start_btn.configure(state="normal"); self.cancel_btn.configure(state="disabled")
                    done=len(cp.data.get("completed",{})); total=len(cp.data.get("candidates",[]))
                    self.status_var.set(f"중지됨 - {done}/{total}명 저장 완료")
                    self._append_log(f"\n중지됨. 진행상황 저장 완료: {done}/{total}명")
                    self._append_log("같은 조건으로 다시 검색하면 이어하기 여부를 묻습니다.")
                    self._refresh_catalog_label()
                elif kind=="error":
                    _,msg,cp,n429=ev
                    self.start_btn.configure(state="normal"); self.cancel_btn.configure(state="disabled")
                    self.status_var.set("오류 - 진행상황은 저장됨")
                    self._append_log("\n[오류]\n"+msg)
                    messagebox.showerror("검색 오류",msg+"\n\n진행상황은 저장되어 다음 실행에서 이어갈 수 있습니다.")
        except queue.Empty:
            pass
        self.after(100,self._poll_events)

    def _insert_result(self,row):
        vals=[row.get(k,"") for k in ("닉네임","월드","레벨","직업","길드","장비명","스타포스","잠재등급","잠재1","잠재2","잠재3","에디등급","에디1","에디2","에디3","장비출처")]
        self.tree.insert("","end",values=vals)

    def _append_log(self,msg):
        self.log_text.insert("end",msg+"\n"); self.log_text.see("end")

    def _export_csv(self):
        if not self.results:
            messagebox.showinfo("결과 없음","저장할 결과가 없습니다."); return
        path=filedialog.asksaveasfilename(title="결과 CSV 저장",defaultextension=".csv",filetypes=[("CSV","*.csv")],initialfile="maple_equipment_results.csv")
        if not path: return
        fields=list(self.results[0].keys())
        with open(path,"w",encoding="utf-8-sig",newline="") as f:
            w=csv.DictWriter(f,fieldnames=fields); w.writeheader(); w.writerows(self.results)
        messagebox.showinfo("저장 완료",path)


if __name__=="__main__":
    App().mainloop()
