# -*- coding: utf-8 -*-
"""
MapleStory Equipment Finder GUI v3
Robust long-run version:
- Adaptive rate limiting / Retry-After support
- Automatic checkpoint
- Resume interrupted scans
- Avoid rescanning completed candidates
- Results/errors saved incrementally
- No third-party packages required
"""

import base64
import calendar
import csv
import hashlib
import json
import os
import queue
import re
import threading
import time
import webbrowser
from collections import Counter
from datetime import datetime, timedelta, timezone
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.parse import urlencode, quote
from urllib.request import Request, urlopen

import tkinter as tk
from tkinter import ttk, filedialog, messagebox

BASE = "https://open.api.nexon.com/maplestory/v1"
KST = timezone(timedelta(hours=9))
OPENAPI_HISTORY_START = datetime(2023, 12, 21, tzinfo=KST).date()
CACHE_MAX_AGE_DAYS = 29
CREDIT_TEXT = "Data based on NEXON Open API"
_GLOBAL_API_PACE_LOCK = threading.Lock()
_GLOBAL_API_LAST_REQUEST = 0.0

JOB_GROUPS = {
    "전사": [
        "히어로", "팔라딘", "다크나이트",
        "소울마스터", "미하일", "아란",
        "블래스터", "데몬슬레이어", "데몬어벤져",
        "카이저", "제로", "아델", "렌",
    ],
    "마법사": [
        "아크메이지(불,독)", "아크메이지(썬,콜)", "비숍",
        "플레임위자드", "에반", "루미너스", "배틀메이지",
        "키네시스", "일리움", "라라", "레테",
    ],
    "궁수": [
        "보우마스터", "신궁", "패스파인더",
        "윈드브레이커", "메르세데스", "와일드헌터", "카인",
    ],
    "도적": [
        "나이트로드", "섀도어", "듀얼블레이더",
        "나이트워커", "팬텀", "카데나", "호영", "칼리",
    ],
    "해적": [
        "바이퍼", "캡틴", "캐논마스터",
        "스트라이커", "은월", "메카닉", "엔젤릭버스터", "아크",
    ],
    "도적/해적": ["제논"],
}
JOB_API_FILTER = {
    "히어로": "전사-히어로",
    "팔라딘": "전사-팔라딘",
    "다크나이트": "전사-다크나이트",

    "아크메이지(불,독)": "마법사-아크메이지(불독)",
    "아크메이지(썬,콜)": "마법사-아크메이지(썬콜)",
    "비숍": "마법사-비숍",

    "보우마스터": "궁수-보우마스터",
    "신궁": "궁수-신궁",
    "패스파인더": "궁수-패스파인더",

    "나이트로드": "도적-나이트로드",
    "섀도어": "도적-섀도어",
    "듀얼블레이더": "도적-듀얼블레이더",

    "바이퍼": "해적-바이퍼",
    "캡틴": "해적-캡틴",
    "캐논마스터": "해적-캐논마스터",

    "소울마스터": "기사단-소울마스터",
    "플레임위자드": "기사단-플레임위자드",
    "윈드브레이커": "기사단-윈드브레이커",
    "나이트워커": "기사단-나이트워커",
    "스트라이커": "기사단-스트라이커",
    "미하일": "기사단-미하일",

    "아란": "아란-전체 전직",
    "에반": "에반-전체 전직",
    "메르세데스": "메르세데스-전체 전직",
    "팬텀": "팬텀-전체 전직",
    "루미너스": "루미너스-전체 전직",
    "은월": "은월-전체 전직",

    "배틀메이지": "레지스탕스-배틀메이지",
    "와일드헌터": "레지스탕스-와일드헌터",
    "메카닉": "레지스탕스-메카닉",
    "데몬슬레이어": "레지스탕스-데몬슬레이어",
    "데몬어벤져": "레지스탕스-데몬어벤져",
    "제논": "레지스탕스-제논",
    "블래스터": "레지스탕스-블래스터",

    "카이저": "카이저-전체 전직",
    "엔젤릭버스터": "엔젤릭버스터-전체 전직",
    "카데나": "카데나-전체 전직",
    "카인": "카인-전체 전직",

    "제로": "초월자-제로",
    "키네시스": "프렌즈 월드-키네시스",

    "일리움": "일리움-전체 전직",
    "아크": "아크-전체 전직",
    "아델": "아델-전체 전직",
    "칼리": "칼리-전체 전직",

    "호영": "호영-전체 전직",
    "라라": "라라-전체 전직",
    "렌": "렌-전체 전직",

    "레테": "레테-전체 전직",
}

EQUIP_LIST_KEYS = [
    ("현재 장비", "item_equipment"),
    ("프리셋 1", "item_equipment_preset_1"),
    ("프리셋 2", "item_equipment_preset_2"),
    ("프리셋 3", "item_equipment_preset_3"),
]
GRADES = ["미적용", "레어", "에픽", "유니크", "레전드리"]


def latest_complete_historical_date_kst():
    """Most recent day whose character/guild historical snapshot is officially ready.

    NEXON currently publishes previous-day character/union/guild data from 02:00 KST.
    Before 02:00, use two days ago as the latest complete historical date.
    """
    now = datetime.now(KST)
    days_back = 1 if (now.hour, now.minute) >= (2, 0) else 2
    return now.date() - timedelta(days=days_back)


def yesterday_kst():
    # Kept for UI compatibility; now means the latest officially complete
    # historical search date rather than blindly calendar-yesterday.
    return latest_complete_historical_date_kst().isoformat()


def today_kst():
    return datetime.now(KST).date()


def parse_flexible_search_date(value):
    """Accept YYYY-M-D or M-D and normalize to a date."""
    raw=clean_text(value)
    if not raw:
        raise ValueError("조회 날짜를 입력하세요.")

    normalized=re.sub(r"[./\\s]+","-",raw)
    normalized=re.sub(r"-+","-",normalized).strip("-")
    parts=normalized.split("-")
    today=today_kst()

    try:
        if len(parts)==2:
            year=today.year
            month=int(parts[0])
            day=int(parts[1])
        elif len(parts)==3:
            year=int(parts[0])
            month=int(parts[1])
            day=int(parts[2])
        else:
            raise ValueError
        return datetime(year,month,day).date()
    except Exception:
        raise ValueError(
            "날짜 형식을 확인하세요.\n"
            "예: 2026-09-16 / 2026-9-16 / 9-16"
        )


def clean_text(s):
    return (s or "").strip()



def _opt_norm(value):
    s=str(value or '').strip().casefold()
    s=s.replace('％','%')
    return re.sub(r'[\s_:<>]', '', s)


def _first_number(value):
    m=re.search(r'[-+]?\d+(?:\.\d+)?', str(value or ''))
    if not m:
        return None
    try:
        return abs(float(m.group(0)))
    except Exception:
        return None


def _query_without_number(value):
    s=str(value or '').strip().casefold().replace('％','%')
    s=re.sub(r'[-+]?\d+(?:\.\d+)?', '', s)
    s=s.replace('%','').replace('초','')
    return re.sub(r'[\s_:<>+\-]', '', s)


def _defs_for_mode(mode):
    return OPTION_TYPE_DEFS.get(mode, [])


def _option_candidates(value, mode):
    raw=str(value or '').strip()
    if not raw:
        return []
    defs=_defs_for_mode(mode)
    base=_query_without_number(raw)
    has_pct='%' in raw or '퍼' in raw
    has_sec='초' in raw
    has_plus='+' in raw and '%' not in raw
    num=_first_number(raw)
    matches=[]
    for d in defs:
        terms=[d.get('label',''), d.get('display','')] + d.get('aliases',[])
        norm_terms=[_query_without_number(x) for x in terms if x]
        if not base:
            continue
        if any(base==x or base in x or x in base for x in norm_terms if x):
            matches.append(d)
    if not matches:
        return []
    if has_pct:
        pct=[d for d in matches if d.get('kind')=='percent']
        if pct: matches=pct
    elif has_sec:
        sec=[d for d in matches if d.get('kind')=='seconds']
        if sec: matches=sec
    elif has_plus:
        flat=[d for d in matches if d.get('kind')=='flat']
        if flat: matches=flat
    elif num is not None:
        # Maple shorthand such as 힘12/마12/공2 normally means percentage.
        pct=[d for d in matches if d.get('kind')=='percent']
        if pct: matches=pct
    def rank(d):
        terms=[d.get('label',''), d.get('display','')] + d.get('aliases',[])
        norms=[_query_without_number(x) for x in terms if x]
        if base in norms: match_rank=0
        elif any(x.startswith(base) for x in norms): match_rank=1
        else: match_rank=2
        kind_rank=0 if d.get('kind')=='percent' else (1 if d.get('kind')=='flat' else 0)
        return (match_rank, kind_rank)
    return sorted(matches, key=lambda d:(rank(d), len(d.get('label','')), d.get('label','')))


def _semantic_line_match(actual, wanted, mode):
    a=str(actual or '').strip()
    w=str(wanted or '').strip()
    if not a or not w:
        return False
    wcands=_option_candidates(w, mode)
    acands=_option_candidates(a, mode)
    wn=_first_number(w)
    an=_first_number(a)
    if wcands and acands:
        akeys={d['key'] for d in acands}
        for wd in wcands:
            if wd['key'] not in akeys:
                continue
            if wn is None:
                return True
            if an is not None and abs(an-wn)<1e-9:
                return True
        return False
    anorm=_opt_norm(a)
    wnorm=_opt_norm(w)
    if not re.search(r'\d', w):
        return wnorm in anorm
    return anorm==wnorm


def _def_by_key(mode, key):
    for d in OPTION_TYPE_DEFS.get(mode, []):
        if d.get("key") == key:
            return d
    return None


def _family_suggestions(query, mode, limit=30):
    query=str(query or "").strip()
    if not query:
        return []
    defs=_option_candidates(query, mode)
    out=[]
    seen=set()
    for d in defs:
        name=d.get("display") or d.get("label")
        if name and name not in seen:
            seen.add(name)
            out.append(name)
        if len(out)>=limit:
            break
    return out


def _resolve_family(mode, value):
    raw=str(value or "").strip()
    if not raw:
        return None
    # Direct display match first.
    for d in OPTION_TYPE_DEFS.get(mode, []):
        if raw.casefold() == str(d.get("display") or "").casefold():
            return d.get("display")
    candidates=_family_suggestions(raw, mode, limit=20)
    unique=[]
    for x in candidates:
        if x not in unique:
            unique.append(x)
    return unique[0] if len(unique)==1 else None


def _family_defs(mode, family):
    return [
        d for d in OPTION_TYPE_DEFS.get(mode, [])
        if d.get("display") == family
    ]


def _unit_for_kind(kind):
    return {
        "percent":"%",
        "flat":"수치",
        "seconds":"초",
        "skill":"값 없음",
        "text":"값 없음",
    }.get(kind, "값 없음")


def _kind_for_unit(unit):
    return {
        "%":"percent",
        "수치":"flat",
        "초":"seconds",
        "값 없음":None,
    }.get(unit)


def _family_units(mode, family):
    units=[]
    for d in _family_defs(mode, family):
        u=_unit_for_kind(d.get("kind"))
        if u not in units:
            units.append(u)
    order={"%":0,"수치":1,"초":2,"값 없음":3}
    return sorted(units, key=lambda x:order.get(x,99))


def _resolve_condition_def(mode, family, unit):
    defs=_family_defs(mode, family)
    if unit=="값 없음":
        # Text / skill option.
        for d in defs:
            if d.get("kind") in ("text","skill"):
                return d
        return defs[0] if len(defs)==1 else None
    kind=_kind_for_unit(unit)
    matches=[d for d in defs if d.get("kind")==kind]
    return matches[0] if len(matches)==1 else None


def _actual_matches_condition(actual, condition, mode):
    actual=str(actual or "").strip()
    if not actual:
        return False
    target=_def_by_key(mode, condition.get("key"))
    if not target:
        return False

    base=_query_without_number(actual)
    terms=[
        target.get("label",""),
        target.get("display",""),
        *target.get("aliases",[]),
    ]
    norms=[_query_without_number(x) for x in terms if x]
    if not any(
        base==x or x in base or base in x
        for x in norms if x
    ):
        return False

    kind=target.get("kind")
    if kind=="percent" and "%" not in actual and "％" not in actual:
        return False
    if kind=="seconds" and "초" not in actual:
        return False
    if kind=="flat" and ("%" in actual or "％" in actual or "초" in actual):
        return False

    wanted=condition.get("value")
    if wanted is None:
        return True
    actual_num=_first_number(actual)
    if actual_num is None:
        return False
    actual_num=float(actual_num)
    wanted=float(wanted)
    op=condition.get("op", "정확히")
    if op=="이상":
        return actual_num >= wanted
    if op=="이하":
        return actual_num <= wanted
    return abs(actual_num-wanted)<1e-9


def structured_options_match(actual_lines, conditions, order_mode, mode):
    conditions=[c for c in (conditions or []) if c]
    if not conditions:
        return True

    actual=list(actual_lines or [])
    while len(actual)<3:
        actual.append("")

    if order_mode=="순서까지 일치":
        for cond in conditions:
            slot=int(cond.get("slot",0))
            if slot<0 or slot>=3:
                return False
            if not _actual_matches_condition(actual[slot], cond, mode):
                return False
        return True

    used=set()
    for cond in conditions:
        found=False
        for i,a in enumerate(actual[:3]):
            if i in used:
                continue
            if _actual_matches_condition(a, cond, mode):
                used.add(i)
                found=True
                break
        if not found:
            return False
    return True


def potential_group_match(item, prefix, grade, conditions, order_mode, mode):
    if prefix=="potential":
        actual_grade=clean_text(item.get("potential_option_grade"))
        actual_lines=[
            item.get("potential_option_1"),
            item.get("potential_option_2"),
            item.get("potential_option_3"),
        ]
    else:
        actual_grade=clean_text(item.get("additional_potential_option_grade"))
        actual_lines=[
            item.get("additional_potential_option_1"),
            item.get("additional_potential_option_2"),
            item.get("additional_potential_option_3"),
        ]

    # 미적용은 잠재/에디셔널의 존재 여부와 내용을 검색 조건에서 완전히 제외한다.
    if grade=="미적용":
        return True

    conditions=[c for c in (conditions or []) if c]

    # 특정 등급을 선택했지만 옵션을 하나도 입력하지 않은 경우에는
    # 등급 선택값 자체를 조건으로 쓰지 않고, 잠재/에디셔널이 없는 장비를 찾는다.
    # (별도의 '없음' 선택지는 두지 않는다.)
    if not conditions:
        return (not actual_grade) and not any(clean_text(x) for x in actual_lines)

    if actual_grade != grade:
        return False

    return structured_options_match(
        actual_lines,
        conditions,
        order_mode,
        mode,
    )


def item_name_match(actual, wanted, mode):
    wanted = clean_text(wanted)
    if not wanted:
        return True
    actual = clean_text(actual)
    return wanted in actual if mode == "이름 포함" else actual == wanted


def safe_filename(s):
    s = re.sub(r'[\\/:*?"<>|]+', "_", s)
    s = re.sub(r"\s+", "_", s.strip())
    return s[:100] or "result"


def atomic_write_json(path, obj):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    with tmp.open("w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=2)
    os.replace(tmp, path)


def search_fingerprint(cfg):
    # Never include API key in a checkpoint ID.
    fields = {
        k: cfg[k] for k in (
            "date","min_level","max_level","job_group","job","world_types",
            "include_presets","item_name","item_name_mode","starforce",
            "potential_grade","potential_conditions","potential_order","additional_grade","additional_conditions","additional_order",
            "flame_presence","flame_conditions","max_pages","character_realtime",
        )
    }
    raw = json.dumps(fields, ensure_ascii=False, sort_keys=True).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()[:16]




OPTION_TYPE_DEFS = {'potential': [{'key': 'boss_damage', 'label': '보스 몬스터 데미지 %증가', 'display': '보스 몬스터 데미지', 'kind': 'percent', 'aliases': ['보공', '보스', '보스 데미지', '보스 몬스터 데미지', '보스 몬스터 공격 시 데미지', 'boss', 'boss damage']}, {'key': 'ignore_defense', 'label': '몬스터 방어율 무시', 'display': '몬스터 방어율 무시', 'kind': 'percent', 'aliases': ['방무', '방어율 무시', '몬스터 방어율 무시', 'ied', 'ignore defense']}, {'key': 'damage_percent', 'label': '데미지 %증가', 'display': '데미지', 'kind': 'percent', 'aliases': ['데미지', '뎀', '뎀퍼', 'damage']}, {'key': 'attack_percent', 'label': '공격력 %증가', 'display': '공격력', 'kind': 'percent', 'aliases': ['공격력', '공퍼', '공', 'attack', 'atk']}, {'key': 'magic_percent', 'label': '마력 %증가', 'display': '마력', 'kind': 'percent', 'aliases': ['마력', '마퍼', '마', 'magic', 'matk']}, {'key': 'all_stat_percent', 'label': '올스탯 %증가', 'display': '올스탯', 'kind': 'percent', 'aliases': ['올스탯', '올퍼', '올', 'all stat', 'allstat']}, {'key': 'str_percent', 'label': 'STR %증가', 'display': 'STR', 'kind': 'percent', 'aliases': ['str', '힘', '힘퍼']}, {'key': 'dex_percent', 'label': 'DEX %증가', 'display': 'DEX', 'kind': 'percent', 'aliases': ['dex', '민첩', '덱스', '민첩퍼', '덱퍼']}, {'key': 'int_percent', 'label': 'INT %증가', 'display': 'INT', 'kind': 'percent', 'aliases': ['int', '지능', '인트', '지능퍼', '인트퍼']}, {'key': 'luk_percent', 'label': 'LUK %증가', 'display': 'LUK', 'kind': 'percent', 'aliases': ['luk', '럭', '운', '행운', '럭퍼', '행운퍼']}, {'key': 'crit_rate', 'label': '크리티컬 확률 증가', 'display': '크리티컬 확률', 'kind': 'percent', 'aliases': ['크리티컬 확률', '크확', 'critical rate', 'crit rate']}, {'key': 'crit_damage', 'label': '크리티컬 데미지 증가', 'display': '크리티컬 데미지', 'kind': 'percent', 'aliases': ['크리티컬 데미지', '크뎀', 'critical damage', 'crit damage']}, {'key': 'cooldown', 'label': '모든 스킬 재사용 대기시간 감소', 'display': '모든 스킬 재사용 대기시간 감소', 'kind': 'seconds', 'aliases': ['재사용', '재사용 대기시간', '쿨감', '재감', '쿨타임 감소', 'cooldown', 'cdr']}, {'key': 'item_drop', 'label': '아이템 획득 확률 증가', 'display': '아이템 획득 확률', 'kind': 'percent', 'aliases': ['아이템 획득', '아이템 획득 확률', '아획', '드랍', '드랍률', 'item drop', 'drop rate']}, {'key': 'max_hp_percent', 'label': 'MaxHP %증가', 'display': 'MaxHP', 'kind': 'percent', 'aliases': ['maxhp', 'hp퍼', '체력퍼', '최대hp', '최대 체력']}, {'key': 'max_mp_percent', 'label': 'MaxMP %증가', 'display': 'MaxMP', 'kind': 'percent', 'aliases': ['maxmp', 'mp퍼', '마나퍼', '최대mp', '최대 마나']}, {'key': 'attack_flat', 'label': '공격력 증가', 'display': '공격력', 'kind': 'flat', 'aliases': ['공격력 증가', '공증', '공격력', '공', 'attack up']}, {'key': 'magic_flat', 'label': '마력 증가', 'display': '마력', 'kind': 'flat', 'aliases': ['마력 증가', '마증', '마력', '마', 'magic up']}, {'key': 'skill_haste', 'label': '<쓸만한 헤이스트> 스킬', 'display': '쓸만한 헤이스트', 'kind': 'skill', 'aliases': ['헤이스트', '쓸헤이', '쓸만한 헤이스트']}, {'key': 'skill_mystic_door', 'label': '<쓸만한 미스틱 도어> 스킬', 'display': '쓸만한 미스틱 도어', 'kind': 'skill', 'aliases': ['미스틱 도어', '미도', '쓸미도', '쓸만한 미스틱 도어']}, {'key': 'skill_sharp_eyes', 'label': '<쓸만한 샤프 아이즈> 스킬', 'display': '쓸만한 샤프 아이즈', 'kind': 'skill', 'aliases': ['샤프 아이즈', '샤프', '쓸샾', '쓸만한 샤프 아이즈']}, {'key': 'skill_hyper_body', 'label': '<쓸만한 하이퍼 바디> 스킬', 'display': '쓸만한 하이퍼 바디', 'kind': 'skill', 'aliases': ['하이퍼 바디', '쓸하이', '쓸하이퍼', '쓸만한 하이퍼 바디']}, {'key': 'skill_combat_orders', 'label': '<쓸만한 컴뱃 오더스> 스킬', 'display': '쓸만한 컴뱃 오더스', 'kind': 'skill', 'aliases': ['컴뱃 오더스', '컴뱃', '쓸컴뱃', '쓸만한 컴뱃 오더스']}, {'key': 'skill_advanced_bless', 'label': '<쓸만한 어드밴스드 블레스> 스킬', 'display': '쓸만한 어드밴스드 블레스', 'kind': 'skill', 'aliases': ['어드밴스드 블레스', '어블', '쓸어블', '쓸만한 어드밴스드 블레스']}, {'key': 'skill_wind_booster', 'label': '<쓸만한 윈드 부스터> 스킬', 'display': '쓸만한 윈드 부스터', 'kind': 'skill', 'aliases': ['윈드 부스터', '윈부', '쓸윈부', '쓸만한 윈드 부스터']}, {'key': 'str_flat', 'label': 'STR 증가', 'display': 'STR', 'kind': 'flat', 'aliases': ['str 증가', 'str', '힘 증가', '힘']}, {'key': 'dex_flat', 'label': 'DEX 증가', 'display': 'DEX', 'kind': 'flat', 'aliases': ['dex 증가', 'dex', '민첩 증가', '덱스 증가', '민첩', '덱스']}, {'key': 'int_flat', 'label': 'INT 증가', 'display': 'INT', 'kind': 'flat', 'aliases': ['int 증가', 'int', '지능 증가', '인트 증가', '지능', '인트']}, {'key': 'luk_flat', 'label': 'LUK 증가', 'display': 'LUK', 'kind': 'flat', 'aliases': ['luk 증가', 'luk', '럭 증가', '운 증가', '행운 증가', '럭', '운', '행운']}, {'key': 'max_hp_flat', 'label': 'MaxHP 증가', 'display': 'MaxHP', 'kind': 'flat', 'aliases': ['maxhp 증가', 'maxhp', 'hp 증가', '체력 증가', '최대hp 증가']}, {'key': 'max_mp_flat', 'label': 'MaxMP 증가', 'display': 'MaxMP', 'kind': 'flat', 'aliases': ['maxmp 증가', 'maxmp', 'mp 증가', '마나 증가', '최대mp 증가']}, {'key': 'attack_hp_recovery', 'label': '공격 시 HP 회복', 'display': '공격 시 HP 회복', 'kind': 'text', 'aliases': ['공격 시 hp 회복', '공격시 hp 회복', '타격 hp 회복', '흡혈 hp']}, {'key': 'attack_mp_recovery', 'label': '공격 시 MP 회복', 'display': '공격 시 MP 회복', 'kind': 'text', 'aliases': ['공격 시 mp 회복', '공격시 mp 회복', '타격 mp 회복']}, {'key': 'recovery_efficiency', 'label': 'HP 회복 아이템 및 스킬 효율 증가', 'display': 'HP 회복 아이템 및 스킬 효율', 'kind': 'percent', 'aliases': ['회복 효율', 'hp 회복 효율', '물약 효율', '회복 아이템 효율']}, {'key': 'meso_gain', 'label': '메소 획득량 증가', 'display': '메소 획득량', 'kind': 'percent', 'aliases': ['메소 획득', '메획', '메소', 'meso']}, {'key': 'status_on_attack', 'label': '공격 시 일정 확률로 상태이상 적용', 'display': '공격 시 상태이상 적용', 'kind': 'text', 'aliases': ['상태이상 적용', '공격 시 상태이상', '공격시 상태이상', '상태이상']}, {'key': 'damage_ignore_on_hit', 'label': '피격 시 일정 확률로 데미지% 무시', 'display': '피격 시 데미지 무시', 'kind': 'text', 'aliases': ['피격 데미지 무시', '피격 시 데미지 무시', '데미지 무시']}, {'key': 'defense_percent', 'label': '방어력 %증가', 'display': '방어력', 'kind': 'percent', 'aliases': ['방어력 %증가', '방퍼', 'def%', 'defense percent']}, {'key': 'defense_flat', 'label': '방어력 증가', 'display': '방어력', 'kind': 'flat', 'aliases': ['방어력 증가', '방어력', 'defense']}, {'key': 'invincible_duration', 'label': '피격 후 무적 시간 증가', 'display': '피격 후 무적 시간', 'kind': 'seconds', 'aliases': ['피격 후 무적', '무적 시간', '무적시간 증가']}, {'key': 'chance_invincible', 'label': '피격 시 일정 확률로 일정 시간 무적', 'display': '피격 시 일정 확률로 무적', 'kind': 'text', 'aliases': ['피격 시 무적', '확률 무적', '일정 시간 무적']}, {'key': 'damage_reflect', 'label': '일정 확률로 받은 피해 반사', 'display': '받은 피해 반사', 'kind': 'text', 'aliases': ['피해 반사', '데미지 반사', '반사']}, {'key': 'speed_flat', 'label': '이동속도 증가', 'display': '이동속도', 'kind': 'flat', 'aliases': ['이동속도', '이속', 'move speed']}, {'key': 'jump_flat', 'label': '점프력 증가', 'display': '점프력', 'kind': 'flat', 'aliases': ['점프력', '점프', 'jump']}, {'key': 'kill_hp_recovery', 'label': '몬스터 처치 시 일정 확률로 HP 회복', 'display': '몬스터 처치 시 HP 회복', 'kind': 'text', 'aliases': ['처치 hp 회복', '몬스터 처치 hp', '킬 hp 회복']}, {'key': 'kill_mp_recovery', 'label': '몬스터 처치 시 일정 확률로 MP 회복', 'display': '몬스터 처치 시 MP 회복', 'kind': 'text', 'aliases': ['처치 mp 회복', '몬스터 처치 mp', '킬 mp 회복']}, {'key': 'mp_cost_reduction', 'label': '모든 스킬의 MP 소모 감소', 'display': '모든 스킬의 MP 소모 감소', 'kind': 'percent', 'aliases': ['mp 소모 감소', '마나 소모 감소', 'mp 감소']}], 'additional': [{'key': 'boss_damage', 'label': '보스 공격 시 데미지 %증가', 'display': '보스 공격 시 데미지', 'kind': 'percent', 'aliases': ['보공', '보스', '보스 공격 시 데미지', '보스 몬스터 데미지', 'boss damage']}, {'key': 'ignore_defense', 'label': '몬스터 방어율 무시', 'display': '몬스터 방어율 무시', 'kind': 'percent', 'aliases': ['방무', '방어율 무시', '몬스터 방어율 무시', 'ied', 'ignore defense']}, {'key': 'damage_percent', 'label': '데미지 %증가', 'display': '데미지', 'kind': 'percent', 'aliases': ['데미지', '뎀', 'damage']}, {'key': 'attack_percent', 'label': '공격력 %증가', 'display': '공격력', 'kind': 'percent', 'aliases': ['공격력', '공퍼', '공', 'attack', 'atk']}, {'key': 'magic_percent', 'label': '마력 %증가', 'display': '마력', 'kind': 'percent', 'aliases': ['마력', '마퍼', '마', 'magic', 'matk']}, {'key': 'all_stat_percent', 'label': '올스탯 %증가', 'display': '올스탯', 'kind': 'percent', 'aliases': ['올스탯', '올퍼', '올', 'all stat', 'allstat']}, {'key': 'str_percent', 'label': 'STR %증가', 'display': 'STR', 'kind': 'percent', 'aliases': ['str', '힘', '힘퍼']}, {'key': 'dex_percent', 'label': 'DEX %증가', 'display': 'DEX', 'kind': 'percent', 'aliases': ['dex', '민첩', '덱스', '민첩퍼', '덱퍼']}, {'key': 'int_percent', 'label': 'INT %증가', 'display': 'INT', 'kind': 'percent', 'aliases': ['int', '지능', '인트', '지능퍼', '인트퍼']}, {'key': 'luk_percent', 'label': 'LUK %증가', 'display': 'LUK', 'kind': 'percent', 'aliases': ['luk', '럭', '운', '행운', '럭퍼']}, {'key': 'crit_rate', 'label': '크리티컬 확률 증가', 'display': '크리티컬 확률', 'kind': 'percent', 'aliases': ['크리티컬 확률', '크확', 'critical rate', 'crit rate']}, {'key': 'crit_damage', 'label': '크리티컬 데미지 증가', 'display': '크리티컬 데미지', 'kind': 'percent', 'aliases': ['크리티컬 데미지', '크뎀', 'critical damage', 'crit damage']}, {'key': 'cooldown', 'label': '모든 스킬 재사용 대기시간 감소', 'display': '모든 스킬 재사용 대기시간 감소', 'kind': 'seconds', 'aliases': ['재사용', '쿨감', '재감', 'cooldown', 'cdr']}, {'key': 'item_drop', 'label': '아이템 획득 확률 증가', 'display': '아이템 획득 확률', 'kind': 'percent', 'aliases': ['아이템 획득', '아획', 'drop', '드랍', '드랍률']}, {'key': 'max_hp_percent', 'label': 'MaxHP %증가', 'display': 'MaxHP', 'kind': 'percent', 'aliases': ['maxhp', 'hp퍼', '체력퍼', '최대hp']}, {'key': 'max_mp_percent', 'label': 'MaxMP %증가', 'display': 'MaxMP', 'kind': 'percent', 'aliases': ['maxmp', 'mp퍼', '마나퍼', '최대mp']}, {'key': 'attack_flat', 'label': '공격력 증가', 'display': '공격력', 'kind': 'flat', 'aliases': ['공격력 증가', '공증', '공격력', '공']}, {'key': 'magic_flat', 'label': '마력 증가', 'display': '마력', 'kind': 'flat', 'aliases': ['마력 증가', '마증', '마력', '마']}, {'key': 'str_flat', 'label': 'STR 증가', 'display': 'STR', 'kind': 'flat', 'aliases': ['str 증가', 'str', '힘 증가', '힘']}, {'key': 'dex_flat', 'label': 'DEX 증가', 'display': 'DEX', 'kind': 'flat', 'aliases': ['dex 증가', 'dex', '민첩 증가', '덱스 증가', '민첩', '덱스']}, {'key': 'int_flat', 'label': 'INT 증가', 'display': 'INT', 'kind': 'flat', 'aliases': ['int 증가', 'int', '지능 증가', '인트 증가', '지능', '인트']}, {'key': 'luk_flat', 'label': 'LUK 증가', 'display': 'LUK', 'kind': 'flat', 'aliases': ['luk 증가', 'luk', '럭 증가', '운 증가', '행운 증가', '럭', '운', '행운']}, {'key': 'max_hp_flat', 'label': 'MaxHP 증가', 'display': 'MaxHP', 'kind': 'flat', 'aliases': ['maxhp 증가', 'hp 증가', '체력 증가', '최대hp 증가']}, {'key': 'max_mp_flat', 'label': 'MaxMP 증가', 'display': 'MaxMP', 'kind': 'flat', 'aliases': ['maxmp 증가', 'mp 증가', '마나 증가', '최대mp 증가']}, {'key': 'attack_hp_recovery', 'label': '공격 시 HP 회복', 'display': '공격 시 HP 회복', 'kind': 'text', 'aliases': ['공격 시 hp 회복', '공격시 hp 회복', '타격 hp 회복']}, {'key': 'attack_mp_recovery', 'label': '공격 시 MP 회복', 'display': '공격 시 MP 회복', 'kind': 'text', 'aliases': ['공격 시 mp 회복', '공격시 mp 회복', '타격 mp 회복']}, {'key': 'per9_str', 'label': '캐릭터 9레벨 당 STR 증가', 'display': '캐릭터 9레벨 당 STR', 'kind': 'flat', 'aliases': ['9레벨당 str', '레벨당 str', '9레벨당 힘', '레벨당 힘']}, {'key': 'per9_dex', 'label': '캐릭터 9레벨 당 DEX 증가', 'display': '캐릭터 9레벨 당 DEX', 'kind': 'flat', 'aliases': ['9레벨당 dex', '레벨당 dex', '9레벨당 민첩', '레벨당 민첩', '레벨당 덱스']}, {'key': 'per9_int', 'label': '캐릭터 9레벨 당 INT 증가', 'display': '캐릭터 9레벨 당 INT', 'kind': 'flat', 'aliases': ['9레벨당 int', '레벨당 int', '9레벨당 지능', '레벨당 지능', '9레벨당 인트', '레벨당 인트']}, {'key': 'per9_luk', 'label': '캐릭터 9레벨 당 LUK 증가', 'display': '캐릭터 9레벨 당 LUK', 'kind': 'flat', 'aliases': ['9레벨당 luk', '레벨당 luk', '9레벨당 럭', '레벨당 럭', '9레벨당 운', '레벨당 운', '9레벨당 행운', '레벨당 행운']}, {'key': 'recovery_efficiency', 'label': 'HP 회복 아이템 및 스킬 효율 증가', 'display': 'HP 회복 아이템 및 스킬 효율', 'kind': 'percent', 'aliases': ['회복 효율', 'hp 회복 효율', '물약 효율']}, {'key': 'meso_gain', 'label': '메소 획득량 증가', 'display': '메소 획득량', 'kind': 'percent', 'aliases': ['메소 획득', '메획', '메소', 'meso']}, {'key': 'defense_percent', 'label': '방어력 %증가', 'display': '방어력', 'kind': 'percent', 'aliases': ['방어력 %증가', '방퍼', 'def%']}, {'key': 'defense_flat', 'label': '방어력 증가', 'display': '방어력', 'kind': 'flat', 'aliases': ['방어력 증가', '방어력', 'defense']}, {'key': 'speed_flat', 'label': '이동속도 증가', 'display': '이동속도', 'kind': 'flat', 'aliases': ['이동속도', '이속', 'move speed']}, {'key': 'jump_flat', 'label': '점프력 증가', 'display': '점프력', 'kind': 'flat', 'aliases': ['점프력', '점프', 'jump']}, {'key': 'mp_cost_reduction', 'label': '모든 스킬의 MP 소모 감소', 'display': '모든 스킬의 MP 소모 감소', 'kind': 'percent', 'aliases': ['mp 소모 감소', '마나 소모 감소', 'mp 감소']}]}

FLAME_OPTION_DEFS = [{'key': 'str', 'label': 'STR', 'kind': 'flat', 'aliases': ['str', '힘', '힘추', '힘 추옵']}, {'key': 'dex', 'label': 'DEX', 'kind': 'flat', 'aliases': ['dex', '민첩', '덱스', '덱', '민첩추', '덱추']}, {'key': 'int', 'label': 'INT', 'kind': 'flat', 'aliases': ['int', '지능', '인트', '인', '지능추', '인트추']}, {'key': 'luk', 'label': 'LUK', 'kind': 'flat', 'aliases': ['luk', '럭', '운', '행운', '럭추', '운추']}, {'key': 'max_hp', 'label': 'MaxHP', 'kind': 'flat', 'aliases': ['maxhp', 'hp', '체력', 'hp추', '체력추']}, {'key': 'max_mp', 'label': 'MaxMP', 'kind': 'flat', 'aliases': ['maxmp', 'mp', '마나', 'mp추']}, {'key': 'attack_power', 'label': '공격력', 'kind': 'flat', 'aliases': ['공격력', '공', '공추', '공격력추']}, {'key': 'magic_power', 'label': '마력', 'kind': 'flat', 'aliases': ['마력', '마', '마추', '마력추']}, {'key': 'armor', 'label': '방어력', 'kind': 'flat', 'aliases': ['방어력', '방어', '방추']}, {'key': 'speed', 'label': '이동속도', 'kind': 'flat', 'aliases': ['이동속도', '이속', '속도']}, {'key': 'jump', 'label': '점프력', 'kind': 'flat', 'aliases': ['점프력', '점프']}, {'key': 'boss_damage', 'label': '보스 몬스터 데미지', 'kind': 'percent', 'aliases': ['보공', '보스', '보스 데미지', '보스 몬스터 데미지']}, {'key': 'damage', 'label': '데미지', 'kind': 'percent', 'aliases': ['데미지', '뎀', '뎀추']}, {'key': 'all_stat', 'label': '올스탯', 'kind': 'percent', 'aliases': ['올스탯', '올', '올추', '올스탯추']}, {'key': 'equipment_level_decrease', 'label': '착용 제한 레벨 감소', 'kind': 'level', 'aliases': ['착용 레벨 감소', '레벨 감소', '착감', '착용 제한 레벨 감소']}]

class OptionCatalog:
    def __init__(self, entries):
        self.entries=list(entries)

    def suggest(self, query, limit=30):
        query=str(query or '').strip()
        if not query:
            return []
        mode='potential' if self.entries is OPTION_TYPE_DEFS['potential'] else 'additional'
        candidates=_option_candidates(query, mode)
        number=_first_number(query)
        out=[]
        for d in candidates:
            if number is None:
                label=d['label']
            elif d.get('kind')=='percent':
                n=int(number) if float(number).is_integer() else number
                label=f"{d['display']} {n}%"
            elif d.get('kind')=='flat':
                n=int(number) if float(number).is_integer() else number
                label=f"{d['display']} +{n}"
            elif d.get('kind')=='seconds':
                n=int(number) if float(number).is_integer() else number
                label=f"{d['display']} {n}초"
            else:
                label=d['label']
            if label not in out:
                out.append(label)
            if len(out)>=limit:
                break
        return out


class FlameCatalog:
    @staticmethod
    def _norm(v):
        return re.sub(r'[\s_+%\-]', '', str(v or '').strip().casefold())

    def suggest(self, query, limit=30):
        q=self._norm(re.sub(r'\d+(?:\.\d+)?','',str(query or '')))
        if not q:
            return []
        found=[]
        for d in FLAME_OPTION_DEFS:
            terms=[d['label']]+d.get('aliases',[])
            norms=[self._norm(x) for x in terms]
            if any(q==x or q in x or x in q for x in norms):
                score=0 if q in norms else 1
                found.append((score,len(d['label']),d['label']))
        found.sort()
        out=[]
        for _,_,label in found:
            if label not in out:
                out.append(label)
            if len(out)>=limit:
                break
        return out

    def resolve(self, value):
        q=self._norm(value)
        if not q:
            return None
        loose=[]
        for d in FLAME_OPTION_DEFS:
            terms=[d['label']]+d.get('aliases',[])
            norms=[self._norm(x) for x in terms]
            if q in norms:
                return d
            if any(q in x or x in q for x in norms):
                loose.append(d)
        return loose[0] if len(loose)==1 else None


def _num(v):
    try:
        return float(v or 0)
    except Exception:
        return 0.0


def flame_has_any(item_add_option):
    add=item_add_option or {}
    return any(abs(_num(add.get(d['key'])))>1e-12 for d in FLAME_OPTION_DEFS)


def flame_match(item, cfg):
    add=item.get('item_add_option') or {}
    presence=cfg.get('flame_presence','미적용')
    if presence=='미적용':
        return True

    has=flame_has_any(add)
    conditions=[c for c in cfg.get('flame_conditions',[]) if c]

    # 적용을 선택하고 조건을 하나도 입력하지 않으면 추가옵션이 없는 장비 검색.
    if not conditions:
        return not has
    if not has:
        return False

    for cond in conditions:
        actual=_num(add.get(cond['field']))
        wanted=float(cond['value'])
        # 추가옵션은 입력한 값과 정확히 같은 값만 검색한다.
        if abs(actual-wanted)>1e-9:
            return False
    return True


def flame_summary(item):
    add=item.get('item_add_option') or {}
    parts=[]
    for d in FLAME_OPTION_DEFS:
        val=_num(add.get(d['key']))
        if abs(val)<1e-12:
            continue
        n=int(val) if float(val).is_integer() else val
        if d['kind']=='percent':
            parts.append(f"{d['label']} +{n}%")
        elif d['kind']=='level':
            parts.append(f"{d['label']} -{n}")
        else:
            parts.append(f"{d['label']} +{n}")
    return ' | '.join(parts) if parts else '없음'


class EquipmentCatalog:
    """Local equipment-name catalog used for autocomplete."""
    def __init__(self, bundled_path, user_path):
        self.bundled_path = Path(bundled_path)
        self.user_path = Path(user_path)
        self._lock = threading.Lock()
        self.items = set()
        self._load_file(self.bundled_path)
        self._load_file(self.user_path)

    def _extract_items(self, data):
        if isinstance(data, list):
            return [str(x).strip() for x in data if str(x).strip()]
        if isinstance(data, dict):
            if isinstance(data.get("items"), list):
                return [str(x).strip() for x in data["items"] if str(x).strip()]
        return []

    def _load_file(self, path):
        if not path.exists():
            return
        try:
            if path.suffix.lower() == ".json":
                data = json.loads(path.read_text(encoding="utf-8"))
                values = self._extract_items(data)
            else:
                values = [
                    line.strip()
                    for line in path.read_text(encoding="utf-8-sig").splitlines()
                    if line.strip()
                ]
            self.items.update(values)
        except Exception:
            pass

    @staticmethod
    def _norm(value):
        return re.sub(r"\s+", "", str(value or "")).casefold()

    def suggest(self, query, limit=30):
        query = str(query or "").strip()
        if not query:
            return []
        nq = self._norm(query)
        with self._lock:
            values = list(self.items)

        def score(name):
            nn = self._norm(name)
            if nn == nq:
                rank = 0
            elif nn.startswith(nq):
                rank = 1
            elif any(self._norm(part).startswith(nq) for part in name.split()):
                rank = 2
            elif nq in nn:
                rank = 3
            else:
                rank = 99
            return (rank, len(name), name)

        matched = [x for x in values if nq in self._norm(x)]
        matched.sort(key=score)
        return matched[:limit]

    def learn_many(self, names):
        clean = {
            str(name).strip()
            for name in (names or [])
            if name and str(name).strip()
        }
        if not clean:
            return 0

        changed = 0
        with self._lock:
            before = len(self.items)
            self.items.update(clean)
            changed = len(self.items) - before
            if changed:
                self.user_path.parent.mkdir(parents=True, exist_ok=True)
                payload = {
                    "updated_at": datetime.now().isoformat(timespec="seconds"),
                    "items": sorted(self.items),
                }
                tmp = self.user_path.with_suffix(".tmp")
                tmp.write_text(
                    json.dumps(payload, ensure_ascii=False, indent=2),
                    encoding="utf-8",
                )
                os.replace(tmp, self.user_path)
        return changed

    def import_file(self, path):
        path = Path(path)
        if not path.exists():
            return 0
        try:
            if path.suffix.lower() == ".json":
                data = json.loads(path.read_text(encoding="utf-8"))
                names = self._extract_items(data)
            else:
                names = [
                    line.strip()
                    for line in path.read_text(encoding="utf-8-sig").splitlines()
                    if line.strip()
                ]
        except Exception as e:
            raise ValueError(f"장비 목록 파일을 읽을 수 없습니다: {e}")
        return self.learn_many(names)

    def learn_from_cache(self, cache_dir):
        """Learn item_name values from existing cached item-equipment responses."""
        cache_dir = Path(cache_dir)
        if not cache_dir.exists():
            return 0
        found = set()

        def walk(obj):
            if isinstance(obj, dict):
                value = obj.get("item_name")
                if value:
                    found.add(str(value).strip())
                for child in obj.values():
                    walk(child)
            elif isinstance(obj, list):
                for child in obj:
                    walk(child)

        for path in cache_dir.glob("*.json"):
            try:
                data = json.loads(path.read_text(encoding="utf-8"))
                if "item-equipment" not in str(data.get("url", "")):
                    continue
                walk(data.get("data"))
            except Exception:
                continue
        return self.learn_many(found)

    def __len__(self):
        with self._lock:
            return len(self.items)


class AutocompleteEntry(tk.Frame):
    def __init__(self, parent, variable, suggestion_func, on_select=None,
                 bg="#121925", max_rows=8):
        super().__init__(parent, bg=bg)
        self.variable = variable
        self.suggestion_func = suggestion_func
        self.on_select = on_select
        self.max_rows = max_rows
        self._trace_lock = False
        self.current = []

        self.entry = ttk.Entry(self, textvariable=variable)
        self.entry.pack(fill="x")

        self.listbox = tk.Listbox(
            self,
            height=1,
            bg="#0B111A",
            fg="#E6ECF5",
            selectbackground="#273650",
            selectforeground="#FFFFFF",
            borderwidth=1,
            relief="solid",
            highlightthickness=0,
            activestyle="none",
            font=("맑은 고딕", 9),
        )

        self.entry.bind("<KeyRelease>", self._on_keyrelease)
        self.entry.bind("<Down>", self._focus_list)
        self.entry.bind("<Escape>", lambda e: self.hide())
        self.entry.bind("<FocusOut>", self._delayed_hide)
        self.listbox.bind("<ButtonRelease-1>", self._choose_mouse)
        self.listbox.bind("<Return>", self._choose_keyboard)
        self.listbox.bind("<Escape>", lambda e: self.hide())
        self.listbox.bind("<FocusOut>", self._delayed_hide)

    def _on_keyrelease(self, event):
        if event.keysym in ("Up", "Down", "Return", "Escape", "Tab"):
            return
        self.refresh()

    def refresh(self):
        query = self.variable.get().strip()
        if not query:
            self.hide()
            return
        values = self.suggestion_func(query)
        if not values:
            self.hide()
            return

        self.current = values
        self.listbox.delete(0, "end")
        for value in values:
            self.listbox.insert("end", value)
        self.listbox.configure(height=min(self.max_rows, len(values)))
        if not self.listbox.winfo_ismapped():
            self.listbox.pack(fill="x", pady=(4, 0))

    def hide(self):
        if self.listbox.winfo_ismapped():
            self.listbox.pack_forget()

    def _focus_list(self, event=None):
        if not self.listbox.winfo_ismapped():
            self.refresh()
        if self.listbox.winfo_ismapped() and self.listbox.size():
            self.listbox.focus_set()
            self.listbox.selection_clear(0, "end")
            self.listbox.selection_set(0)
            self.listbox.activate(0)
            return "break"

    def _choose_index(self, index):
        if index < 0 or index >= len(self.current):
            return
        value = self.current[index]
        self.variable.set(value)
        self.hide()
        self.entry.icursor("end")
        self.entry.focus_set()
        if self.on_select:
            self.on_select(value)

    def _choose_mouse(self, event):
        sel = self.listbox.curselection()
        if sel:
            self._choose_index(sel[0])

    def _choose_keyboard(self, event):
        sel = self.listbox.curselection()
        if sel:
            self._choose_index(sel[0])
        return "break"

    def _delayed_hide(self, event=None):
        self.after(160, self._hide_if_unfocused)

    def _hide_if_unfocused(self):
        focus = self.focus_get()
        if focus not in (self.entry, self.listbox):
            self.hide()


class HoverTooltip:
    def __init__(self, widget, text, width=340):
        self.widget=widget
        self.text=text
        self.width=width
        self.tip=None
        widget.bind("<Enter>", self.show, add="+")
        widget.bind("<Leave>", self.hide, add="+")

    def show(self, event=None):
        if self.tip is not None:
            return
        try:
            x=self.widget.winfo_rootx()+self.widget.winfo_width()+8
            y=self.widget.winfo_rooty()
            self.tip=tk.Toplevel(self.widget)
            self.tip.wm_overrideredirect(True)
            self.tip.wm_geometry(f"+{x}+{y}")
            label=tk.Label(
                self.tip,
                text=self.text,
                justify="left",
                anchor="w",
                bg="#101A28",
                fg="#E7EEF8",
                relief="solid",
                borderwidth=1,
                padx=12,
                pady=10,
                wraplength=self.width,
                font=("맑은 고딕", 9),
            )
            label.pack()
        except Exception:
            self.tip=None

    def hide(self, event=None):
        if self.tip is not None:
            try:
                self.tip.destroy()
            except Exception:
                pass
            self.tip=None


class OptionConditionWidget(tk.Frame):
    """잠재/에디셔널 옵션 한 줄.

    잠재/에디셔널은 실제 옵션 한 줄과 정확히 일치시키는 검색만 지원한다.
    따라서 비교(이상/정확히/이하)는 두지 않고, 같은 표시명에서 %/수치 등을
    구분하기 위한 단위 선택만 노출한다.
    """
    def __init__(self, parent, mode, bg="#121925", max_rows=8):
        super().__init__(parent, bg=bg)
        self.mode=mode
        self.bg=bg
        self.type_var=tk.StringVar()
        self.unit_var=tk.StringVar()
        self.value_var=tk.StringVar()
        self.enabled=True

        self.grid_columnconfigure(0,weight=1,minsize=160)
        self.grid_columnconfigure(1,weight=0,minsize=62)
        self.grid_columnconfigure(2,weight=0,minsize=66)

        self.type_auto=AutocompleteEntry(
            self,
            self.type_var,
            lambda q:_family_suggestions(q, self.mode, limit=30),
            on_select=self._on_type_selected,
            bg=bg,
            max_rows=max_rows,
        )
        self.type_auto.grid(
            row=0,column=0,
            sticky="ew",padx=(0,5)
        )

        self.unit_combo=ttk.Combobox(
            self,
            textvariable=self.unit_var,
            values=[],
            state="readonly",
            width=6,
        )
        self.unit_combo.grid(
            row=0,column=1,
            sticky="ew",padx=(0,5)
        )

        self.value_entry=ttk.Entry(
            self,
            textvariable=self.value_var,
            width=7,
        )
        self.value_entry.grid(
            row=0,column=2,
            sticky="ew"
        )

        self._value_trace_lock=False
        self.type_var.trace_add("write", self._type_changed)
        self.unit_var.trace_add("write", self._unit_changed)
        self.value_var.trace_add("write", self._value_changed)

    def _on_type_selected(self, value):
        family=_resolve_family(self.mode, value)
        if family:
            self.type_var.set(family)
        self._sync_units()

    def _type_changed(self, *_):
        self.after_idle(self._sync_units)

    def _sync_units(self):
        family=_resolve_family(self.mode, self.type_var.get())
        units=_family_units(self.mode, family) if family else []
        self.unit_combo.configure(values=units)

        current=self.unit_var.get()
        if len(units)==1:
            if current!=units[0]:
                self.unit_var.set(units[0])
        elif current not in units:
            # If both a percentage and a flat numeric version exist
            # (e.g. STR 12% / STR +3), percent is the safer default.
            if "%" in units:
                self.unit_var.set("%")
            else:
                self.unit_var.set(units[0] if units else "")

        self._update_value_state()
        self.after_idle(self._enforce_value_limit)

    def _unit_changed(self, *_):
        self.after_idle(self._update_value_state)
        self.after_idle(self._enforce_value_limit)

    def _value_changed(self, *_):
        self.after_idle(self._enforce_value_limit)

    def _enforce_value_limit(self):
        """Clamp special potential values to values that can actually exist."""
        if self._value_trace_lock:
            return

        family=_resolve_family(self.mode, self.type_var.get())
        unit=self.unit_var.get()
        if not family or not unit:
            return

        d=_resolve_condition_def(self.mode, family, unit)
        if not d or d.get("key")!="cooldown":
            return

        raw=clean_text(self.value_var.get())
        if not raw:
            return

        try:
            value=float(raw)
        except Exception:
            return

        # Main potential can have up to 2 seconds.
        # Additional potential can have up to 1 second.
        limit=2 if self.mode=="potential" else 1
        if value <= limit:
            return

        try:
            self._value_trace_lock=True
            self.value_var.set(str(limit))
        finally:
            self._value_trace_lock=False

    def _update_value_state(self):
        if not self.enabled:
            self.value_entry.configure(state="disabled")
            return
        unit=self.unit_var.get()
        if unit=="값 없음":
            self.value_var.set("")
            self.value_entry.configure(state="disabled")
        elif unit:
            self.value_entry.configure(state="normal")
        else:
            self.value_entry.configure(state="disabled")

    def set_enabled(self, enabled, clear=False):
        self.enabled=bool(enabled)
        if clear:
            self.clear()
        state="normal" if enabled else "disabled"
        self.type_auto.entry.configure(state=state)
        if not enabled:
            self.type_auto.hide()
            self.unit_combo.configure(state="disabled")
            self.value_entry.configure(state="disabled")
        else:
            self.unit_combo.configure(state="readonly")
            self._sync_units()

    def clear(self):
        self.type_var.set("")
        self.unit_var.set("")
        self.value_var.set("")

    def get_condition(self, slot):
        raw_type=clean_text(self.type_var.get())
        raw_value=clean_text(self.value_var.get())
        raw_unit=clean_text(self.unit_var.get())

        # 종류와 수치가 모두 비어 있으면 '빈 옵션 행'으로 취급한다.
        # 단위 콤보에 이전/자동 선택값이 남아 있어도 검색 조건으로 보지 않는다.
        # 따라서 등급만 선택하고 모든 옵션 행을 비우면 잠재/에디셔널 없음 검색이 된다.
        if not raw_type and not raw_value:
            return None
        if not raw_type:
            raise ValueError(f"옵션 {slot+1}의 종류를 선택하세요.")

        family=_resolve_family(self.mode, raw_type)
        if not family:
            raise ValueError(f"옵션 {slot+1}의 종류를 확인하세요: {raw_type}")

        units=_family_units(self.mode, family)
        unit=raw_unit
        if not unit and len(units)==1:
            unit=units[0]
        if unit not in units:
            raise ValueError(f"옵션 {slot+1}의 단위를 선택하세요.")

        d=_resolve_condition_def(self.mode, family, unit)
        if not d:
            raise ValueError(f"옵션 {slot+1}의 종류/단위 조합을 확인하세요.")

        if unit=="값 없음":
            value=None
        else:
            if not raw_value:
                raise ValueError(f"옵션 {slot+1}의 수치를 입력하세요.")
            try:
                value=float(raw_value)
            except Exception:
                raise ValueError(f"옵션 {slot+1}의 수치는 숫자로 입력하세요.")

            if d.get("key")=="cooldown":
                limit=2 if self.mode=="potential" else 1
                if value > limit:
                    value=float(limit)
                    try:
                        self._value_trace_lock=True
                        self.value_var.set(str(limit))
                    finally:
                        self._value_trace_lock=False

        return {
            "slot":slot,
            "key":d["key"],
            "op":"정확히",
            "display":d.get("display") or d.get("label"),
            "kind":d.get("kind"),
            "unit":unit,
            "value":value,
        }



class VerticalScrolledFrame(tk.Frame):
    def __init__(self, parent, bg="#0B0F16"):
        super().__init__(parent, bg=bg)
        self.canvas=tk.Canvas(
            self,
            bg=bg,
            highlightthickness=0,
            borderwidth=0,
        )
        self.vbar=ttk.Scrollbar(
            self,
            orient="vertical",
            command=self.canvas.yview,
        )
        self.canvas.configure(yscrollcommand=self.vbar.set)
        self.canvas.pack(side="left", fill="both", expand=True)
        self.vbar.pack(side="right", fill="y")

        self.interior=tk.Frame(self.canvas, bg=bg)
        self._window=self.canvas.create_window(
            (0,0),
            window=self.interior,
            anchor="nw",
        )
        self.interior.bind("<Configure>", self._on_interior_configure)
        self.canvas.bind("<Configure>", self._on_canvas_configure)

        # Mouse-wheel works while the pointer is over the scroll area,
        # even when an entry or combobox has keyboard focus.
        top=self.winfo_toplevel()
        top.bind_all("<MouseWheel>", self._on_mousewheel, add="+")
        top.bind_all("<Button-4>", self._on_linux_wheel, add="+")
        top.bind_all("<Button-5>", self._on_linux_wheel, add="+")

    def _on_interior_configure(self, event=None):
        try:
            self.canvas.configure(scrollregion=self.canvas.bbox("all"))
        except Exception:
            pass

    def _on_canvas_configure(self, event):
        try:
            self.canvas.itemconfigure(self._window, width=event.width)
        except Exception:
            pass

    def _pointer_inside(self):
        try:
            x=self.canvas.winfo_pointerx()
            y=self.canvas.winfo_pointery()
            left=self.canvas.winfo_rootx()
            top=self.canvas.winfo_rooty()
            return (
                left <= x <= left+self.canvas.winfo_width()
                and top <= y <= top+self.canvas.winfo_height()
            )
        except Exception:
            return False

    def _on_mousewheel(self, event):
        if not self._pointer_inside():
            return
        delta=event.delta
        if not delta:
            return
        step=-1 if delta>0 else 1
        if abs(delta)>=120:
            step=int(-delta/120)
        self.canvas.yview_scroll(step, "units")

    def _on_linux_wheel(self, event):
        if not self._pointer_inside():
            return
        self.canvas.yview_scroll(-1 if event.num==4 else 1, "units")

    def scroll_to_top(self):
        self.canvas.yview_moveto(0)


class NexonApiError(RuntimeError):
    def __init__(self, status, code, api_message, url):
        self.status = int(status or 0)
        self.code = str(code or "")
        self.api_message = str(api_message or "")
        self.url = str(url or "")
        friendly = {
            "OPENAPI00001": "NEXON Open API 서버 내부 오류입니다.",
            "OPENAPI00002": "이 API를 호출할 권한이 없습니다.",
            "OPENAPI00003": "유효하지 않은 식별자이거나 해당 시점의 데이터가 없습니다.",
            "OPENAPI00004": "요청 파라미터가 누락되었거나 올바르지 않습니다.",
            "OPENAPI00005": "API Key가 유효하지 않습니다.",
            "OPENAPI00006": "게임 또는 API 경로가 올바르지 않습니다.",
            "OPENAPI00007": "API 호출 허용량을 초과했습니다.",
            "OPENAPI00009": "NEXON에서 데이터를 준비 중입니다.",
            "OPENAPI00010": "메이플스토리가 점검 중입니다.",
            "OPENAPI00011": "NEXON Open API가 점검 중입니다.",
        }.get(self.code, "NEXON Open API 요청에 실패했습니다.")
        extra = f" ({self.api_message})" if self.api_message else ""
        super().__init__(f"{friendly}{extra} [HTTP {self.status} {self.code}]".strip())


def _cache_saved_datetime(wrapper, path):
    raw = str((wrapper or {}).get("saved_at") or "").strip()
    if raw:
        try:
            dt = datetime.fromisoformat(raw)
            if dt.tzinfo is not None:
                return dt.astimezone().replace(tzinfo=None)
            return dt
        except Exception:
            pass
    try:
        return datetime.fromtimestamp(path.stat().st_mtime)
    except Exception:
        return None


def purge_expired_api_cache(cache_dir, max_age_days=CACHE_MAX_AGE_DAYS):
    cache_dir = Path(cache_dir)
    if not cache_dir.exists():
        return 0
    cutoff = datetime.now() - timedelta(days=max_age_days)
    removed = 0
    for p in cache_dir.glob("*.json"):
        try:
            with p.open("r", encoding="utf-8") as f:
                wrapper = json.load(f)
            saved = _cache_saved_datetime(wrapper, p)
            if saved is None or saved < cutoff:
                p.unlink(missing_ok=True)
                removed += 1
        except Exception:
            # Corrupt cache entries are safer to discard than reuse.
            try:
                p.unlink(missing_ok=True)
                removed += 1
            except Exception:
                pass
    return removed


class AdaptiveApiClient:
    """
    Long-run API client.

    429 policy:
    - 429 never becomes a fatal error by itself.
    - If Retry-After exists, respect it.
    - Otherwise use increasingly long cooldowns.
    - User can always stop from the GUI.

    Cache policy:
    - /id responses: persistent cache (OCID mapping is reused).
    - Responses with a past 'date' parameter: persistent cache.
    - Current-day/no-date game data is not persistently cached.
    """
    def __init__(
        self,
        api_key,
        cancel_event,
        log_cb=None,
        base_interval=0.75,
        cache_dir=None,
        cooldown_cb=None,
        pause_event=None,
        minimum_interval=0.25,
    ):
        self.api_key = api_key
        self.cancel_event = cancel_event
        self.pause_event = pause_event
        self.log_cb = log_cb or (lambda x: None)
        self.cooldown_cb = cooldown_cb or (lambda seconds: None)

        self.minimum_interval = max(0.01, float(minimum_interval))
        self.base_interval = max(self.minimum_interval, float(base_interval))
        self.current_interval = self.base_interval
        self.max_interval = 5.0
        self._last_request_time = 0.0
        self.success_streak = 0
        self.total_429 = 0
        self.consecutive_429 = 0

        self.cache_dir = Path(cache_dir) if cache_dir else None
        if self.cache_dir:
            self.cache_dir.mkdir(parents=True, exist_ok=True)
        self.cache_hits = 0
        self.cache_writes = 0

    def check_cancel(self):
        if self.cancel_event.is_set():
            raise InterruptedError("사용자가 검색을 중지했습니다.")

        # The long-running main search can be cooperatively paused while a
        # character-detail request gets API priority.  This does not discard
        # the current checkpoint or worker state.
        while self.pause_event is not None and self.pause_event.is_set():
            if self.cancel_event.is_set():
                raise InterruptedError("사용자가 검색을 중지했습니다.")
            time.sleep(0.10)

    def _pace(self):
        # Application-wide request pacing.
        #
        # IMPORTANT: never hold the global lock while waiting or while a
        # pause_event is active.  The long-running scan may be paused while a
        # detail window gets priority; if it held this lock during that pause,
        # the detail worker would be unable to make its own API request.
        global _GLOBAL_API_LAST_REQUEST

        while True:
            # Pause-aware check happens OUTSIDE the global lock.
            self.check_cancel()

            with _GLOBAL_API_PACE_LOCK:
                # Inside the lock only check hard cancellation; do not enter
                # the pause loop here.
                if self.cancel_event.is_set():
                    raise InterruptedError("사용자가 검색을 중지했습니다.")

                now = time.monotonic()
                wait = self.current_interval - (now - _GLOBAL_API_LAST_REQUEST)

                if wait <= 0:
                    _GLOBAL_API_LAST_REQUEST = now
                    self._last_request_time = now
                    return

            # Sleep outside the lock.  If the main search becomes paused while
            # sleeping, check_cancel() can wait without blocking detail calls.
            end = time.monotonic() + wait
            while True:
                self.check_cancel()
                remaining = end - time.monotonic()
                if remaining <= 0:
                    break
                time.sleep(min(0.05, remaining))

    def _sleep_cancelable(self, seconds):
        seconds = max(0.0, float(seconds))
        end = time.monotonic() + seconds
        last_report = None

        while True:
            self.check_cancel()
            remaining = end - time.monotonic()
            if remaining <= 0:
                self.cooldown_cb(0)
                return

            shown = int(remaining + 0.999)
            if shown != last_report:
                self.cooldown_cb(shown)
                last_report = shown

            time.sleep(min(1.0, remaining))

    def _on_success(self):
        was_limited = self.consecutive_429 > 0
        self.consecutive_429 = 0
        self.success_streak += 1

        if was_limited:
            self.log_cb("API 제한 해제 확인. 검색을 자동 재개합니다.")

        # After a long stable streak, gently return toward user's base interval.
        if self.success_streak >= 40 and self.current_interval > self.base_interval:
            old = self.current_interval
            self.current_interval = max(
                self.base_interval,
                self.current_interval * 0.90,
            )
            self.success_streak = 0
            if old - self.current_interval >= 0.10:
                self.log_cb(
                    f"API 호출 간격 완화: {old:.2f}초 → "
                    f"{self.current_interval:.2f}초"
                )

    def _cooldown_seconds(self, retry_after):
        if retry_after is not None:
            return max(1.0, float(retry_after))

        # Conservative schedule when Nexon does not provide a reset time.
        schedule = [10, 30, 60, 120, 300, 600, 900]
        idx = min(max(self.consecutive_429 - 1, 0), len(schedule) - 1)
        return float(schedule[idx])

    def _cacheable(self, path, params):
        if not self.cache_dir:
            return False

        # Character name -> OCID is especially useful to keep.
        if path == "id":
            return True

        params = params or {}
        date = params.get("date")
        if not date:
            return False

        try:
            requested = datetime.strptime(str(date), "%Y-%m-%d").date()
            return requested < datetime.now(KST).date()
        except Exception:
            return False

    def _cache_path(self, url):
        digest = hashlib.sha256(url.encode("utf-8")).hexdigest()
        return self.cache_dir / f"{digest}.json"

    def _read_cache(self, path, params, url):
        if not self._cacheable(path, params):
            return None
        p = self._cache_path(url)
        if not p.exists():
            return None
        try:
            with p.open("r", encoding="utf-8") as f:
                wrapper = json.load(f)
            if wrapper.get("url") != url:
                return None

            saved = _cache_saved_datetime(wrapper, p)
            cutoff = datetime.now() - timedelta(days=CACHE_MAX_AGE_DAYS)
            if saved is None or saved < cutoff:
                try:
                    p.unlink(missing_ok=True)
                except Exception:
                    pass
                return None

            self.cache_hits += 1
            return wrapper.get("data")
        except Exception:
            try:
                p.unlink(missing_ok=True)
            except Exception:
                pass
            return None

    def _write_cache(self, path, params, url, data):
        if not self._cacheable(path, params):
            return
        p = self._cache_path(url)
        tmp = p.with_suffix(".tmp")
        wrapper = {
            "saved_at": datetime.now().isoformat(timespec="seconds"),
            "url": url,
            "data": data,
        }
        try:
            with tmp.open("w", encoding="utf-8") as f:
                json.dump(wrapper, f, ensure_ascii=False)
            os.replace(tmp, p)
            self.cache_writes += 1
        except Exception:
            try:
                if tmp.exists():
                    tmp.unlink()
            except Exception:
                pass

    def get_json(self, path, params=None, retries=8, allow_missing=False):
        url = f"{BASE}/{path}"
        if params:
            url += "?" + urlencode(params)

        cached = self._read_cache(path, params, url)
        if cached is not None:
            return cached

        other_error_attempt = 0
        transient_delay = 1.0

        while True:
            self.check_cancel()
            self._pace()

            req = Request(
                url,
                headers={
                    "accept": "application/json",
                    "x-nxopen-api-key": self.api_key,
                    "User-Agent": "MapleEquipmentFinderGUI/5.0",
                },
                method="GET",
            )

            try:
                with urlopen(req, timeout=30) as resp:
                    data = json.loads(resp.read().decode("utf-8"))
                    self._on_success()
                    self._write_cache(path, params, url, data)
                    return data

            except HTTPError as e:
                body = ""
                try:
                    body = e.read().decode("utf-8", "replace")
                except Exception:
                    pass

                code = ""
                api_message = ""
                try:
                    payload = json.loads(body) if body else {}
                    err = payload.get("error") or {}
                    code = str(err.get("name") or "")
                    api_message = str(err.get("message") or "")
                except Exception:
                    payload = {}

                body_lower = body.casefold()
                if code == "OPENAPI00005" or (
                    e.code in (400,401,403)
                    and (
                        "apikey is not valid" in body_lower
                        or "api key is not valid" in body_lower
                    )
                ):
                    raise RuntimeError("API_KEY_INVALID") from e

                if e.code == 429 or code == "OPENAPI00007":
                    self.total_429 += 1
                    self.consecutive_429 += 1
                    self.success_streak = 0

                    old_interval = self.current_interval
                    self.current_interval = min(
                        self.max_interval,
                        max(self.current_interval * 1.35, self.base_interval + 0.5),
                    )

                    retry_after = None
                    header = e.headers.get("Retry-After")
                    if header:
                        try:
                            retry_after = float(header)
                        except ValueError:
                            retry_after = None
                    wait = self._cooldown_seconds(retry_after)

                    if self.consecutive_429 == 1:
                        self.log_cb("API 호출량 제한(429) 감지. 요청을 멈추고 쿨다운합니다.")
                    elif self.consecutive_429 == 3:
                        self.log_cb("429가 계속되어 장기 쿨다운 모드로 전환합니다.")
                    source = "Retry-After" if retry_after is not None else "자동 쿨다운"
                    self.log_cb(
                        f"429 연속 {self.consecutive_429}회 / {source} {wait:.0f}초 / "
                        f"호출 간격 {old_interval:.2f}→{self.current_interval:.2f}초"
                    )
                    self._sleep_cancelable(wait)
                    continue

                # Since 2026-06-19, characters with no historical Open API
                # snapshot may return HTTP 400.  Historical callers that opt
                # into allow_missing treat only OPENAPI00003 as no-data.
                if allow_missing and code == "OPENAPI00003" and (params or {}).get("date"):
                    return None

                transient = (
                    500 <= e.code < 600
                    or code in ("OPENAPI00001", "OPENAPI00009", "OPENAPI00011")
                )
                if transient:
                    other_error_attempt += 1
                    if other_error_attempt < retries:
                        label = code or f"HTTP {e.code}"
                        self.log_cb(
                            f"API 임시 오류 {label}: {transient_delay:.1f}초 후 재시도"
                        )
                        self._sleep_cancelable(transient_delay)
                        transient_delay = min(transient_delay * 2, 30)
                        continue

                raise NexonApiError(e.code, code, api_message, url) from e

            except URLError as e:
                other_error_attempt += 1
                if other_error_attempt < retries:
                    self.log_cb(
                        f"네트워크 오류: {transient_delay:.1f}초 후 재시도"
                    )
                    self._sleep_cancelable(transient_delay)
                    transient_delay = min(transient_delay * 2, 30)
                    continue
                raise RuntimeError(f"네트워크 오류: {e}") from e

def iter_items(equipment_json, include_presets):
    keys = EQUIP_LIST_KEYS if include_presets else EQUIP_LIST_KEYS[:1]
    for label, key in keys:
        for item in equipment_json.get(key) or []:
            yield label, item


def item_matches(item, cfg):
    if not item_name_match(item.get("item_name"), cfg["item_name"], cfg["item_name_mode"]):
        return False

    if cfg["starforce"]:
        try:
            if int(item.get("starforce") or 0) != int(cfg["starforce"]):
                return False
        except ValueError:
            return False

    if not potential_group_match(
        item,
        "potential",
        cfg["potential_grade"],
        cfg.get("potential_conditions", []),
        cfg.get("potential_order", "순서 무관"),
        "potential",
    ):
        return False

    if not potential_group_match(
        item,
        "additional",
        cfg["additional_grade"],
        cfg.get("additional_conditions", []),
        cfg.get("additional_order", "순서 무관"),
        "additional",
    ):
        return False

    if not flame_match(item, cfg):
        return False
    return True


def make_result_row(candidate, source, item):
    return {
        "닉네임": candidate.get("character_name", ""),
        "월드": candidate.get("world_name", ""),
        "레벨": candidate.get("level", ""),
        "직업": candidate.get("class_name", ""),
        "길드": candidate.get("guild_name", ""),
        "랭킹": candidate.get("ranking", ""),
        "장비출처": source,
        "장비명": item.get("item_name", ""),
        "부위": item.get("item_equipment_slot", "") or item.get("item_equipment_part", ""),
        "스타포스": item.get("starforce", ""),
        "추가옵션": flame_summary(item),
        "잠재등급": item.get("potential_option_grade", ""),
        "잠재1": item.get("potential_option_1", ""),
        "잠재2": item.get("potential_option_2", ""),
        "잠재3": item.get("potential_option_3", ""),
        "에디등급": item.get("additional_potential_option_grade", ""),
        "에디1": item.get("additional_potential_option_1", ""),
        "에디2": item.get("additional_potential_option_2", ""),
        "에디3": item.get("additional_potential_option_3", ""),
        "추옵_STR": (item.get("item_add_option") or {}).get("str", "0"),
        "추옵_DEX": (item.get("item_add_option") or {}).get("dex", "0"),
        "추옵_INT": (item.get("item_add_option") or {}).get("int", "0"),
        "추옵_LUK": (item.get("item_add_option") or {}).get("luk", "0"),
        "추옵_MaxHP": (item.get("item_add_option") or {}).get("max_hp", "0"),
        "추옵_MaxMP": (item.get("item_add_option") or {}).get("max_mp", "0"),
        "추옵_공격력": (item.get("item_add_option") or {}).get("attack_power", "0"),
        "추옵_마력": (item.get("item_add_option") or {}).get("magic_power", "0"),
        "추옵_방어력": (item.get("item_add_option") or {}).get("armor", "0"),
        "추옵_이동속도": (item.get("item_add_option") or {}).get("speed", "0"),
        "추옵_점프력": (item.get("item_add_option") or {}).get("jump", "0"),
        "추옵_보스데미지": (item.get("item_add_option") or {}).get("boss_damage", "0"),
        "추옵_데미지": (item.get("item_add_option") or {}).get("damage", "0"),
        "추옵_올스탯": (item.get("item_add_option") or {}).get("all_stat", "0"),
        "추옵_착용레벨감소": (item.get("item_add_option") or {}).get("equipment_level_decrease", 0),
    }


class Checkpoint:
    def __init__(self, app_dir, cfg):
        self.cfg = cfg
        self.fp = search_fingerprint(cfg)
        self.dir = Path(app_dir) / "checkpoints"
        self.path = self.dir / f"{self.fp}.json"
        self.results_csv = self.dir / f"{self.fp}_results.csv"
        self.errors_txt = self.dir / f"{self.fp}_errors.txt"
        self.data = {
            "version": 3,
            "fingerprint": self.fp,
            "created_at": datetime.now().isoformat(timespec="seconds"),
            "updated_at": datetime.now().isoformat(timespec="seconds"),
            "config": {k:v for k,v in cfg.items() if k != "api_key"},
            "phase": "new",
            "candidates": [],
            "completed": {},   # key -> status
            "results": [],
            "errors": [],
        }

    def exists(self):
        return self.path.exists()

    def load(self):
        with self.path.open("r", encoding="utf-8") as f:
            self.data = json.load(f)
        return self.data

    def save(self):
        self.data["updated_at"] = datetime.now().isoformat(timespec="seconds")
        atomic_write_json(self.path, self.data)
        self._write_results_csv()
        self._write_errors()

    def discard_files(self):
        """Remove every persisted artifact for this search fingerprint."""
        removed = []
        for path in (self.path, self.results_csv, self.errors_txt):
            try:
                if path.exists():
                    path.unlink()
                    removed.append(str(path))
            except Exception:
                # Caller can still create an in-memory fresh checkpoint; any
                # remaining file will not be loaded unless resume=True.
                pass
        return removed

    def _write_results_csv(self):
        rows = self.data.get("results") or []
        self.results_csv.parent.mkdir(parents=True, exist_ok=True)
        fields = [
            "닉네임","월드","레벨","직업","길드","랭킹","장비출처","장비명","부위",
            "스타포스","추가옵션","잠재등급","잠재1","잠재2","잠재3",
            "에디등급","에디1","에디2","에디3",
            "추옵_STR","추옵_DEX","추옵_INT","추옵_LUK","추옵_MaxHP","추옵_MaxMP",
            "추옵_공격력","추옵_마력","추옵_방어력","추옵_이동속도","추옵_점프력",
            "추옵_보스데미지","추옵_데미지","추옵_올스탯","추옵_착용레벨감소"
        ]
        with self.results_csv.open("w", encoding="utf-8-sig", newline="") as f:
            w = csv.DictWriter(f, fieldnames=fields)
            w.writeheader()
            for row in rows:
                w.writerow({k: row.get(k, "") for k in fields})

    def _write_errors(self):
        self.errors_txt.parent.mkdir(parents=True, exist_ok=True)
        with self.errors_txt.open("w", encoding="utf-8") as f:
            for e in self.data.get("errors") or []:
                f.write(f"{e.get('character_name','')}\t{e.get('message','')}\n")

    @staticmethod
    def ckey(c):
        return f"{c.get('world_name','')}|{c.get('character_name','')}"

    def mark_completed(self, candidate, status, error=None):
        key = self.ckey(candidate)
        self.data["completed"][key] = {
            "status": status,
            "at": datetime.now().isoformat(timespec="seconds"),
        }
        if error:
            self.data["errors"].append({
                "character_name": candidate.get("character_name", ""),
                "world_name": candidate.get("world_name", ""),
                "message": error,
            })

    def is_completed(self, candidate):
        return self.ckey(candidate) in self.data.get("completed", {})


def collect_candidates(client, cfg, log_cb, progress_cb):
    selected_job = cfg["job"]
    api_filter = JOB_API_FILTER.get(selected_job) if selected_job != "전체" else None
    candidates = []
    seen = set()

    def run_pages(world_type, class_filter):
        rows_out = []
        for page in range(1, cfg["max_pages"] + 1):
            client.check_cancel()
            params = {"date": cfg["date"], "world_type": world_type, "page": page}
            if class_filter:
                params["class"] = class_filter

            try:
                data = client.get_json("ranking/overall", params)
            except RuntimeError as e:
                msg = str(e)
                api_code = getattr(e, "code", "")
                status = getattr(e, "status", 0)
                if page == 1 and class_filter and (api_code == "OPENAPI00004" or (status == 400 and not api_code)):
                    raise ValueError("CLASS_FILTER_INVALID") from e
                if page > 1 and (api_code in ("OPENAPI00003","OPENAPI00004") or (status == 400 and not api_code)):
                    log_cb(f"  page {page}: 더 이상 조회할 페이지가 없어 종료")
                    break
                raise

            ranking = data.get("ranking") or []
            if not ranking:
                break

            levels = []
            kept = 0
            for r in ranking:
                try:
                    lv = int(r.get("character_level", -1))
                except Exception:
                    continue
                levels.append(lv)

                if selected_job != "전체":
                    rank_class = clean_text(r.get("class_name"))
                    rank_sub = clean_text(r.get("sub_class_name"))
                    if selected_job not in (rank_class, rank_sub):
                        continue

                if cfg["min_level"] <= lv <= cfg["max_level"]:
                    key = (r.get("character_name"), r.get("world_name"))
                    if key in seen:
                        continue
                    seen.add(key)
                    rows_out.append({
                        "character_name": r.get("character_name", ""),
                        "world_name": r.get("world_name", ""),
                        "level": lv,
                        "class_name": clean_text(r.get("sub_class_name")) or clean_text(r.get("class_name")),
                        "guild_name": r.get("character_guildname") or "",
                        "ranking": r.get("ranking", ""),
                        "world_type": world_type,
                    })
                    kept += 1

            hi = max(levels) if levels else "?"
            lo = min(levels) if levels else "?"
            log_cb(f"  page {page}: Lv.{hi}~{lo} / 후보 +{kept}")
            progress_cb("rank", page, cfg["max_pages"])

            if levels and min(levels) < cfg["min_level"]:
                break

        return rows_out

    for world_type in cfg["world_types"]:
        label = "일반 월드" if world_type == 0 else "에오스/핼리오스"
        log_cb(f"\n[랭킹 수집] {label}")
        log_cb(f"직업 API 필터: {api_filter or '없음'}")
        try:
            candidates.extend(run_pages(world_type, api_filter))
        except ValueError as e:
            if str(e) != "CLASS_FILTER_INVALID":
                raise
            log_cb("[주의] 직업 API 필터가 거부되어 직업 필터 없이 조회 후 재필터링합니다.")
            candidates.extend(run_pages(world_type, None))

    candidates.sort(key=lambda x: (-x["level"], x["world_name"], x["character_name"]))
    return candidates


def scan_candidates(client, cfg, checkpoint, log_cb, progress_cb, result_cb, catalog_cb=None):
    candidates = checkpoint.data["candidates"]
    total = len(candidates)
    completed_before = sum(1 for c in candidates if checkpoint.is_completed(c))
    if completed_before:
        log_cb(f"이어하기: 이미 완료된 {completed_before}명은 건너뜁니다.")

    dirty = 0
    for idx, cand in enumerate(candidates, 1):
        client.check_cancel()

        if checkpoint.is_completed(cand):
            progress_cb("scan", idx, total)
            continue

        name = cand["character_name"]
        progress_cb("scan", idx, total)
        log_cb(f"[{idx}/{total}] {name} / {cand['world_name']} / Lv.{cand['level']}")

        try:
            ocid_data = client.get_json("id", {"character_name": name})
            ocid = ocid_data.get("ocid")
            if not ocid:
                checkpoint.mark_completed(cand, "no_ocid")
                log_cb("  - OCID 없음")
                dirty += 1
                continue

            equip_params = {"ocid": ocid}
            if not cfg.get("character_realtime"):
                equip_params["date"] = cfg["date"]
            equip = client.get_json(
                "character/item-equipment",
                equip_params,
                allow_missing=not cfg.get("character_realtime"),
            )
            if equip is None:
                checkpoint.mark_completed(cand, "no_historical_data")
                log_cb("  - 해당 날짜의 캐릭터 장비 데이터 없음")
                dirty += 1
                continue

            # Every fetched equipment name becomes future autocomplete data.
            if catalog_cb:
                try:
                    catalog_cb([
                        item.get("item_name")
                        for _, item in iter_items(equip, True)
                        if item.get("item_name")
                    ])
                except Exception:
                    pass

            matched_here = 0
            dedupe = set()
            for source, item in iter_items(equip, cfg["include_presets"]):
                if not item_matches(item, cfg):
                    continue
                key = (
                    item.get("item_name"), item.get("starforce"), item.get("potential_option_grade"),
                    item.get("potential_option_1"), item.get("potential_option_2"), item.get("potential_option_3"),
                    item.get("additional_potential_option_grade"),
                    item.get("additional_potential_option_1"), item.get("additional_potential_option_2"),
                    item.get("additional_potential_option_3"),
                )
                if key in dedupe:
                    continue
                dedupe.add(key)

                row = make_result_row(cand, source, item)
                checkpoint.data["results"].append(row)
                result_cb(row)
                matched_here += 1

            checkpoint.mark_completed(cand, "matched" if matched_here else "no_match")
            log_cb(f"  >>> 일치 {matched_here}건" if matched_here else "  -")
            dirty += 1

        except InterruptedError:
            raise
        except Exception as e:
            msg = str(e).splitlines()[0][:400]
            checkpoint.mark_completed(cand, "error", error=msg)
            log_cb(f"  [조회 오류] {msg}")
            dirty += 1

        # Save frequently; at most ~3 characters of work are lost on power-off/crash.
        if dirty >= 3:
            checkpoint.data["phase"] = "scanning"
            checkpoint.save()
            dirty = 0

    checkpoint.data["phase"] = "done"
    checkpoint.save()
    return checkpoint.data["results"]



DETAIL_HISTORY_START = OPENAPI_HISTORY_START


def _active_item_equipment(equip_json):
    """Return the actual/current equipment list, not every preset."""
    return list((equip_json or {}).get("item_equipment") or [])


def _cash_item_list(cash_json):
    """
    Return the currently represented cash-equipment items.
    Prefer the active preset if preset_no is supplied; otherwise use base.
    """
    data=cash_json or {}
    try:
        preset=int(data.get("preset_no") or 0)
    except Exception:
        preset=0

    if preset in (1,2,3):
        keys=[
            f"cash_item_equipment_preset_{preset}",
            f"additional_cash_item_equipment_preset_{preset}",
        ]
    else:
        keys=[
            "cash_item_equipment_base",
            "additional_cash_item_equipment_base",
        ]

    items=[]
    for key in keys:
        for item in data.get(key) or []:
            name=clean_text(item.get("cash_item_name"))
            if not name:
                continue
            items.append({
                "part":clean_text(item.get("cash_item_equipment_part")),
                "name":name,
                "icon":clean_text(item.get("cash_item_icon")),
            })
    return items


def _cash_summary(cash_json, limit=8):
    items=_cash_item_list(cash_json)
    names=[x["name"] for x in items]
    if not names:
        return "코디 아이템 정보 없음"
    if len(names)>limit:
        return " · ".join(names[:limit]) + f" 외 {len(names)-limit}개"
    return " · ".join(names)


def _potential_summary(item, additional=False):
    if additional:
        grade=clean_text(item.get("additional_potential_option_grade"))
        lines=[
            clean_text(item.get("additional_potential_option_1")),
            clean_text(item.get("additional_potential_option_2")),
            clean_text(item.get("additional_potential_option_3")),
        ]
    else:
        grade=clean_text(item.get("potential_option_grade"))
        lines=[
            clean_text(item.get("potential_option_1")),
            clean_text(item.get("potential_option_2")),
            clean_text(item.get("potential_option_3")),
        ]
    lines=[x for x in lines if x]
    if not grade and not lines:
        return "-"
    parts=[]
    if grade:
        parts.append(grade)
    if lines:
        parts.append(" / ".join(lines))
    return " | ".join(parts)


def _equipment_detail_rows(equip_json):
    out=[]
    for item in _active_item_equipment(equip_json):
        out.append({
            "part":clean_text(item.get("item_equipment_part")),
            "name":clean_text(item.get("item_name")),
            "starforce":clean_text(item.get("starforce")) or "0",
            "flame":flame_summary(item),
            "potential":_potential_summary(item, False),
            "additional":_potential_summary(item, True),
        })
    return out


def _download_image_bytes(url):
    if not url:
        return None
    try:
        req=Request(
            url,
            headers={"User-Agent":"MapleEquipmentFinderGUI/5.0"},
            method="GET",
        )
        with urlopen(req, timeout=6) as resp:
            data=resp.read(2_000_000)
        return data
    except Exception:
        return None


class App(tk.Tk):
    # Palette
    BG = "#0B0F16"
    PANEL = "#121925"
    PANEL_2 = "#172131"
    PANEL_3 = "#0F1621"
    BORDER = "#263247"
    TEXT = "#F4F7FB"
    MUTED = "#9EABBE"
    ACCENT = "#6DA8FF"
    ACCENT_DARK = "#4C7BFF"
    BLUE = "#7EA5FF"
    GREEN = "#68D69A"
    DANGER = "#FF7F8A"

    def __init__(self):
        super().__init__()
        self.title("메이플 장비 검색기 1.2.1")
        self.geometry("1600x940")
        self.minsize(1120, 760)
        self.configure(bg=self.BG)

        script_dir = Path(__file__).resolve().parent
        self.app_dir = script_dir.parent if script_dir.name.lower() == "resources" else script_dir

        self.catalog = EquipmentCatalog(
            self.app_dir / "Resources" / "equipment_catalog.json",
            self.app_dir / "data" / "equipment_catalog_user.json",
        )
        self.potential_catalog = OptionCatalog(OPTION_TYPE_DEFS["potential"])
        self.additional_catalog = OptionCatalog(OPTION_TYPE_DEFS["additional"])
        self.flame_catalog = FlameCatalog()
        try:
            purge_expired_api_cache(self.app_dir / "api_cache")
        except Exception:
            pass
        try:
            self.catalog.learn_from_cache(self.app_dir / "api_cache")
        except Exception:
            pass

        # Window/taskbar icon
        try:
            icon_file = self.app_dir / "Resources" / "app_icon.png"
            self.window_icon = tk.PhotoImage(file=str(icon_file))
            self.iconphoto(True, self.window_icon)
        except Exception:
            self.window_icon = None
        self.event_q = queue.Queue()
        self.cancel_event = threading.Event()
        self.search_pause_event = threading.Event()
        self.worker = None
        self.results = []
        self.last_cfg = None
        self.last_search_progress_text = "대기"

        # Detail windows temporarily take API priority over the long-running
        # scan.  As long as at least one priority detail is open, the main
        # search stays paused unless the user explicitly presses 검색 재개.
        self.detail_windows = {}
        self.detail_cancel_events = {}
        self.priority_detail_tokens = set()
        self.detail_pause_override = False
        self.active_detail_token = None

        self._make_vars()
        self._configure_styles()
        self._build_ui()
        self._install_global_combobox_wheel_lock()
        self._load_defaults()
        self.after(100, self._poll_events)

    def _install_global_combobox_wheel_lock(self):
        # One rule for every ttk.Combobox in the entire application:
        # the mouse wheel can scroll a page but never change the selected value.
        self.bind_class("TCombobox", "<MouseWheel>", self._global_combo_mousewheel)
        self.bind_class("TCombobox", "<Button-4>", self._global_combo_linux_wheel)
        self.bind_class("TCombobox", "<Button-5>", self._global_combo_linux_wheel)

    def _global_combo_mousewheel(self, event):
        try:
            if (
                hasattr(self, "search_scroller")
                and event.widget.winfo_toplevel() is self
            ):
                self.search_scroller._on_mousewheel(event)
        except Exception:
            pass
        return "break"

    def _global_combo_linux_wheel(self, event):
        try:
            if (
                hasattr(self, "search_scroller")
                and event.widget.winfo_toplevel() is self
            ):
                self.search_scroller._on_linux_wheel(event)
        except Exception:
            pass
        return "break"

    def _make_vars(self):
        self.api_key_var = tk.StringVar()
        self.show_key_var = tk.BooleanVar(value=False)
        self.date_var = tk.StringVar(value=yesterday_kst())
        self.min_level_var = tk.StringVar(value="295")
        self.max_level_var = tk.StringVar(value="295")
        self.job_group_var = tk.StringVar(value="전체")
        self.job_var = tk.StringVar(value="전체")
        self.world_normal_var = tk.BooleanVar(value=True)
        self.world_reboot_var = tk.BooleanVar(value=True)
        self.include_presets_var = tk.BooleanVar(value=True)

        self.item_name_var = tk.StringVar(value="")
        self.item_name_mode_var = tk.StringVar(value="정확히 일치")
        self.starforce_var = tk.StringVar(value="")
        self.pot_grade_var = tk.StringVar(value="미적용")
        self.potential_order_var = tk.StringVar(value="순서 무관")
        self.pot_vars = [tk.StringVar() for _ in range(3)]
        self.add_grade_var = tk.StringVar(value="미적용")
        self.additional_order_var = tk.StringVar(value="순서 무관")
        self.add_vars = [tk.StringVar() for _ in range(3)]
        self.flame_presence_var = tk.StringVar(value="미적용")
        self.flame_type_vars = [tk.StringVar() for _ in range(4)]
        self.flame_unit_vars = [tk.StringVar() for _ in range(4)]
        self.flame_value_vars = [tk.StringVar() for _ in range(4)]

        self.base_interval_var = tk.StringVar(value="0.75")
        self.max_pages_var = tk.StringVar(value="300")
        self.status_var = tk.StringVar(value="대기")
        self.count_var = tk.StringVar(value="0")
        self.progress_var = tk.DoubleVar(value=0.0)
        self.progress_percent_var = tk.StringVar(value="0%")

    def _configure_styles(self):
        style = ttk.Style(self)
        try:
            style.theme_use("clam")
        except Exception:
            pass

        style.configure(".", font=("맑은 고딕", 9))
        style.configure("App.TFrame", background=self.BG)
        style.configure("Sidebar.TFrame", background="#0D131D")
        style.configure("Card.TFrame", background=self.PANEL, relief="flat")
        style.configure("Card2.TFrame", background=self.PANEL_2, relief="flat")
        style.configure("Toolbar.TFrame", background=self.PANEL_3)

        style.configure("TLabel", background=self.BG, foreground=self.TEXT)
        style.configure("Title.TLabel", background=self.BG, foreground=self.TEXT,
                        font=("맑은 고딕", 22, "bold"))
        style.configure("Sub.TLabel", background=self.BG, foreground=self.MUTED,
                        font=("맑은 고딕", 9))
        style.configure("CardTitle.TLabel", background=self.PANEL_2, foreground="#EAF3FF",
                        font=("맑은 고딕", 12, "bold"))
        style.configure("CardText.TLabel", background=self.PANEL, foreground=self.MUTED)
        style.configure("SidebarTitle.TLabel", background="#0D131D", foreground=self.TEXT,
                        font=("맑은 고딕", 13, "bold"))
        style.configure("SidebarText.TLabel", background="#0D131D", foreground=self.MUTED)
        style.configure("Metric.TLabel", background=self.PANEL_2, foreground=self.TEXT,
                        font=("맑은 고딕", 18, "bold"))
        style.configure("MetricLabel.TLabel", background=self.PANEL_2, foreground=self.MUTED,
                        font=("맑은 고딕", 8))

        style.configure(
            "TEntry",
            fieldbackground="#08111E",
            foreground="#EAF2FF",
            insertcolor="#F4F8FF",
            bordercolor="#2B4F83",
            lightcolor="#2B4F83",
            darkcolor="#2B4F83",
            padding=8,
        )
        style.configure(
            "TCombobox",
            fieldbackground="#08111E",
            background="#08111E",
            foreground="#EAF2FF",
            arrowcolor="#AFC8F6",
            bordercolor="#2B4F83",
            lightcolor="#2B4F83",
            darkcolor="#2B4F83",
            padding=7,
        )
        style.map(
            "TCombobox",
            fieldbackground=[("readonly", "#08111E")],
            foreground=[("readonly", self.TEXT)],
            selectbackground=[("readonly", "#08111E")],
            selectforeground=[("readonly", self.TEXT)],
        )

        style.configure("TCheckbutton", background=self.PANEL, foreground=self.TEXT)
        style.map("TCheckbutton", background=[("active", self.PANEL)])

        style.configure(
            "Accent.TButton",
            background="#63A9FF",
            foreground="#F8FBFF",
            borderwidth=1,
            bordercolor="#A9CDFF",
            focusthickness=0,
            padding=(18, 10),
            font=("맑은 고딕", 10, "bold"),
        )
        style.map(
            "Accent.TButton",
            background=[("active", "#84BBFF"), ("disabled", "#2A405F")],
            foreground=[("disabled", "#A9B8D3")],
        )
        style.configure(
            "Ghost.TButton",
            background="#0F203A",
            foreground="#E7F0FF",
            bordercolor="#284A7B",
            padding=(14, 10),
            font=("맑은 고딕", 9, "bold"),
        )
        style.map(
            "Ghost.TButton",
            background=[("active", "#173055"), ("disabled", "#16233A")],
            foreground=[("disabled", "#94A3BD")],
        )
        style.configure(
            "Danger.TButton",
            background="#33223F",
            foreground="#FFD8E8",
            bordercolor="#6B4C89",
            padding=(12, 9),
            font=("맑은 고딕", 9, "bold"),
        )
        style.map(
            "Danger.TButton",
            background=[("active", "#473057"), ("disabled", "#2A2231")],
            foreground=[("disabled", "#B4A2B3")],
        )

        style.configure(
            "App.Horizontal.TProgressbar",
            troughcolor="#18202D",
            background=self.ACCENT,
            bordercolor="#18202D",
            lightcolor=self.ACCENT,
            darkcolor=self.ACCENT,
            thickness=11,
        )

        style.configure(
            "App.Treeview",
            background="#0E151F",
            fieldbackground="#0E151F",
            foreground="#DFE6F1",
            bordercolor=self.BORDER,
            rowheight=29,
            font=("맑은 고딕", 8),
        )
        style.map("App.Treeview", background=[("selected", "#273650")])
        style.configure(
            "App.Treeview.Heading",
            background="#182231",
            foreground="#C8D2E0",
            relief="flat",
            font=("맑은 고딕", 8, "bold"),
            padding=(7, 7),
        )
        style.map("App.Treeview.Heading", background=[("active", "#202D40")])

        style.configure("App.TNotebook", background=self.BG, borderwidth=0)
        style.configure(
            "App.TNotebook.Tab",
            background="#111925",
            foreground=self.MUTED,
            padding=(15, 8),
            font=("맑은 고딕", 9, "bold"),
        )
        style.map(
            "App.TNotebook.Tab",
            background=[("selected", self.PANEL_2), ("active", "#172131")],
            foreground=[("selected", self.TEXT), ("active", self.TEXT)],
        )
        style.configure("Hidden.TNotebook", background=self.BG, borderwidth=0)
        style.layout("Hidden.TNotebook.Tab", [])

        style.configure(
            "HeaderNav.TButton",
            background="#0F1C32",
            foreground="#DEE9FB",
            borderwidth=1,
            bordercolor="#1F3B67",
            padding=(16, 10),
            font=("맑은 고딕", 9, "bold"),
        )
        style.map(
            "HeaderNav.TButton",
            background=[("active", "#162A48")],
            foreground=[("disabled", "#8394B0")],
        )
        style.configure(
            "HeaderNavActive.TButton",
            background="#2C7CFF",
            foreground="#FFFFFF",
            borderwidth=1,
            bordercolor="#95C5FF",
            padding=(16, 10),
            font=("맑은 고딕", 9, "bold"),
        )
        style.map(
            "HeaderNavActive.TButton",
            background=[("active", "#4E95FF")],
            foreground=[("disabled", "#D0D8E8")],
        )

    def _card(self, parent, title, subtitle=None):
        outer = tk.Frame(parent, bg=self.PANEL, highlightthickness=1,
                         highlightbackground="#1F3E69", bd=0)
        header = tk.Frame(outer, bg=self.PANEL_2)
        header.pack(fill="x", padx=0, pady=0)
        if subtitle:
            # 제목과 설명을 한 줄로 두고, 서로 다른 기존 폰트 크기는 그대로 유지합니다.
            # 동일한 위/아래 여백을 적용해 헤더 높이 기준 중앙에 오도록 정렬합니다.
            header_line = tk.Frame(header, bg=self.PANEL_2)
            header_line.pack(fill="x", padx=16, pady=0)
            tk.Label(
                header_line, text=title, bg=self.PANEL_2, fg="#EEF5FF",
                font=("맑은 고딕", 12, "bold")
            ).pack(side="left", pady=11)
            tk.Label(
                header_line, text=subtitle, bg=self.PANEL_2, fg="#AFC0D9",
                font=("맑은 고딕", 8)
            ).pack(side="left", padx=(12, 0), pady=11)
        else:
            tk.Label(
                header, text=title, bg=self.PANEL_2, fg="#EEF5FF",
                font=("맑은 고딕", 12, "bold")
            ).pack(anchor="w", padx=16, pady=(14, 12))
        body = tk.Frame(outer, bg=self.PANEL)
        body.pack(fill="both", expand=True, padx=16, pady=(14, 16))
        return outer, body

    def _field_label(self, parent, text, row, col, **kwargs):
        lbl = tk.Label(parent, text=text, bg=self.PANEL, fg=self.MUTED,
                       font=("맑은 고딕", 8, "bold"))
        lbl.grid(row=row, column=col, sticky="w", pady=(8, 3), **kwargs)
        return lbl

    def _build_ui(self):
        # Root grid
        self.grid_rowconfigure(0, weight=1)
        self.grid_columnconfigure(1, weight=1)

        # Sidebar
        sidebar = tk.Frame(self, bg="#09101B", width=350)
        sidebar.grid(row=0, column=0, sticky="nsw")
        sidebar.grid_propagate(False)

        brand = tk.Frame(sidebar, bg="#0D131D")
        brand.pack(fill="x", padx=14, pady=(16, 14))
        try:
            brand_file = self.app_dir / "Resources" / "brand_logo_sidebar.png"
            self.brand_logo = tk.PhotoImage(file=str(brand_file))
            tk.Label(
                brand,
                image=self.brand_logo,
                bg="#0D131D",
                bd=0,
            ).pack(anchor="center")
        except Exception:
            tk.Label(
                brand,
                text="메이플 장비 검색기",
                bg="#0D131D",
                fg=self.TEXT,
                font=("맑은 고딕", 11, "bold"),
            ).pack(anchor="center")

        sidebar_bottom = tk.Frame(sidebar, bg="#0D131D")
        sidebar_bottom.pack(side="bottom", fill="x", padx=16, pady=18)
        tk.Label(
            sidebar_bottom,
            text="Data based on NEXON Open API\n비공식 공개 장비 검색 도구",
            bg="#101823", fg=self.MUTED, justify="left",
            padx=12, pady=9, font=("맑은 고딕", 8)
        ).pack(fill="x")
        tk.Label(
            sidebar_bottom,
            text="Version 1.2.1",
            bg="#0D131D", fg="#5F6D82",
            font=("맑은 고딕", 7)
        ).pack(anchor="w", padx=4, pady=(6, 0))

        # Main
        main = tk.Frame(self, bg=self.BG)
        main.grid(row=0, column=1, sticky="nsew")
        main.grid_rowconfigure(3, weight=1)
        main.grid_columnconfigure(0, weight=1)

        # Header
        header = tk.Frame(main, bg=self.BG)
        header.grid(row=0, column=0, sticky="ew", padx=26, pady=(18, 12))

        self.header_watermark = None
        self.header_watermark_label = None

        title_wrap = tk.Frame(header, bg=self.BG)
        title_wrap.pack(side="left", fill="y")
        self.header_icon = None
        title_text = tk.Frame(title_wrap, bg=self.BG)
        title_text.pack(side="left")
        tk.Label(
            title_text,
            text="메이플 장비 검색기",
            bg=self.BG,
            fg=self.TEXT,
            font=("맑은 고딕", 18, "bold"),
            anchor="w",
        ).pack(anchor="w")
        tk.Label(
            title_text,
            text="Equipment Finder",
            bg=self.BG,
            fg="#C7D6EC",
            font=("맑은 고딕", 10),
            anchor="w",
        ).pack(anchor="w", pady=(2,0))

        self.header_decor = None
        self.header_decor_label = None

        nav = tk.Frame(header, bg=self.BG)
        nav.pack(side="left", padx=(48, 0))
        self.nav_search_btn = ttk.Button(nav, text="⌕ 검색 조건", style="HeaderNavActive.TButton", command=lambda: self._go_main_tab(0), width=10)
        self.nav_search_btn.pack(side="left", padx=(0, 8))
        self.nav_result_btn = ttk.Button(nav, text="▦ 검색 결과", style="HeaderNav.TButton", command=lambda: self._go_main_tab(1), width=10)
        self.nav_result_btn.pack(side="left", padx=8)
        self.nav_log_btn = ttk.Button(nav, text="≡ 진행 로그", style="HeaderNav.TButton", command=lambda: self._go_main_tab(2), width=10)
        self.nav_log_btn.pack(side="left", padx=8)
        self.nav_help_btn = ttk.Button(nav, text="? 도움말", style="HeaderNav.TButton", command=lambda: self._go_main_tab(3), width=8)
        self.nav_help_btn.pack(side="left", padx=(8,0))

        try:
            top_wm_file = self.app_dir / "Resources" / "top_right_header_blend.png"
            self.top_right_watermark = tk.PhotoImage(file=str(top_wm_file))
            self.top_right_watermark_label = tk.Label(main, image=self.top_right_watermark, bg=self.BG, bd=0)
            # 헤더 우측 배경에 은은하지만 분명히 보이도록 배치한다.
            # 버튼은 가리지 않고, 아래 API 박스가 하단 일부를 덮는 자연스러운 워터마크 구도다.
            self.top_right_watermark_label.place(relx=1.0, x=28, y=0, anchor="ne")
        except Exception:
            self.top_right_watermark = None
            self.top_right_watermark_label = None

        # API connection is mandatory but is not a search target condition.
        api_bar = tk.Frame(
            main, bg=self.PANEL, highlightthickness=1,
            highlightbackground="#1F3E69"
        )
        api_bar.grid(row=1, column=0, sticky="ew", padx=26, pady=(0, 14))
        api_bar.grid_columnconfigure(1, weight=1)

        self.header_watermark = None
        self.header_watermark_label = None

        api_head = tk.Frame(api_bar, bg=self.PANEL_2)
        api_head.grid(row=0, column=0, columnspan=4, sticky="ew")
        self.api_head_watermark = None
        self.api_head_watermark_label = None
        tk.Label(
            api_head, text="기본 설정", bg=self.PANEL_2, fg="#EEF5FF",
            font=("맑은 고딕", 12, "bold")
        ).pack(side="left", padx=(16, 10), pady=9)
        tk.Label(
            api_head,
            text="API Key와 기본 연결 상태를 설정합니다.",
            bg=self.PANEL_2, fg="#AFC0D9", font=("맑은 고딕", 8)
        ).pack(side="left", pady=9)

        tk.Label(
            api_bar, text="API 연결", bg=self.PANEL, fg=self.MUTED,
            font=("맑은 고딕", 8, "bold")
        ).grid(row=1, column=0, padx=(16, 12), pady=(14, 12), sticky="w")

        self.key_entry = ttk.Entry(
            api_bar, textvariable=self.api_key_var, show="●"
        )
        self.key_entry.grid(row=1, column=1, sticky="ew", pady=(12, 12))

        ttk.Checkbutton(
            api_bar, text="표시", variable=self.show_key_var,
            command=self._toggle_key
        ).grid(row=1, column=2, padx=(10, 8), sticky="w")

        tk.Label(
            api_bar,
            text="필수 · Key는 체크포인트에 저장하지 않습니다",
            bg=self.PANEL, fg=self.MUTED, font=("맑은 고딕", 8)
        ).grid(row=1, column=3, padx=(0, 16), sticky="e")

        # Metric cards removed for a cleaner, concept-focused layout.
        self.metric_level = None
        self.metric_job = None
        self.metric_mode = None

        # Notebook
        self.notebook = ttk.Notebook(main, style="Hidden.TNotebook")
        self.notebook.grid(row=3, column=0, sticky="nsew", padx=26, pady=(0, 10))

        search_tab = tk.Frame(self.notebook, bg=self.BG)
        result_tab = tk.Frame(self.notebook, bg=self.BG)
        log_tab = tk.Frame(self.notebook, bg=self.BG)
        help_tab = tk.Frame(self.notebook, bg=self.BG)
        self.search_tab = search_tab
        self.help_tab = help_tab
        self.notebook.add(search_tab, text="  검색 조건  ")
        self.notebook.add(result_tab, text="  결과  ")
        self.notebook.add(log_tab, text="  진행 로그  ")
        self.notebook.add(help_tab, text="  도움말  ")
        self.notebook.bind("<<NotebookTabChanged>>", self._on_main_notebook_changed, add="+")
        self._update_top_nav_buttons()

        # Search tab: real vertical scrolling for smaller windows.
        search_tab.grid_rowconfigure(0, weight=1)
        search_tab.grid_columnconfigure(0, weight=1)
        self.search_scroller=VerticalScrolledFrame(search_tab, bg=self.BG)
        self.search_scroller.grid(row=0, column=0, sticky="nsew")
        search_content=self.search_scroller.interior
        search_content.grid_columnconfigure(
            0, weight=1, uniform="search_pair"
        )
        search_content.grid_columnconfigure(
            1, weight=1, uniform="search_pair"
        )

        # Card: character search target
        card1, body1 = self._card(search_content, "1. 캐릭터 검색 조건", "캐릭터 범위와 직업을 지정합니다.")
        card1.grid(row=0, column=0, sticky="nsew", padx=(0, 7), pady=(10, 7))
        body1.grid_columnconfigure(1, weight=1)
        body1.grid_columnconfigure(3, weight=1)

        self._field_label(body1, "조회 날짜", 0, 0)
        date_wrap=tk.Frame(body1,bg=self.PANEL)
        date_wrap.grid(row=1,column=0,columnspan=2,sticky="ew",padx=(0,7))
        date_wrap.grid_columnconfigure(0,weight=1)

        self.date_entry=ttk.Entry(
            date_wrap,textvariable=self.date_var,width=14
        )
        self.date_entry.grid(row=0,column=0,sticky="ew")
        self.date_entry.bind(
            "<FocusOut>",
            lambda e:self._normalize_date_input(show_error=False)
        )
        self.date_entry.bind(
            "<Return>",
            lambda e:(self._normalize_date_input(show_error=True),"break")[1]
        )
        self.date_entry.bind(
            "<Double-Button-1>",
            lambda e:self._open_date_picker()
        )

        tk.Button(
            date_wrap,
            text="▦",
            command=self._open_date_picker,
            width=4,
            height=1,
            bg="#101A28",
            fg="#D3E5FA",
            activebackground="#203B59",
            activeforeground="#FFFFFF",
            relief="solid",
            bd=1,
            highlightthickness=0,
            padx=0,
            pady=0,
            cursor="hand2",
            font=("Segoe UI Symbol",11,"bold"),
        ).grid(row=0,column=1,padx=(5,0),ipadx=0,ipady=0)
        self._field_label(body1, "레벨 범위", 0, 2)
        level_wrap = tk.Frame(body1, bg=self.PANEL)
        level_wrap.grid(row=1, column=2, columnspan=2, sticky="ew")
        level_wrap.grid_columnconfigure(0, weight=1)
        level_wrap.grid_columnconfigure(2, weight=1)
        ttk.Entry(level_wrap, textvariable=self.min_level_var, width=8).grid(row=0, column=0, sticky="ew")
        tk.Label(level_wrap, text="~", bg=self.PANEL, fg=self.MUTED).grid(row=0, column=1, padx=7)
        ttk.Entry(level_wrap, textvariable=self.max_level_var, width=8).grid(row=0, column=2, sticky="ew")

        self._field_label(body1, "직업 대분류", 2, 0)
        self._field_label(body1, "세부 직업", 2, 2)
        self.group_combo = ttk.Combobox(
            body1,
            textvariable=self.job_group_var,
            values=["전체"] + list(JOB_GROUPS.keys()),
            state="readonly",
            width=14,
        )
        self.group_combo.grid(row=3, column=0, columnspan=2, sticky="ew", padx=(0, 7))
        self.group_combo.bind("<<ComboboxSelected>>", self._on_group_changed)

        self.job_combo = ttk.Combobox(
            body1,
            textvariable=self.job_var,
            state="readonly",
            width=14,
        )
        self.job_combo.grid(row=3, column=2, columnspan=2, sticky="ew")

        # Disable native combobox wheel selection.  When the pointer is over
        # either job selector, the wheel continues to scroll the search page.
        for combo in (self.group_combo, self.job_combo):
            combo.bind("<MouseWheel>", self._job_combo_mousewheel)
            combo.bind("<Button-4>", self._job_combo_linux_wheel)
            combo.bind("<Button-5>", self._job_combo_linux_wheel)

        self._field_label(body1, "월드 유형", 4, 0)
        world_wrap = tk.Frame(body1, bg=self.PANEL)
        world_wrap.grid(row=5, column=0, columnspan=4, sticky="w")
        ttk.Checkbutton(world_wrap, text="일반 월드", variable=self.world_normal_var).pack(side="left")
        ttk.Checkbutton(world_wrap, text="에오스 / 핼리오스", variable=self.world_reboot_var).pack(side="left", padx=(12, 0))
        ttk.Checkbutton(world_wrap, text="프리셋 1~3 포함", variable=self.include_presets_var).pack(side="left", padx=(12, 0))

        tk.Label(
            body1,
            text=(
                "Open API 조회 가능: 2023-12-21 이후  ·  "
                "오늘 랭킹은 09:30 KST 이후 조회 가능"
            ),
            bg=self.PANEL,
            fg="#D8A85D",
            font=("맑은 고딕", 8, "bold"),
            anchor="w",
            justify="left",
        ).grid(
            row=6, column=0, columnspan=4,
            sticky="w", pady=(10, 0)
        )

        tk.Label(
            body1,
            text=(
                "※ 2023-12-21 이후 Open API 데이터가 생성된 캐릭터 기준이며, "
                "당일 랭킹은 집계 상황에 따라 제공이 다소 지연될 수 있습니다."
            ),
            bg=self.PANEL,
            fg=self.MUTED,
            font=("맑은 고딕", 8),
            anchor="w",
            justify="left",
            wraplength=430,
        ).grid(
            row=7, column=0, columnspan=4,
            sticky="w", pady=(3, 0)
        )

        # Card: equipment
        card2, body2 = self._card(search_content, "2. 장비 검색 조건", "장비 이름과 강화 수치를 지정합니다.")
        card2.grid(row=0, column=1, sticky="nsew", padx=(7, 0), pady=(10, 7))
        body2.grid_columnconfigure(0, weight=7)
        body2.grid_columnconfigure(1, weight=3)

        self._field_label(body2, "장비명", 0, 0)
        self._field_label(body2, "일치 방식", 0, 1)
        self.item_autocomplete = AutocompleteEntry(
            body2,
            self.item_name_var,
            self._equipment_suggestions,
            on_select=self._equipment_selected,
            bg=self.PANEL,
            max_rows=8,
        )
        self.item_autocomplete.grid(row=1, column=0, sticky="ew", padx=(0, 7))
        ttk.Combobox(
            body2,
            textvariable=self.item_name_mode_var,
            values=["정확히 일치", "이름 포함"],
            state="readonly",
            width=11,
        ).grid(row=1,column=1,sticky="ew")

        self._field_label(body2, "스타포스", 2, 0)
        ttk.Entry(body2, textvariable=self.starforce_var).grid(row=3, column=0, sticky="ew", padx=(0, 7))
        tk.Label(body2, text="비우면 강화 수치는 제한 없이 검색합니다.",
                 bg=self.PANEL, fg=self.MUTED, font=("맑은 고딕", 8)).grid(row=3, column=1, sticky="w")

        catalog_bar = tk.Frame(body2, bg=self.PANEL)
        catalog_bar.grid(row=4, column=0, columnspan=2, sticky="ew", pady=(12, 0))
        catalog_bar.grid_columnconfigure(0, weight=1)
        self.catalog_status_label = tk.Label(
            catalog_bar,
            text=f"장비 자동완성 데이터 {len(self.catalog):,}개 · 검색할수록 자동 추가",
            bg=self.PANEL,
            fg=self.MUTED,
            font=("맑은 고딕", 8),
        )
        self.catalog_status_label.grid(row=0, column=0, sticky="w")
        ttk.Button(
            catalog_bar,
            text="장비 목록 추가",
            style="Ghost.TButton",
            command=self._import_equipment_catalog,
        ).grid(row=0, column=1, sticky="e")

        # Potential card
        card3, body3 = self._card(
            search_content,
            "잠재능력",
        )
        card3.grid(row=1, column=0, sticky="nsew", padx=(0, 7), pady=7)
        body3.grid_columnconfigure(0,weight=0,minsize=74)
        body3.grid_columnconfigure(1,weight=1)


        tk.Label(
            body3, text="등급", bg=self.PANEL, fg=self.MUTED,
            font=("맑은 고딕", 8, "bold")
        ).grid(row=0,column=0,sticky="w",pady=(0,3))
        self.pot_grade_combo=ttk.Combobox(
            body3,
            textvariable=self.pot_grade_var,
            values=GRADES,
            state="readonly",
            width=12,
        )
        self.pot_grade_combo.grid(row=1,column=0,sticky="ew",padx=(0,7))

        tk.Label(
            body3, text="옵션 순서", bg=self.PANEL, fg=self.MUTED,
            font=("맑은 고딕", 8, "bold")
        ).grid(row=0,column=1,sticky="w",pady=(0,3))
        self.pot_order_combo=ttk.Combobox(
            body3,
            textvariable=self.potential_order_var,
            values=["순서 무관","순서까지 일치"],
            state="disabled",
        )
        self.pot_order_combo.grid(row=1,column=1,sticky="ew")

        tk.Label(
            body3,
            text="미적용 = 검색 조건에서 제외 · 등급 선택 후 옵션 미입력 = 잠재능력이 없는 장비",
            bg=self.PANEL,
            fg=self.MUTED,
            font=("맑은 고딕", 8),
        ).grid(row=2,column=0,columnspan=2,sticky="w",pady=(8,7))

        tk.Label(
            body3,text="옵션",
            bg=self.PANEL,fg=self.MUTED,
            font=("맑은 고딕",8,"bold")
        ).grid(row=3,column=0,sticky="w",pady=(7,3),padx=(0,7))

        pot_head=tk.Frame(body3,bg=self.PANEL)
        pot_head.grid(row=3,column=1,sticky="ew",pady=(7,3))
        pot_head.grid_columnconfigure(0,weight=1,minsize=160)
        pot_head.grid_columnconfigure(1,weight=0,minsize=62)
        pot_head.grid_columnconfigure(2,weight=0,minsize=66)
        tk.Label(
            pot_head,text="종류",bg=self.PANEL,fg=self.MUTED,
            font=("맑은 고딕",8,"bold")
        ).grid(row=0,column=0,sticky="w")
        tk.Label(
            pot_head,text="단위",bg=self.PANEL,fg=self.MUTED,
            font=("맑은 고딕",8,"bold")
        ).grid(row=0,column=1,sticky="w",padx=(0,5))
        tk.Label(
            pot_head,text="수치",bg=self.PANEL,fg=self.MUTED,
            font=("맑은 고딕",8,"bold")
        ).grid(row=0,column=2,sticky="w")

        self.potential_rows=[]
        for i in range(3):
            tk.Label(
                body3,
                text=f"옵션 {i+1}",
                bg=self.PANEL,
                fg=self.TEXT,
                font=("맑은 고딕",8,"bold"),
            ).grid(row=4+i,column=0,sticky="w",pady=4,padx=(0,7))
            row=OptionConditionWidget(
                body3,"potential",bg=self.PANEL,max_rows=8
            )
            row.grid(row=4+i,column=1,sticky="ew",pady=4)
            row.set_enabled(False)
            self.potential_rows.append(row)

        # Additional potential
        card4, body4 = self._card(
            search_content,
            "에디셔널 잠재능력",
        )
        card4.grid(row=1, column=1, sticky="nsew", padx=(7, 0), pady=7)
        body4.grid_columnconfigure(0,weight=0,minsize=74)
        body4.grid_columnconfigure(1,weight=1)


        tk.Label(
            body4, text="등급", bg=self.PANEL, fg=self.MUTED,
            font=("맑은 고딕", 8, "bold")
        ).grid(row=0,column=0,sticky="w",pady=(0,3))
        self.add_grade_combo=ttk.Combobox(
            body4,
            textvariable=self.add_grade_var,
            values=GRADES,
            state="readonly",
            width=12,
        )
        self.add_grade_combo.grid(row=1,column=0,sticky="ew",padx=(0,7))

        tk.Label(
            body4, text="옵션 순서", bg=self.PANEL, fg=self.MUTED,
            font=("맑은 고딕", 8, "bold")
        ).grid(row=0,column=1,sticky="w",pady=(0,3))
        self.add_order_combo=ttk.Combobox(
            body4,
            textvariable=self.additional_order_var,
            values=["순서 무관","순서까지 일치"],
            state="disabled",
        )
        self.add_order_combo.grid(row=1,column=1,sticky="ew")

        tk.Label(
            body4,
            text="미적용 = 검색 조건에서 제외 · 등급 선택 후 옵션 미입력 = 에디셔널 잠재능력이 없는 장비",
            bg=self.PANEL,
            fg=self.MUTED,
            font=("맑은 고딕", 8),
        ).grid(row=2,column=0,columnspan=2,sticky="w",pady=(8,7))

        tk.Label(
            body4,text="옵션",
            bg=self.PANEL,fg=self.MUTED,
            font=("맑은 고딕",8,"bold")
        ).grid(row=3,column=0,sticky="w",pady=(7,3),padx=(0,7))

        add_head=tk.Frame(body4,bg=self.PANEL)
        add_head.grid(row=3,column=1,sticky="ew",pady=(7,3))
        add_head.grid_columnconfigure(0,weight=1,minsize=160)
        add_head.grid_columnconfigure(1,weight=0,minsize=62)
        add_head.grid_columnconfigure(2,weight=0,minsize=66)
        tk.Label(
            add_head,text="종류",bg=self.PANEL,fg=self.MUTED,
            font=("맑은 고딕",8,"bold")
        ).grid(row=0,column=0,sticky="w")
        tk.Label(
            add_head,text="단위",bg=self.PANEL,fg=self.MUTED,
            font=("맑은 고딕",8,"bold")
        ).grid(row=0,column=1,sticky="w",padx=(0,5))
        tk.Label(
            add_head,text="수치",bg=self.PANEL,fg=self.MUTED,
            font=("맑은 고딕",8,"bold")
        ).grid(row=0,column=2,sticky="w")

        self.additional_rows=[]
        for i in range(3):
            tk.Label(
                body4,
                text=f"옵션 {i+1}",
                bg=self.PANEL,
                fg=self.TEXT,
                font=("맑은 고딕",8,"bold"),
            ).grid(row=4+i,column=0,sticky="w",pady=4,padx=(0,7))
            row=OptionConditionWidget(
                body4,"additional",bg=self.PANEL,max_rows=8
            )
            row.grid(row=4+i,column=1,sticky="ew",pady=4)
            row.set_enabled(False)
            self.additional_rows.append(row)

        self.pot_grade_var.trace_add(
            "write", lambda *_: self._update_option_group_state("potential")
        )
        self.add_grade_var.trace_add(
            "write", lambda *_: self._update_option_group_state("additional")
        )

        # Right-side stack: advanced settings + search execution.
        # This keeps the execution card directly below advanced settings even when
        # the left-side additional-option card is much taller.
        right_stack = tk.Frame(search_content, bg=self.BG)
        right_stack.grid(
            row=2, column=1, sticky="nsew",
            padx=(7,0), pady=(7,7)
        )
        right_stack.grid_columnconfigure(0, weight=1)
        # 남는 높이는 검색 실행 카드가 채워 추가옵션 카드의 하단선과 맞춥니다.
        right_stack.grid_rowconfigure(1, weight=1)

        # Advanced settings - compact half-width card.
        card5, body5 = self._card(
            right_stack,
            "고급 설정",
            "대부분은 기본값 그대로 사용하면 됩니다.",
        )
        card5.grid(
            row=0, column=0,
            sticky="ew",
            padx=0,
            pady=(0,9),
        )
        body5.grid_columnconfigure(0,weight=1)
        body5.grid_columnconfigure(1,weight=1)

        self._field_label(body5,"API 호출 간격(초)",0,0)
        self._field_label(body5,"최대 랭킹 페이지",0,1)

        ttk.Entry(
            body5,textvariable=self.base_interval_var,width=10
        ).grid(row=1,column=0,sticky="ew",padx=(0,7))
        ttk.Entry(
            body5,textvariable=self.max_pages_var,width=10
        ).grid(row=1,column=1,sticky="ew")

        tk.Label(
            body5,
            text=(
                "429 발생 시 자동 대기하며 진행상황은 "
                "체크포인트에 저장됩니다."
            ),
            bg=self.PANEL,fg=self.MUTED,
            font=("맑은 고딕",8),
            justify="left",wraplength=360,
        ).grid(
            row=2,column=0,columnspan=2,
            sticky="w",pady=(15,8)
        )

        # Additional-option (flame) conditions are part of the main search form.
        flame_card, flame_body = self._card(
            search_content,
            "추가옵션",
        )
        flame_card.grid(
            row=2,column=0,
            sticky="nsew",
            padx=(0,7),
            pady=(7,7),
        )
        flame_body.grid_columnconfigure(0,weight=0,minsize=74)
        flame_body.grid_columnconfigure(1,weight=1)


        tk.Label(
            flame_body,
            text="적용 여부",
            bg=self.PANEL,
            fg=self.MUTED,
            font=("맑은 고딕",8,"bold"),
        ).grid(
            row=0,column=0,
            sticky="w",pady=(0,4)
        )

        self.flame_presence_combo=ttk.Combobox(
            flame_body,
            textvariable=self.flame_presence_var,
            values=["미적용","적용"],
            state="readonly",
            # 잠재/에디셔널 등급 콤보와 동일한 폭을 사용해
            # 옵션 표의 '종류' 시작 위치를 정확히 맞춘다.
            width=12,
        )
        self.flame_presence_combo.grid(
            row=1,column=0,
            sticky="w",padx=(0,7)
        )

        tk.Label(
            flame_body,
            text=(
                "미적용 = 검색 조건에서 제외\n"
                "적용 후 옵션 미입력 = 추가옵션이 없는 장비"
            ),
            bg=self.PANEL,
            fg=self.MUTED,
            font=("맑은 고딕",8),
            justify="left",
            anchor="w",
        ).grid(
            row=1,column=1,
            sticky="w"
        )

        tk.Label(
            flame_body,
            text="옵션",
            bg=self.PANEL,
            fg=self.MUTED,
            font=("맑은 고딕",8,"bold")
        ).grid(
            row=2,column=0,
            sticky="w",pady=(15,5),padx=(0,7)
        )

        flame_head=tk.Frame(flame_body,bg=self.PANEL)
        flame_head.grid(
            row=2,column=1,
            sticky="ew",pady=(15,5)
        )
        flame_head.grid_columnconfigure(0,weight=1,minsize=160)
        flame_head.grid_columnconfigure(1,weight=0,minsize=62)
        flame_head.grid_columnconfigure(2,weight=0,minsize=66)

        tk.Label(
            flame_head,text="종류",
            bg=self.PANEL,fg=self.MUTED,
            font=("맑은 고딕",8,"bold")
        ).grid(row=0,column=0,sticky="w")

        tk.Label(
            flame_head,text="단위",
            bg=self.PANEL,fg=self.MUTED,
            font=("맑은 고딕",8,"bold")
        ).grid(row=0,column=1,sticky="w",padx=(0,5))

        tk.Label(
            flame_head,text="수치",
            bg=self.PANEL,fg=self.MUTED,
            font=("맑은 고딕",8,"bold")
        ).grid(row=0,column=2,sticky="w")

        self.flame_autocomplete_widgets=[]
        self.flame_unit_combos=[]
        self.flame_value_entries=[]

        for i in range(4):
            tk.Label(
                flame_body,
                text=f"옵션 {i+1}",
                bg=self.PANEL,
                fg=self.TEXT,
                font=("맑은 고딕",8,"bold")
            ).grid(
                row=3+i,column=0,
                sticky="w",pady=4,padx=(0,7)
            )

            flame_row=tk.Frame(
                flame_body,bg=self.PANEL
            )
            flame_row.grid(
                row=3+i,column=1,
                sticky="ew",pady=4
            )
            flame_row.grid_columnconfigure(
                0,weight=1,minsize=160
            )
            flame_row.grid_columnconfigure(
                1,weight=0,minsize=62
            )
            flame_row.grid_columnconfigure(
                2,weight=0,minsize=66
            )

            ac=AutocompleteEntry(
                flame_row,
                self.flame_type_vars[i],
                self._flame_suggestions,
                on_select=lambda value, idx=i: self._on_flame_type_selected(idx, value),
                bg=self.PANEL,
                max_rows=7,
            )
            ac.grid(
                row=0,column=0,
                sticky="ew",padx=(0,5)
            )
            ac.entry.configure(
                state="disabled"
            )
            self.flame_autocomplete_widgets.append(ac)

            unit_combo=ttk.Combobox(
                flame_row,
                textvariable=self.flame_unit_vars[i],
                values=["%","수치"],
                state="disabled",
                # 잠재능력의 '단위' 콤보와 동일한 폭.
                width=6,
            )
            unit_combo.grid(
                row=0,column=1,
                sticky="ew",padx=(0,5)
            )
            self.flame_unit_combos.append(unit_combo)

            value_entry=ttk.Entry(
                flame_row,
                textvariable=self.flame_value_vars[i],
                width=7,
                state="disabled",
            )
            value_entry.grid(
                row=0,column=2,
                sticky="ew"
            )
            self.flame_value_entries.append(
                value_entry
            )


        for _idx, _var in enumerate(self.flame_type_vars):
            _var.trace_add(
                "write",
                lambda *_, idx=_idx: self.after_idle(
                    lambda idx=idx: self._sync_flame_unit(idx)
                ),
            )

        self.flame_presence_var.trace_add(
            "write", lambda *_: self._update_flame_group_state()
        )

        exec_card, exec_body = self._card(
            right_stack,
            "3. 검색 실행",
            "검색 시작/중지와 결과 저장을 관리합니다.",
        )
        exec_card.grid(row=1, column=0, sticky="nsew", padx=0, pady=(0, 0))
        exec_body.grid_columnconfigure(4, weight=1)
        # 검색 상태/진행률은 하단 고정 게이지에서 표시하므로 버튼 행만 카드 높이에 맞춰 배치합니다.
        exec_body.grid_rowconfigure(0, weight=1)

        self.start_btn = ttk.Button(exec_body, text="⌕ 검색 시작", style="Accent.TButton", command=self._start_search)
        self.start_btn.grid(row=0, column=0, padx=(0, 6), pady=(6,4), sticky="w")
        self.cancel_btn = ttk.Button(exec_body, text="■ 중지", style="Danger.TButton", command=self._cancel_search, state="disabled")
        self.cancel_btn.grid(row=0, column=1, padx=6, pady=(6,4), sticky="w")
        self.header_export_btn = ttk.Button(exec_body, text="⭳ CSV 저장", style="Ghost.TButton", command=self._export_csv)
        self.header_export_btn.grid(row=0, column=2, padx=(6, 6), pady=(6,4), sticky="w")
        self.reset_filters_btn = ttk.Button(
            exec_body,
            text="↺ 검색 조건 초기화",
            style="Ghost.TButton",
            command=self._reset_search_filters,
        )
        self.reset_filters_btn.grid(row=0, column=3, padx=(6, 10), pady=(6,4), sticky="w")

        # Results tab
        result_tab.grid_rowconfigure(1, weight=1)
        result_tab.grid_columnconfigure(0, weight=1)

        result_header = tk.Frame(result_tab, bg=self.BG)
        result_header.grid(row=0, column=0, sticky="ew", pady=(10, 8))
        tk.Label(result_header, text="일치 결과", bg=self.BG, fg=self.TEXT,
                 font=("맑은 고딕", 13, "bold")).pack(side="left")
        tk.Label(
            result_header,
            text="항목을 더블클릭하면 현재 장비 · 최근 코디 · 레벨 이력을 확인할 수 있습니다.",
            bg=self.BG, fg=self.MUTED, font=("맑은 고딕", 8)
        ).pack(side="left", padx=12)

        result_frame = tk.Frame(result_tab, bg=self.PANEL, highlightthickness=1,
                                highlightbackground=self.BORDER)
        result_frame.grid(row=1, column=0, sticky="nsew", pady=(0, 10))
        result_frame.grid_rowconfigure(0, weight=1)
        result_frame.grid_columnconfigure(0, weight=1)

        columns = (
            "닉네임","월드","레벨","직업","길드","장비명","스타포스","추가옵션",
            "잠재등급","잠재1","잠재2","잠재3",
            "에디등급","에디1","에디2","에디3","장비출처"
        )
        self.tree = ttk.Treeview(result_frame, columns=columns, show="headings",
                                 style="App.Treeview")
        widths = {
            "닉네임":110,"월드":80,"레벨":55,"직업":115,"길드":95,
            "장비명":185,"스타포스":65,"추가옵션":320,"잠재등급":75,
            "잠재1":185,"잠재2":185,"잠재3":185,
            "에디등급":75,"에디1":175,"에디2":175,"에디3":175,"장비출처":80,
        }
        for col in columns:
            self.tree.heading(col, text=col)
            self.tree.column(col, width=widths.get(col, 100), anchor="center")
        ybar = ttk.Scrollbar(result_frame, orient="vertical", command=self.tree.yview)
        xbar = ttk.Scrollbar(result_frame, orient="horizontal", command=self.tree.xview)
        self.tree.configure(yscrollcommand=ybar.set, xscrollcommand=xbar.set)
        self.tree.grid(row=0, column=0, sticky="nsew")
        ybar.grid(row=0, column=1, sticky="ns")
        xbar.grid(row=1, column=0, sticky="ew")
        self.tree.bind("<Double-1>", self._open_selected_character_detail)

        # Log tab
        log_tab.grid_rowconfigure(1, weight=1)
        log_tab.grid_columnconfigure(0, weight=1)

        log_header = tk.Frame(log_tab, bg=self.BG)
        log_header.grid(row=0, column=0, sticky="ew", pady=(10, 8))
        tk.Label(log_header, text="진행 로그", bg=self.BG, fg=self.TEXT,
                 font=("맑은 고딕", 13, "bold")).pack(side="left")
        tk.Label(log_header, text="429 대기 및 체크포인트 상태를 여기에서 확인합니다.",
                 bg=self.BG, fg=self.MUTED, font=("맑은 고딕", 8)).pack(side="left", padx=12)

        log_wrap = tk.Frame(log_tab, bg="#0A1018", highlightthickness=1,
                            highlightbackground=self.BORDER)
        log_wrap.grid(row=1, column=0, sticky="nsew", pady=(0, 10))
        self.log_text = tk.Text(
            log_wrap, wrap="word", bg="#0A1018", fg="#C8D2E0",
            insertbackground=self.TEXT, relief="flat", borderwidth=0,
            font=("Consolas", 9), padx=12, pady=12
        )
        log_scroll = ttk.Scrollbar(log_wrap, orient="vertical", command=self.log_text.yview)
        self.log_text.configure(yscrollcommand=log_scroll.set)
        self.log_text.pack(side="left", fill="both", expand=True)
        log_scroll.pack(side="right", fill="y")

        # Help tab - same main-page navigation flow as search/results/log.
        # No scrollbar: the full guide is intentionally kept within one page.
        help_tab.grid_rowconfigure(1, weight=1)
        help_tab.grid_columnconfigure(0, weight=1)

        help_header=tk.Frame(help_tab,bg=self.BG)
        help_header.grid(row=0,column=0,sticky="ew",pady=(10,8))
        tk.Label(
            help_header,text="도움말",bg=self.BG,fg=self.TEXT,
            font=("맑은 고딕",13,"bold")
        ).pack(side="left")
        tk.Label(
            help_header,text="사용 방법과 프로그램 정보를 확인할 수 있습니다.",
            bg=self.BG,fg=self.MUTED,font=("맑은 고딕",8)
        ).pack(side="left",padx=12)

        help_inner=tk.Frame(help_tab,bg=self.BG)
        help_inner.grid(row=1,column=0,sticky="nsew",pady=(0,10))
        help_inner.grid_columnconfigure(0,weight=1,uniform="help")
        help_inner.grid_columnconfigure(1,weight=1,uniform="help")
        help_inner.grid_rowconfigure(1,weight=1)

        help_head=tk.Frame(
            help_inner,bg=self.PANEL_2,highlightthickness=1,
            highlightbackground=self.BORDER
        )
        help_head.grid(row=0,column=0,columnspan=2,sticky="ew",pady=(0,10))
        tk.Label(
            help_head,text="메이플 장비 검색기",bg=self.PANEL_2,fg=self.TEXT,
            font=("맑은 고딕",16,"bold"),anchor="w"
        ).pack(fill="x",padx=16,pady=(12,1))
        tk.Label(
            help_head,text="Equipment Finder  ·  Version 1.2.1  ·  배포용",
            bg=self.PANEL_2,fg=self.MUTED,font=("맑은 고딕",9),anchor="w"
        ).pack(fill="x",padx=16,pady=(0,12))

        def help_section(title, text, row, col, colspan=1):
            card=tk.Frame(
                help_inner,bg=self.PANEL,highlightthickness=1,
                highlightbackground=self.BORDER
            )
            card.grid(
                row=row,column=col,columnspan=colspan,sticky="nsew",
                padx=(0,5) if col==0 and colspan==1 else ((5,0) if col==1 else 0),
                pady=(0,10)
            )
            tk.Label(
                card,text=title,bg=self.PANEL_2,fg=self.TEXT,
                font=("맑은 고딕",11,"bold"),anchor="w",padx=14,pady=9
            ).pack(fill="x")
            tk.Label(
                card,text=text,bg=self.PANEL,fg="#D7E2F2",
                font=("맑은 고딕",9),anchor="nw",justify="left",
                wraplength=510,padx=14,pady=11
            ).pack(fill="both",expand=True)

        help_section(
            "사용 방법",
            "1. 조회 날짜, 레벨, 직업, 월드와 장비 조건을 설정합니다.\n"
            "2. 잠재능력·에디셔널·추가옵션을 필요한 만큼 입력합니다.\n"
            "3. 검색 시작을 누르고 하단 진행률 게이지를 확인합니다.\n"
            "4. 결과에서 캐릭터를 더블클릭하면 상세 정보·타임라인·코디 기록을 볼 수 있습니다.\n"
            "5. 진행 로그에서 API 대기·체크포인트·검색 진행 내역을 확인합니다.\n"
            "6. 검색 조건 초기화 / CSV 저장으로 조건과 결과를 관리합니다.",
            1,0
        )
        help_section(
            "검색 조건 참고",
            "• 잠재능력/에디셔널: 미적용은 조건 제외, 등급 선택 후 옵션을 비우면 해당 잠재능력이 없는 장비를 찾습니다.\n\n"
            "• 추가옵션: 미적용은 조건 제외, 적용 후 옵션을 비우면 추가옵션이 없는 장비를 찾습니다.\n\n"
            "• 상세창의 타임라인과 코디 기록은 조회 개수를 직접 지정할 수 있습니다.",
            1,1
        )
        help_section(
            "프로그램 정보",
            "NEXON Open API 데이터를 이용하는 비공식 공개 장비 검색 도구입니다.  "
            "프로그램명: 메이플 장비 검색기  ·  버전: 1.2.1  ·  빌드: 배포용",
            2,0,2
        )

        # Footer - persistent search progress/status
        footer = tk.Frame(main, bg=self.PANEL_3, height=52)
        footer.grid(row=4, column=0, sticky="ew")
        footer.grid_columnconfigure(1, weight=1)

        tk.Label(
            footer,
            textvariable=self.status_var,
            bg=self.PANEL_3, fg="#B7C8E0",
            font=("맑은 고딕", 8, "bold"), anchor="w"
        ).grid(row=0,column=0,padx=(26,14),pady=(8,2),sticky="w")

        tk.Label(
            footer,
            text="검색 진행률",
            bg=self.PANEL_3, fg="#89A0C3",
            font=("맑은 고딕", 8, "bold")
        ).grid(row=0,column=1,pady=(8,2),sticky="w")

        tk.Label(
            footer,
            textvariable=self.progress_percent_var,
            bg=self.PANEL_3, fg=self.ACCENT,
            font=("맑은 고딕", 9, "bold")
        ).grid(row=0,column=2,padx=(12,26),pady=(8,2),sticky="e")

        self.progress = ttk.Progressbar(
            footer, variable=self.progress_var, maximum=100,
            style="App.Horizontal.TProgressbar"
        )
        self.progress.grid(row=1,column=0,columnspan=3,sticky="ew",padx=26,pady=(0,9))

        self._update_option_group_state("potential")
        self._update_option_group_state("additional")
        self._update_flame_group_state()
        self._on_group_changed()

        # Keep the level range logically valid while editing.
        self.min_level_var.trace_add("write", self._sync_level_range)
        self.max_level_var.trace_add("write", self._sync_level_range)

        # Live summary bindings.
        for var in (self.min_level_var, self.max_level_var, self.job_group_var,
                    self.job_var, self.item_name_var):
            var.trace_add("write", lambda *_: self._update_metrics())
        self._update_metrics()

    def _sync_level_range(self, *_):
        """Ensure maximum level can never remain below minimum level."""
        if getattr(self, "_level_sync_lock", False):
            return

        min_raw=self.min_level_var.get().strip()
        max_raw=self.max_level_var.get().strip()
        if not min_raw or not max_raw:
            return

        try:
            min_level=int(min_raw)
            max_level=int(max_raw)
        except Exception:
            return

        if min_level <= max_level:
            return

        try:
            self._level_sync_lock=True
            self.max_level_var.set(str(min_level))
        finally:
            self._level_sync_lock=False

    def _restore_search_condition_editability(self):
        """검색 종료/중지/오류 후 조건 입력 컨트롤이 잠긴 채 남지 않게 복구합니다."""
        root=getattr(self, "search_tab", None)
        if root is None:
            return

        def walk(widget):
            for child in widget.winfo_children():
                try:
                    if isinstance(child, ttk.Combobox):
                        child.configure(state="readonly")
                    elif isinstance(child, ttk.Entry):
                        child.configure(state="normal")
                    elif isinstance(child, ttk.Checkbutton):
                        child.state(["!disabled"])
                    elif isinstance(child, ttk.Button):
                        child.state(["!disabled"])
                    elif isinstance(child, tk.Entry):
                        child.configure(state="normal")
                    elif isinstance(child, tk.Button):
                        child.configure(state="normal")
                except Exception:
                    pass
                walk(child)

        walk(root)
        # 미적용 등 의도적으로 비활성화되는 조건만 다시 반영합니다.
        self._update_option_group_state("potential")
        self._update_option_group_state("additional")
        self._update_flame_group_state()

    def _go_main_tab(self, index):
        try:
            self.notebook.select(index)
        except Exception:
            return
        self._update_top_nav_buttons()

    def _open_quick_settings(self):
        self._go_main_tab(0)
        try:
            self.after(10, lambda: self.key_entry.focus_set())
        except Exception:
            pass

    def _open_help(self):
        self._go_main_tab(3)

    def _update_top_nav_buttons(self):
        try:
            current=self.notebook.index("current")
        except Exception:
            return
        for btn, idx in (
            (getattr(self, "nav_search_btn", None), 0),
            (getattr(self, "nav_result_btn", None), 1),
            (getattr(self, "nav_log_btn", None), 2),
            (getattr(self, "nav_help_btn", None), 3),
        ):
            if btn is not None:
                btn.configure(style="HeaderNavActive.TButton" if idx==current else "HeaderNav.TButton")

    def _on_main_notebook_changed(self, _event=None):
        try:
            if self.notebook.index("current")==0 and not self._main_search_running():
                self._restore_search_condition_editability()
        except Exception:
            pass
        self._update_top_nav_buttons()

    def _update_metrics(self):
        try:
            lv1 = self.min_level_var.get().strip()
            lv2 = self.max_level_var.get().strip()
            level_txt = f"{lv1}" if lv1 == lv2 else f"{lv1}~{lv2}"
            if self.metric_level is not None:
                self.metric_level.configure(text=level_txt or "-")
            if self.metric_job is not None:
                job = self.job_var.get().strip() or self.job_group_var.get().strip()
                self.metric_job.configure(text=job or "-")
            if self.metric_mode is not None:
                mode = "프리셋 포함" if self.include_presets_var.get() else "현재 장비"
                self.metric_mode.configure(text=mode)
        except Exception:
            pass

    def _flame_suggestions(self, query):
        return self.flame_catalog.suggest(query, limit=30)

    def _potential_suggestions(self, query):
        return self.potential_catalog.suggest(query, limit=30)

    def _additional_suggestions(self, query):
        return self.additional_catalog.suggest(query, limit=30)

    def _update_option_group_state(self, mode):
        if mode=="potential":
            grade=self.pot_grade_var.get()
            rows=getattr(self, "potential_rows", [])
            grade_combo=getattr(self, "pot_grade_combo", None)
            order_combo=getattr(self, "pot_order_combo", None)
        else:
            grade=self.add_grade_var.get()
            rows=getattr(self, "additional_rows", [])
            grade_combo=getattr(self, "add_grade_combo", None)
            order_combo=getattr(self, "add_order_combo", None)

        if grade_combo is not None:
            grade_combo.configure(state="readonly")

        rows_enabled=grade!="미적용"
        for row in rows:
            row.set_enabled(rows_enabled, clear=False)

        if order_combo is not None:
            order_combo.configure(
                state="readonly" if rows_enabled else "disabled"
            )

    def _flame_expected_unit(self, index):
        try:
            raw=clean_text(self.flame_type_vars[index].get())
        except Exception:
            return ""
        d=self.flame_catalog.resolve(raw) if raw else None
        if not d:
            return ""
        return "%" if d.get("kind")=="percent" else "수치"

    def _sync_flame_unit(self, index):
        expected=self._flame_expected_unit(index)
        if expected and self.flame_unit_vars[index].get()!=expected:
            self.flame_unit_vars[index].set(expected)

    def _on_flame_type_selected(self, index, value):
        d=self.flame_catalog.resolve(value)
        if d:
            self.flame_type_vars[index].set(d["label"])
        self._sync_flame_unit(index)

    def _update_flame_group_state(self):
        presence=self.flame_presence_var.get()

        if hasattr(self, "flame_presence_combo"):
            self.flame_presence_combo.configure(state="readonly")

        rows_enabled=presence=="적용"
        for ac in getattr(self, "flame_autocomplete_widgets", []):
            ac.entry.configure(state="normal" if rows_enabled else "disabled")
            if not rows_enabled:
                ac.hide()
        for combo in getattr(self, "flame_unit_combos", []):
            combo.configure(state="readonly" if rows_enabled else "disabled")
        for entry in getattr(self, "flame_value_entries", []):
            entry.configure(state="normal" if rows_enabled else "disabled")

    def _collect_option_conditions(self, mode):
        if mode=="potential":
            grade=self.pot_grade_var.get()
            rows=getattr(self, "potential_rows", [])
        else:
            grade=self.add_grade_var.get()
            rows=getattr(self, "additional_rows", [])

        if grade=="미적용":
            return []

        # 등급만 선택하고 옵션 종류/수치를 모두 비워 둔 경우는
        # 잠재/에디셔널 '없음' 검색으로 사용한다. 단위 콤보에 자동값이
        # 남아 있더라도 빈 옵션 행으로 취급해야 한다.
        if rows and all(
            not clean_text(row.type_var.get()) and not clean_text(row.value_var.get())
            for row in rows
        ):
            return []

        out=[]
        for i,row in enumerate(rows):
            cond=row.get_condition(i)
            if cond:
                out.append(cond)
        return out

    def _equipment_suggestions(self, query):
        return self.catalog.suggest(query, limit=100)

    def _equipment_selected(self, name):
        self.item_name_mode_var.set("정확히 일치")

    def _refresh_catalog_label(self):
        if hasattr(self, "catalog_status_label"):
            self.catalog_status_label.configure(
                text=f"장비 자동완성 데이터 {len(self.catalog):,}개 · 검색할수록 자동 추가"
            )

    def _import_equipment_catalog(self):
        path = filedialog.askopenfilename(
            title="장비 이름 목록 추가",
            filetypes=[
                ("장비 목록", "*.json *.txt"),
                ("JSON 파일", "*.json"),
                ("텍스트 파일", "*.txt"),
                ("모든 파일", "*.*"),
            ],
        )
        if not path:
            return
        try:
            added = self.catalog.import_file(path)
            self._refresh_catalog_label()
            messagebox.showinfo(
                "장비 목록 추가",
                f"새 장비 이름 {added:,}개를 추가했습니다.\\n"
                f"현재 추천 데이터: {len(self.catalog):,}개",
            )
        except Exception as e:
            messagebox.showerror("장비 목록 오류", str(e))

    def _normalize_date_input(self, show_error=False):
        try:
            parsed=parse_flexible_search_date(self.date_var.get())
            self.date_var.set(parsed.isoformat())
            return parsed
        except ValueError as e:
            if show_error:
                messagebox.showerror("날짜 입력 확인",str(e))
            return None



    def _show_borderless_popup(self, popup, anchor_widget):
        """Show a borderless popup above this app without permanent topmost."""
        try:
            popup.update_idletasks()
            width=max(1,popup.winfo_reqwidth())
            height=max(1,popup.winfo_reqheight())

            x=anchor_widget.winfo_rootx()
            y=anchor_widget.winfo_rooty()+anchor_widget.winfo_height()+5

            sw=popup.winfo_screenwidth()
            sh=popup.winfo_screenheight()
            if x+width>sw-8:
                x=max(8,sw-width-8)
            if y+height>sh-8:
                y=anchor_widget.winfo_rooty()-height-5
            y=max(8,y)

            owner=anchor_widget.winfo_toplevel()
            try:
                popup.transient(owner)
            except Exception:
                pass

            popup.geometry(f"{width}x{height}+{x}+{y}")
            popup.deiconify()

            # Briefly force above owner, then release so other applications
            # can cover it normally.
            try:
                popup.attributes("-topmost",True)
            except Exception:
                pass
            popup.lift()
            popup.focus_force()

            def release():
                try:
                    if popup.winfo_exists():
                        popup.attributes("-topmost",False)
                        popup.lift()
                except Exception:
                    pass
            popup.after(120,release)

            try:
                popup.grab_set()
            except Exception:
                pass
        except Exception:
            try:
                popup.deiconify()
                popup.lift()
            except Exception:
                pass

    def _safe_destroy_popup(self, popup):
        try:
            popup.grab_release()
        except Exception:
            pass
        try:
            popup.destroy()
        except Exception:
            pass


    def _open_date_picker(self):
        selected=self._normalize_date_input(show_error=False) or today_kst()
        today=today_kst()

        popup=tk.Toplevel(self)
        popup.withdraw()
        popup.configure(bg=self.PANEL)
        popup.resizable(False,False)
        popup.overrideredirect(True)

        state={"year":selected.year,"month":selected.month}
        title_var=tk.StringVar()

        outer=tk.Frame(
            popup,
            bg=self.PANEL,
            highlightthickness=1,
            highlightbackground=self.BORDER,
        )
        outer.pack(fill="both",expand=True)

        head=tk.Frame(outer,bg=self.PANEL)
        head.pack(fill="x",padx=8,pady=(7,4))
        head.grid_columnconfigure(1,weight=1)

        weekdays=tk.Frame(outer,bg=self.PANEL)
        weekdays.pack(fill="x",padx=9)

        days_frame=tk.Frame(outer,bg=self.PANEL)
        days_frame.pack(padx=9,pady=(0,5))

        bottom=tk.Frame(outer,bg=self.PANEL)
        bottom.pack(fill="x",padx=9,pady=(0,8))

        def close_popup():
            self._safe_destroy_popup(popup)

        def choose(day):
            self.date_var.set(day.isoformat())
            close_popup()

        def render():
            for child in days_frame.winfo_children():
                child.destroy()

            year,month=state["year"],state["month"]
            title_var.set(f"{year}년 {month}월")
            weeks=calendar.monthcalendar(year,month)

            for r,week in enumerate(weeks):
                for c,num in enumerate(week):
                    days_frame.grid_columnconfigure(c,weight=1)

                    if not num:
                        tk.Label(
                            days_frame,
                            text="",
                            bg=self.PANEL,
                            width=3,
                        ).grid(row=r,column=c,padx=1,pady=1)
                        continue

                    day=datetime(year,month,num).date()
                    allowed=OPENAPI_HISTORY_START<=day<=today
                    is_selected=(day==selected)

                    tk.Button(
                        days_frame,
                        text=str(num),
                        width=3,
                        height=1,
                        relief="flat",
                        bd=0,
                        bg=(
                            "#2A68A8"
                            if is_selected else "#101A28"
                        ),
                        fg=(
                            "#FFFFFF"
                            if allowed else "#566173"
                        ),
                        activebackground="#26496B",
                        activeforeground="#FFFFFF",
                        disabledforeground="#566173",
                        font=(
                            "맑은 고딕",8,
                            "bold" if is_selected else "normal"
                        ),
                        command=(
                            (lambda d=day:choose(d))
                            if allowed else None
                        ),
                        state="normal" if allowed else "disabled",
                    ).grid(row=r,column=c,padx=1,pady=1)

            popup.update_idletasks()

        ttk.Button(
            head,
            text="‹",
            style="Ghost.TButton",
            width=3,
            command=lambda:self._shift_calendar_month(
                state,-1,render,OPENAPI_HISTORY_START,today
            ),
        ).grid(row=0,column=0,sticky="w")

        tk.Label(
            head,
            textvariable=title_var,
            bg=self.PANEL,
            fg=self.TEXT,
            font=("맑은 고딕",9,"bold"),
            anchor="center",
        ).grid(row=0,column=1,sticky="ew",padx=5)

        ttk.Button(
            head,
            text="›",
            style="Ghost.TButton",
            width=3,
            command=lambda:self._shift_calendar_month(
                state,1,render,OPENAPI_HISTORY_START,today
            ),
        ).grid(row=0,column=2,sticky="e")

        tk.Button(
            head,
            text="×",
            command=close_popup,
            bg=self.PANEL,
            fg="#DDE7F4",
            activebackground="#472229",
            activeforeground="#FFFFFF",
            relief="flat",
            bd=0,
            padx=6,
            pady=0,
            cursor="hand2",
            font=("Segoe UI",13,"bold"),
        ).grid(row=0,column=3,sticky="e",padx=(3,0))

        for i,name in enumerate(("월","화","수","목","금","토","일")):
            weekdays.grid_columnconfigure(i,weight=1)
            tk.Label(
                weekdays,
                text=name,
                bg=self.PANEL,
                fg=self.MUTED,
                font=("맑은 고딕",8,"bold"),
                width=3,
            ).grid(row=0,column=i,pady=(0,3))

        ttk.Button(
            bottom,
            text="오늘",
            style="Ghost.TButton",
            command=lambda:choose(today),
        ).pack(side="left")

        render()
        popup.bind("<Escape>",lambda e:close_popup())

        # Show only after the popup has a real requested size.
        self.after_idle(
            lambda:self._show_borderless_popup(popup,self.date_entry)
        )

    def _shift_calendar_month(
        self, state, delta, render, min_date, max_date
    ):
        year,month=state["year"],state["month"]
        total=year*12+(month-1)+delta
        new_year,new_month=total//12,total%12+1
        first=datetime(new_year,new_month,1).date()
        min_month=datetime(
            min_date.year,min_date.month,1
        ).date()
        max_month=datetime(
            max_date.year,max_date.month,1
        ).date()
        if first<min_month or first>max_month:
            return
        state["year"],state["month"]=new_year,new_month
        render()

    def _reset_search_filters(self):
        """검색 조건만 현재 빌드의 기본값으로 되돌립니다."""
        self._load_defaults()
        try:
            self._restore_search_condition_editability()
        except Exception:
            pass

    def _load_defaults(self):
        self.date_var.set(today_kst().isoformat()); self.min_level_var.set("295"); self.max_level_var.set("295")
        self.job_group_var.set("전체"); self._on_group_changed(); self.job_var.set("전체")
        self.world_normal_var.set(True); self.world_reboot_var.set(True); self.include_presets_var.set(True)
        self.item_name_var.set(""); self.item_name_mode_var.set("정확히 일치"); self.starforce_var.set("")
        self.pot_grade_var.set("미적용")
        self.potential_order_var.set("순서 무관")
        for v in self.pot_vars: v.set("")
        if hasattr(self, "potential_rows"):
            for row in self.potential_rows: row.clear()
        self.add_grade_var.set("미적용")
        self.additional_order_var.set("순서 무관")
        for v in self.add_vars: v.set("")
        if hasattr(self, "additional_rows"):
            for row in self.additional_rows: row.clear()
        if hasattr(self, "_update_option_group_state"):
            self._update_option_group_state("potential")
            self._update_option_group_state("additional")
        self.flame_presence_var.set("미적용")
        for v in self.flame_type_vars: v.set("")
        for v in self.flame_unit_vars:
            v.set("")
        for v in self.flame_value_vars: v.set("")
        if hasattr(self, "_update_flame_group_state"):
            self._update_flame_group_state()
        if hasattr(self, "search_scroller"):
            self.search_scroller.scroll_to_top()
        self.max_pages_var.set("300"); self.base_interval_var.set("0.75")
        if hasattr(self, "_update_metrics"): self._update_metrics()

    def _toggle_key(self):
        self.key_entry.configure(show="" if self.show_key_var.get() else "●")

    def _job_combo_mousewheel(self, event):
        # Forward Windows/macOS wheel movement to the page scroller and
        # return "break" so ttk.Combobox cannot change its selected value.
        if hasattr(self, "search_scroller"):
            self.search_scroller._on_mousewheel(event)
        return "break"

    def _job_combo_linux_wheel(self, event):
        if hasattr(self, "search_scroller"):
            self.search_scroller._on_linux_wheel(event)
        return "break"

    def _on_group_changed(self,event=None):
        g=self.job_group_var.get()
        vals=["전체"] if g=="전체" else JOB_GROUPS.get(g,[])
        self.job_combo["values"]=vals
        if self.job_var.get() not in vals:
            self.job_var.set(vals[0] if vals else "")
        if hasattr(self, "_update_metrics"): self._update_metrics()

    def _get_cfg(self):
        key=clean_text(self.api_key_var.get())
        if not key: raise ValueError("NEXON API Key를 입력하세요.")
        try:
            mn=int(self.min_level_var.get()); mx=int(self.max_level_var.get())
        except: raise ValueError("레벨은 숫자로 입력하세요.")
        if mn<1 or mx<mn: raise ValueError("레벨 범위를 확인하세요.")
        try:
            query_date=parse_flexible_search_date(self.date_var.get())
        except ValueError as e:
            raise ValueError(str(e))
        date=query_date.isoformat()
        self.date_var.set(date)

        now_kst=datetime.now(KST)
        today=now_kst.date()
        if query_date < OPENAPI_HISTORY_START:
            raise ValueError("메이플스토리 Open API 조회 날짜는 2023-12-21 이후여야 합니다.")
        if query_date > today:
            raise ValueError("미래 날짜는 조회할 수 없습니다.")
        if query_date == today and (now_kst.hour, now_kst.minute) < (9,30):
            raise ValueError(
                "오늘 랭킹은 오전 9시 30분(KST) 이후 조회할 수 있습니다.\n"
                "그 전에는 이전 날짜를 선택해 주세요."
            )
        if query_date == today - timedelta(days=1) and (now_kst.hour, now_kst.minute) < (2,0):
            raise ValueError(
                "전일 캐릭터 데이터는 오전 2시(KST)부터 조회할 수 있습니다.\n"
                "현재는 이틀 전 날짜를 선택해 주세요."
            )
        character_realtime = (query_date == today)
        w=[]
        if self.world_normal_var.get(): w.append(0)
        if self.world_reboot_var.get(): w.append(1)
        if not w: raise ValueError("월드 유형을 하나 이상 선택하세요.")
        star=clean_text(self.starforce_var.get())
        if star:
            try:
                if int(star)<0: raise ValueError
            except: raise ValueError("스타포스는 숫자 또는 빈칸이어야 합니다.")
        try:
            pages=int(self.max_pages_var.get())
            if not 1<=pages<=1000: raise ValueError
        except: raise ValueError("최대 랭킹 페이지는 1~1000입니다.")
        try:
            interval=float(self.base_interval_var.get())
            if not 0.25<=interval<=5.0: raise ValueError
        except: raise ValueError("API 호출 간격은 0.25~5.0초 사이로 입력하세요.")
        flame_conditions=[]
        if self.flame_presence_var.get()=="적용":
            for i in range(4):
                t=clean_text(self.flame_type_vars[i].get())
                v=clean_text(self.flame_value_vars[i].get())
                if not t and not v:
                    continue
                if not t or not v:
                    raise ValueError(f"추가옵션 조건 {i+1}의 종류와 수치를 모두 입력하세요.")
                d=self.flame_catalog.resolve(t)
                if not d:
                    raise ValueError(f"추가옵션 조건 {i+1}의 종류를 확인하세요: {t}")
                try:
                    num=float(v)
                except Exception:
                    raise ValueError(f"추가옵션 조건 {i+1}의 수치는 숫자로 입력하세요.")
                unit=clean_text(self.flame_unit_vars[i].get())
                expected_unit="%" if d.get("kind")=="percent" else "수치"
                if not unit:
                    unit=expected_unit
                    self.flame_unit_vars[i].set(unit)
                if unit!=expected_unit:
                    raise ValueError(
                        f"추가옵션 조건 {i+1}의 단위를 확인하세요: "
                        f"{d['label']}은(는) {expected_unit} 단위입니다."
                    )
                flame_conditions.append({
                    "field":d["key"],
                    "label":d["label"],
                    "unit":unit,
                    "op":"정확히",
                    "value":num,
                })

        g=self.job_group_var.get(); job="전체" if g=="전체" else self.job_var.get()
        return {
            "api_key":key,"date":date,"min_level":mn,"max_level":mx,"job_group":g,"job":job,
            "world_types":w,"include_presets":self.include_presets_var.get(),
            "item_name":clean_text(self.item_name_var.get()),"item_name_mode":self.item_name_mode_var.get(),
            "starforce":star,
            "potential_grade":self.pot_grade_var.get(),
            "potential_conditions":self._collect_option_conditions("potential"),
            "potential_order":self.potential_order_var.get(),
            "additional_grade":self.add_grade_var.get(),
            "additional_conditions":self._collect_option_conditions("additional"),
            "additional_order":self.additional_order_var.get(),
            "flame_presence":self.flame_presence_var.get(),"flame_conditions":flame_conditions,
            "max_pages":pages,"base_interval":interval,
            "character_realtime":character_realtime,
        }

    def _start_search(self):
        if self.worker and self.worker.is_alive():
            if self.search_pause_event.is_set():
                self.search_pause_event.clear()
                self.priority_detail_tokens.clear()
                self.detail_pause_override=False
                self.status_var.set(self.last_search_progress_text or "검색 재개")
                self.start_btn.configure(state="disabled")
                self.cancel_btn.configure(state="normal")
                self._append_log("[검색] 일시정지된 전수검색을 재개합니다.")
            return

        try:
            cfg=self._get_cfg()
        except ValueError as e:
            messagebox.showerror("입력 확인",str(e))
            return

        cp=Checkpoint(self.app_dir,cfg)
        resume=False
        fresh_start=False

        if cp.exists():
            try:
                cp.load()
                done=len(cp.data.get("completed",{}))
                total=len(cp.data.get("candidates",[]))
                phase=cp.data.get("phase","")

                if phase=="done":
                    choice=messagebox.askyesnocancel(
                        "이전 검색 발견",
                        f"같은 조건의 완료된 검색이 있습니다.\n"
                        f"후보 {total}명 / 완료 {done}명\n\n"
                        "예 = 기존 결과 열기\n"
                        "아니오 = 현재 화면 설정으로 처음부터 다시 검색\n"
                        "취소 = 돌아가기"
                    )
                    if choice is None:
                        return
                    if choice is True:
                        self._load_checkpoint_into_ui(cp)
                        self.status_var.set(f"완료 · 결과 {len(self.results)}건")
                        return

                    # NO: explicitly throw away every persisted search-progress
                    # artifact and re-read the current UI before launching.
                    fresh_start=True
                    cp.discard_files()
                    try:
                        cfg=self._get_cfg()
                    except ValueError as e:
                        messagebox.showerror("입력 확인",str(e))
                        return
                    cp=Checkpoint(self.app_dir,cfg)

                else:
                    choice=messagebox.askyesno(
                        "이어하기 가능",
                        f"같은 조건의 미완료 검색이 있습니다.\n"
                        f"후보 {total}명 / 완료 {done}명\n\n"
                        "이어하시겠습니까?\n\n"
                        "예 = 저장된 진행상황 이어하기\n"
                        "아니오 = 현재 화면 설정으로 처음부터 다시 검색"
                    )
                    if choice:
                        resume=True
                    else:
                        fresh_start=True
                        cp.discard_files()

                        # Read the controls again after the choice.  A fresh
                        # search must always use what is currently on screen,
                        # never the config embedded in the old checkpoint.
                        try:
                            cfg=self._get_cfg()
                        except ValueError as e:
                            messagebox.showerror("입력 확인",str(e))
                            return
                        cp=Checkpoint(self.app_dir,cfg)

            except Exception as e:
                # If an old checkpoint itself is corrupt, do not silently use
                # any of its stored settings/progress.  Start from current UI.
                fresh_start=True
                try:
                    cp.discard_files()
                except Exception:
                    pass
                try:
                    cfg=self._get_cfg()
                except ValueError as input_error:
                    messagebox.showerror("입력 확인",str(input_error))
                    return
                cp=Checkpoint(self.app_dir,cfg)
                self._append_log(
                    "[체크포인트] 이전 저장 파일을 읽지 못해 현재 화면 설정으로 새 검색을 시작합니다."
                )

        self.last_cfg=cfg
        self.cancel_event.clear()
        self.search_pause_event.clear()
        self.priority_detail_tokens.clear()
        self.detail_pause_override=False

        self.results.clear()
        for iid in self.tree.get_children():
            self.tree.delete(iid)
        self.count_var.set("0")
        self.log_text.delete("1.0","end")
        self.progress_var.set(0)
        self.progress_percent_var.set("0%")

        self.status_var.set("검색 준비 중")
        self.start_btn.configure(state="disabled")
        self.cancel_btn.configure(state="normal")

        self.worker=threading.Thread(
            target=self._worker_main,
            args=(cfg,resume,fresh_start),
            daemon=True,
        )
        self.worker.start()

    def _load_checkpoint_into_ui(self,cp):
        self.results=list(cp.data.get("results") or [])
        for iid in self.tree.get_children(): self.tree.delete(iid)
        for row in self.results: self._insert_result(row)
        self.count_var.set(str(len(self.results)))
        self.last_cfg={**cp.data.get("config",{}),"api_key":self.api_key_var.get()}

    def _main_search_running(self):
        return bool(self.worker and self.worker.is_alive())



    def _pause_main_search_for_detail(self, token):
        if not self._main_search_running():
            return False

        if not self.search_pause_event.is_set():
            self.search_pause_event.set()
            self.status_var.set("검색 일시정지")
            self._append_log(
                "[상세조회] 전수검색을 일시정지했습니다. "
                "상세창 종료 후 메인 '검색 시작'으로 재개할 수 있습니다."
            )

        # Never accumulate nested pause tokens.
        self.priority_detail_tokens.clear()
        return True

    def _cancel_search(self):
        self.cancel_event.set()
        self.search_pause_event.clear()
        self.status_var.set("중지 요청")

    def _worker_main(self,cfg,resume,fresh_start=False):
        def log(msg): self.event_q.put(("log",msg))
        def progress(stage,cur,total): self.event_q.put(("progress",stage,cur,total))
        def result(row): self.event_q.put(("result",row))
        def cooldown(seconds): self.event_q.put(("cooldown",seconds))

        client=AdaptiveApiClient(
            cfg["api_key"],
            self.cancel_event,
            log_cb=log,
            base_interval=cfg["base_interval"],
            cache_dir=self.app_dir / "api_cache",
            cooldown_cb=cooldown,
            pause_event=self.search_pause_event,
        )
        # Validate the key before creating/resuming any checkpoint.
        try:
            client.get_json(
                "ranking/overall",
                {"date":cfg["date"], "world_type":cfg["world_types"][0], "page":1},
            )
        except RuntimeError as e:
            if str(e)=="API_KEY_INVALID":
                self.event_q.put(("api_key_error",))
                return
            self.event_q.put(("preflight_error", str(e)))
            return

        cp=Checkpoint(self.app_dir,cfg)

        # "처음부터 다시 검색" must never reuse the previous candidate list,
        # completed map, result list, or error list.  Delete the old persisted
        # artifacts once more in the worker and instantiate a brand-new
        # checkpoint object from the CURRENT cfg snapshot.
        if fresh_start:
            cp.discard_files()
            cp=Checkpoint(self.app_dir,cfg)

        try:
            if resume and (not fresh_start) and cp.exists():
                cp.load()
                log("=== 이전 검색 이어하기 ===")
                # replay already-found results into the UI
                for row in cp.data.get("results") or []: result(row)
            else:
                log("=== 새 검색 시작 ===")
                if fresh_start:
                    log("[새로 시작] 이전 진행상황을 폐기하고 현재 화면 설정을 다시 적용했습니다.")
                log(f"날짜: {cfg['date']} / 레벨: {cfg['min_level']}~{cfg['max_level']}")
                log(f"직업: {cfg['job_group']} > {cfg['job']}")
                log(f"월드 유형: {cfg['world_types']}")
                log(f"장비: {cfg['item_name'] or '(제한 없음)'} / 스타포스: {cfg['starforce'] or '(제한 없음)'}")
                if cfg.get("character_realtime"):
                    log("오늘 조회 모드: 랭킹=오늘 랭킹 / 캐릭터 장비=실시간")
                else:
                    log(f"과거 조회 모드: 랭킹/캐릭터 장비 기준일={cfg['date']}")
                log(
                    f"잠재: {cfg['potential_grade']} / "
                    f"에디셔널: {cfg['additional_grade']} / "
                    f"추가옵션: {cfg['flame_presence']}"
                )
                log(f"API 기본 호출 간격: {cfg['base_interval']:.2f}초")

            if not cp.data.get("candidates"):
                candidates=collect_candidates(client,cfg,log,progress)
                cp.data["candidates"]=candidates
                cp.data["phase"]="scanning"
                cp.save()
                log(f"\n후보 수집 완료: {len(candidates)}명")
            else:
                candidates=cp.data["candidates"]
                log(f"저장된 후보 목록 사용: {len(candidates)}명")

            if not candidates:
                self.event_q.put(("done",cp,client.total_429,"후보가 없습니다.")); return

            results=scan_candidates(client,cfg,cp,log,progress,result,self.catalog.learn_many)
            log(
                f"API 캐시: 적중 {client.cache_hits}건 / "
                f"새 저장 {client.cache_writes}건"
            )
            self.event_q.put(("done",cp,client.total_429,None))

        except InterruptedError:
            try: cp.save()
            except: pass
            log(
                f"API 캐시: 적중 {client.cache_hits}건 / "
                f"새 저장 {client.cache_writes}건"
            )
            self.event_q.put(("cancelled",cp,client.total_429))
        except Exception as e:
            try: cp.save()
            except: pass
            self.event_q.put(("error",str(e),cp,client.total_429))

    def _poll_events(self):
        try:
            while True:
                ev=self.event_q.get_nowait(); kind=ev[0]
                if kind.startswith("detail_"):
                    self._handle_detail_event(ev)
                elif kind=="log":
                    self._append_log(ev[1])
                elif kind=="cooldown":
                    # Detailed rate-limit waits belong in the log.
                    # Keep the compact sidebar progress text unchanged.
                    pass
                elif kind=="api_key_error":
                    self.start_btn.configure(state="normal")
                    self.cancel_btn.configure(state="disabled")
                    self._restore_search_condition_editability()
                    self.status_var.set("API Key 오류")
                    self._append_log("\n[API Key 오류] 입력한 NEXON Open API Key가 유효하지 않습니다.")
                    try:
                        self.key_entry.focus_set()
                    except Exception:
                        pass
                    messagebox.showerror(
                        "API Key 오류",
                        "입력한 NEXON Open API Key가 유효하지 않습니다.\n\n"
                        "NEXON Open API에서 현재 사용 중인 Key인지 확인해 주세요.\n"
                        "서비스 단계 애플리케이션을 새로 등록했다면 새로 발급된 서비스 Key를 사용하세요."
                    )
                elif kind=="preflight_error":
                    self.start_btn.configure(state="normal")
                    self.cancel_btn.configure(state="disabled")
                    self._restore_search_condition_editability()
                    self.status_var.set("오류 발생")
                    self._append_log("\n[API 연결 오류]\n"+ev[1])
                    messagebox.showerror("API 연결 오류", ev[1])
                elif kind=="progress":
                    _,stage,cur,total=ev
                    if total:
                        pct=min(100,cur*100/total)
                        self.progress_var.set(pct)
                        self.progress_percent_var.set(f"{pct:.1f}%")
                    progress_text=(
                        f"후보 수집 · {cur}페이지"
                        if stage=="rank"
                        else f"검색 {cur} / {total}"
                    )
                    self.last_search_progress_text=progress_text
                    if not self.search_pause_event.is_set():
                        self.status_var.set(progress_text)
                elif kind=="result":
                    row=ev[1]
                    # avoid duplicate UI rows on resumed checkpoint replay
                    sig=(row.get("닉네임"),row.get("월드"),row.get("장비명"),row.get("스타포스"),
                         row.get("잠재1"),row.get("잠재2"),row.get("잠재3"),
                         row.get("에디1"),row.get("에디2"),row.get("에디3"))
                    existing={(r.get("닉네임"),r.get("월드"),r.get("장비명"),r.get("스타포스"),
                               r.get("잠재1"),r.get("잠재2"),r.get("잠재3"),
                               r.get("에디1"),r.get("에디2"),r.get("에디3")) for r in self.results}
                    if sig not in existing:
                        self.results.append(row); self._insert_result(row)
                    self.count_var.set(str(len(self.results)))
                elif kind=="done":
                    _,cp,n429,note=ev
                    self.search_pause_event.clear()
                    self.priority_detail_tokens.clear()
                    self.progress_var.set(100)
                    self.progress_percent_var.set("100%")
                    self.start_btn.configure(state="normal"); self.cancel_btn.configure(state="disabled")
                    self._restore_search_condition_editability()
                    done=len(cp.data.get("completed",{})); total=len(cp.data.get("candidates",[]))
                    self.status_var.set(f"완료 · {done}/{total} · 결과 {len(cp.data.get('results',[]))}건")
                    self._append_log(f"\n=== 검색 완료 ===\n완료 {done}/{total}명")
                    self._append_log(f"체크포인트: {cp.path}")
                    self._append_log(f"결과 CSV: {cp.results_csv}")
                    self._refresh_catalog_label()
                    messagebox.showinfo("검색 완료",f"후보 {total}명 검사가 완료되었습니다.\n일치하는 결과는 {len(cp.data.get('results',[]))}건입니다.")
                elif kind=="cancelled":
                    _,cp,n429=ev
                    self.search_pause_event.clear()
                    self.priority_detail_tokens.clear()
                    self.start_btn.configure(state="normal"); self.cancel_btn.configure(state="disabled")
                    self._restore_search_condition_editability()
                    done=len(cp.data.get("completed",{})); total=len(cp.data.get("candidates",[]))
                    self.status_var.set(f"중지 · {done}/{total}")
                    self._append_log(f"\n중지됨. 진행상황 저장 완료: {done}/{total}명")
                    self._append_log("같은 조건으로 다시 검색하면 이어하기 여부를 묻습니다.")
                    self._refresh_catalog_label()
                elif kind=="error":
                    _,msg,cp,n429=ev
                    self.search_pause_event.clear()
                    self.priority_detail_tokens.clear()
                    self.start_btn.configure(state="normal"); self.cancel_btn.configure(state="disabled")
                    self._restore_search_condition_editability()
                    if msg=="API_KEY_INVALID" or "apikey is not valid" in msg.casefold():
                        self.status_var.set("API Key 오류")
                        self._append_log("\n[API Key 오류] 입력한 NEXON Open API Key가 유효하지 않습니다.")
                        messagebox.showerror(
                            "API Key 오류",
                            "입력한 NEXON Open API Key가 유효하지 않습니다.\n\n"
                            "현재 사용 중인 Key인지 확인해 주세요.\n"
                            "서비스 단계 애플리케이션을 새로 등록했다면 새로 발급된 서비스 Key를 사용하세요."
                        )
                    else:
                        self.status_var.set("오류 발생")
                        self._append_log("\n[오류]\n"+msg)
                        messagebox.showerror("검색 오류",msg+"\n\n진행상황은 저장되어 다음 실행에서 이어갈 수 있습니다.")
        except queue.Empty:
            pass
        self.after(100,self._poll_events)


    def _show_owned_detail_window(self, window, owner, center=True):
        """Raise a borderless detail window above this app, not globally."""
        try:
            window.update_idletasks()
            if center:
                # Toplevel is created withdrawn.  While withdrawn, Tk reports
                # winfo_width()/height() as 1x1 even after geometry("1020x720").
                # Do not overwrite the requested detail size with that placeholder.
                width=max(1020,window.winfo_width())
                height=max(720,window.winfo_height())
                owner.update_idletasks()
                x=owner.winfo_rootx()+max(0,(owner.winfo_width()-width)//2)
                y=owner.winfo_rooty()+max(0,(owner.winfo_height()-height)//2)
                sw=window.winfo_screenwidth()
                sh=window.winfo_screenheight()
                x=max(8,min(x,sw-width-8))
                y=max(8,min(y,sh-height-8))
                window.geometry(f"{width}x{height}+{x}+{y}")

            try:
                window.transient(owner)
            except Exception:
                pass

            window.deiconify()
            try:
                window.attributes("-topmost",True)
            except Exception:
                pass
            window.lift()
            window.focus_force()

            def release():
                try:
                    if window.winfo_exists():
                        window.attributes("-topmost",False)
                        window.lift()
                except Exception:
                    pass
            window.after(140,release)
        except Exception:
            try:
                window.deiconify()
                window.lift()
            except Exception:
                pass

    def _open_selected_character_detail(self, event=None):
        # Only one detail window can exist. Repeated double-clicks simply
        # bring the existing window forward and do not create extra pauses.
        active_token=getattr(self, "active_detail_token", None)
        if active_token:
            ctx=self.detail_windows.get(active_token)
            win=(ctx or {}).get("win")
            try:
                if win is not None and win.winfo_exists():
                    self._show_owned_detail_window(
                        win,self,center=False
                    )
                    return
            except Exception:
                pass
            self.active_detail_token=None

        iid=None
        if event is not None:
            try:
                iid=self.tree.identify_row(event.y)
                if iid:
                    self.tree.selection_set(iid)
            except Exception:
                iid=None

        if not iid:
            selected=self.tree.selection()
            iid=selected[0] if selected else None
        if not iid:
            return

        values=self.tree.item(iid, "values")
        if not values:
            return

        nickname=str(values[0]).strip()
        if not nickname:
            return

        preview_world=str(values[1]).strip() if len(values)>1 else ""
        preview_level=str(values[2]).strip() if len(values)>2 else ""
        preview_job=str(values[3]).strip() if len(values)>3 else ""
        preview_guild=str(values[4]).strip() if len(values)>4 else ""

        api_key=self.api_key_var.get().strip()
        if not api_key:
            messagebox.showwarning(
                "API Key 필요",
                "캐릭터 상세정보를 조회하려면 상단 API Key를 먼저 입력해 주세요.",
            )
            try:
                self.key_entry.focus_set()
            except Exception:
                pass
            return

        win=tk.Toplevel(self)
        win.withdraw()
        win.geometry("1020x720")
        win.configure(
            bg=self.BG,
            highlightthickness=1,
            highlightbackground=self.BORDER,
        )
        win.overrideredirect(True)
        win.transient(self)
        try:
            if self.window_icon is not None:
                win.iconphoto(True,self.window_icon)
        except Exception:
            pass

        token=str(id(win))
        self.active_detail_token=token
        main_was_paused=self._pause_main_search_for_detail(token)

        def close_window():
            ctx=self.detail_windows.get(token)
            if ctx:
                task_cancel=ctx.get("task_cancel_event")
                if task_cancel is not None:
                    task_cancel.set()

            self.detail_windows.pop(token,None)
            self.detail_cancel_events.pop(token,None)
            self.priority_detail_tokens.clear()
            if getattr(self, "active_detail_token", None)==token:
                self.active_detail_token=None

            if self._main_search_running() and self.search_pause_event.is_set():
                self.status_var.set("검색 일시정지 · 검색 시작을 눌러 재개")
                self.start_btn.configure(state="normal")
                self.cancel_btn.configure(state="normal")
                self._append_log(
                    "[상세조회] 상세창 종료. 메인 '검색 시작'을 누르면 "
                    "기존 검색이 이어집니다."
                )

            try:
                win.destroy()
            except Exception:
                pass

        win.protocol("WM_DELETE_WINDOW",close_window)
        win.bind("<Escape>",lambda e:close_window())

        drag_state={"x":0,"y":0}

        def drag_start(event):
            drag_state["x"]=event.x_root-win.winfo_x()
            drag_state["y"]=event.y_root-win.winfo_y()

        def drag_move(event):
            x=event.x_root-drag_state["x"]
            y=event.y_root-drag_state["y"]
            win.geometry(f"+{x}+{y}")

        # Header
        head=tk.Frame(win,bg=self.BG)
        head.pack(fill="x",padx=22,pady=(18,10))

        title_wrap=tk.Frame(head,bg=self.BG)
        title_wrap.pack(side="left",fill="x",expand=True)
        title_label=tk.Label(
            title_wrap,text=nickname,bg=self.BG,fg=self.TEXT,
            font=("맑은 고딕",20,"bold")
        )
        title_label.pack(anchor="w")

        status_label=tk.Label(
            title_wrap,
            text="원하는 탭을 선택하면 해당 정보만 조회합니다.",
            bg=self.BG,fg=self.MUTED,font=("맑은 고딕",9)
        )
        status_label.pack(anchor="w",pady=(2,0))

        priority_label=tk.Label(
            title_wrap,
            text=(
                "전수검색 일시정지 · 상세창 종료 후 메인 검색 시작으로 재개"
                if main_was_paused
                else "현재 진행 중인 전수검색 없음"
            ),
            bg=self.BG,
            fg=self.ACCENT if main_was_paused else self.MUTED,
            font=("맑은 고딕",8,"bold"),
        )
        priority_label.pack(anchor="w",pady=(4,0))

        for _drag_widget in (head,title_wrap,title_label,status_label,priority_label):
            _drag_widget.bind("<ButtonPress-1>",drag_start)
            _drag_widget.bind("<B1-Motion>",drag_move)

        tk.Button(
            head,
            text="×",
            command=close_window,
            bg=self.BG,
            fg="#DDE7F4",
            activebackground="#472229",
            activeforeground="#FFFFFF",
            relief="flat",
            bd=0,
            padx=9,
            pady=0,
            cursor="hand2",
            font=("Segoe UI",18,"bold"),
        ).pack(side="right",padx=(8,0))

        ttk.Button(
            head,text="MapleScouter 열기",style="Ghost.TButton",
            command=lambda n=nickname:webbrowser.open(
                f"https://maplescouter.com/ko/info?name={quote(n)}"
            ),
        ).pack(side="right")

        # Search-result summary: no API request needed.
        summary=tk.Frame(
            win,bg=self.PANEL,highlightthickness=1,
            highlightbackground=self.BORDER
        )
        summary.pack(fill="x",padx=22,pady=(0,12))
        tk.Label(
            summary,
            text=(
                f"월드  {preview_world or '-'}     "
                f"레벨  Lv.{preview_level or '-'}     "
                f"직업  {preview_job or '-'}     "
                f"길드  {preview_guild or '-'}"
            ),
            bg=self.PANEL,fg=self.TEXT,
            anchor="w",justify="left",
            font=("맑은 고딕",10,"bold"),
            padx=16,pady=15,
        ).pack(fill="x")

        notebook=ttk.Notebook(win,style="App.TNotebook")
        notebook.pack(fill="both",expand=True,padx=22,pady=(0,18))

        # Overview: the default tab performs no heavy API work.
        overview_tab=tk.Frame(notebook,bg=self.BG)
        notebook.add(overview_tab,text="안내")
        tk.Label(
            overview_tab,
            text=(
                "조회할 항목을 선택하세요.\n\n"
                "• 타임라인\n"
                "  최근 날짜부터 과거 방향으로 확인하며 레벨업·닉네임·길드·월드·성별 변경을 찾습니다. "
                "레벨 이력 조회 개수는 기본 10이며 원하는 수로 바꿀 수 있습니다.\n\n"
                "• 코디 기록\n"
                "  시작 날짜와 끝 날짜를 지정해 해당 기간의 코디 변화를 확인합니다. "
                "조회 개수는 기본 10이며 원하는 수로 바꿀 수 있습니다.\n\n"
                "다른 탭으로 이동하면 진행 중이던 상세 조회는 중단됩니다."
            ),
            bg=self.BG,
            fg=self.MUTED,
            justify="left",
            anchor="nw",
            font=("맑은 고딕",11),
            padx=24,
            pady=26,
            wraplength=820,
        ).pack(fill="both",expand=True)

        # Timeline
        timeline_tab=tk.Frame(notebook,bg=self.BG)
        notebook.add(timeline_tab,text="타임라인")
        timeline_top=tk.Frame(timeline_tab,bg=self.BG)
        timeline_top.pack(fill="x",pady=(10,7))

        timeline_filters={
            "nickname":tk.BooleanVar(value=True),
            "guild":tk.BooleanVar(value=True),
            "world":tk.BooleanVar(value=True),
            "gender":tk.BooleanVar(value=True),
            "level":tk.BooleanVar(value=True),
        }
        tk.Label(
            timeline_top,text="표시 항목",bg=self.BG,fg=self.MUTED,
            font=("맑은 고딕",8,"bold")
        ).pack(side="left",padx=(0,10))
        for key,label in (
            ("nickname","닉네임"),("guild","길드"),("world","월드"),
            ("gender","성별"),("level","레벨")
        ):
            ttk.Checkbutton(
                timeline_top,text=label,variable=timeline_filters[key],
                command=lambda t=token:self._render_timeline_events(t)
            ).pack(side="left",padx=(0,10))

        timeline_limit_var=tk.StringVar(value="10")
        tk.Label(
            timeline_top,text="레벨 이력 수",bg=self.BG,fg=self.MUTED,
            font=("맑은 고딕",8,"bold")
        ).pack(side="left",padx=(8,5))
        timeline_limit_entry=ttk.Entry(
            timeline_top,textvariable=timeline_limit_var,width=6
        )
        timeline_limit_entry.pack(side="left",padx=(0,5))
        ttk.Button(
            timeline_top,text="조회",style="Ghost.TButton",
            command=lambda t=token:self._normalize_detail_limit(
                t,"timeline",show_error=True,restart=True
            )
        ).pack(side="left")

        timeline_status=tk.Label(
            timeline_tab,
            text="타임라인 탭을 선택하면 날짜별 조회를 시작합니다.",
            bg=self.BG,fg=self.MUTED,font=("맑은 고딕",8),
            anchor="w",justify="left"
        )
        timeline_status.pack(fill="x",pady=(0,4))

        tk.Label(
            timeline_tab,
            text=(
                "조회 가능 시작일: 2023-12-21  ·  "
                "해당 날짜 이후 Open API 과거 데이터가 존재하는 캐릭터 기준"
            ),
            bg=self.BG,
            fg="#D8A85D",
            font=("맑은 고딕",8,"bold"),
            anchor="w",
            justify="left",
        ).pack(fill="x",pady=(0,6))

        timeline_scroll=VerticalScrolledFrame(timeline_tab,bg=self.BG)
        timeline_scroll.pack(fill="both",expand=True,pady=(0,8))

        # Outfit
        outfit_tab=tk.Frame(notebook,bg=self.BG)
        notebook.add(outfit_tab,text="코디 기록")

        outfit_controls=tk.Frame(outfit_tab,bg=self.BG)
        outfit_controls.pack(fill="x",pady=(10,6))

        outfit_end_default=latest_complete_historical_date_kst()
        outfit_start_default=self._subtract_calendar_months(
            outfit_end_default,6
        )

        outfit_start_var=tk.StringVar(
            value=outfit_start_default.isoformat()
        )
        outfit_end_var=tk.StringVar(
            value=outfit_end_default.isoformat()
        )

        tk.Label(
            outfit_controls,text="시작 날짜",
            bg=self.BG,fg=self.MUTED,
            font=("맑은 고딕",8,"bold")
        ).grid(row=0,column=0,sticky="w",padx=(0,6))

        outfit_start_entry=ttk.Entry(
            outfit_controls,textvariable=outfit_start_var,width=12
        )
        outfit_start_entry.grid(
            row=0,column=1,sticky="w",padx=(0,2)
        )

        tk.Button(
            outfit_controls,
            text="▦",
            command=lambda t=token:self._open_outfit_date_picker(t,"start"),
            width=3,
            height=1,
            bg="#101A28",
            fg="#D3E5FA",
            activebackground="#203B59",
            activeforeground="#FFFFFF",
            relief="solid",
            bd=1,
            highlightthickness=0,
            padx=0,
            pady=0,
            cursor="hand2",
            font=("Segoe UI Symbol",11,"bold"),
        ).grid(row=0,column=2,padx=(0,12),ipadx=0,ipady=0)

        tk.Label(
            outfit_controls,text="끝 날짜",
            bg=self.BG,fg=self.MUTED,
            font=("맑은 고딕",8,"bold")
        ).grid(row=0,column=3,sticky="w",padx=(0,6))

        outfit_end_entry=ttk.Entry(
            outfit_controls,textvariable=outfit_end_var,width=12
        )
        outfit_end_entry.grid(
            row=0,column=4,sticky="w",padx=(0,2)
        )

        tk.Button(
            outfit_controls,
            text="▦",
            command=lambda t=token:self._open_outfit_date_picker(t,"end"),
            width=3,
            height=1,
            bg="#101A28",
            fg="#D3E5FA",
            activebackground="#203B59",
            activeforeground="#FFFFFF",
            relief="solid",
            bd=1,
            highlightthickness=0,
            padx=0,
            pady=0,
            cursor="hand2",
            font=("Segoe UI Symbol",11,"bold"),
        ).grid(row=0,column=5,padx=(0,14),ipadx=0,ipady=0)

        outfit_limit_var=tk.StringVar(value="10")
        tk.Label(
            outfit_controls,text="코디 변화 수",
            bg=self.BG,fg=self.MUTED,
            font=("맑은 고딕",8,"bold")
        ).grid(row=0,column=6,sticky="w",padx=(0,6))
        outfit_limit_entry=ttk.Entry(
            outfit_controls,textvariable=outfit_limit_var,width=6
        )
        outfit_limit_entry.grid(
            row=0,column=7,sticky="w",padx=(0,8)
        )
        ttk.Button(
            outfit_controls,text="조회",style="Ghost.TButton",
            command=lambda t=token:self._normalize_detail_limit(
                t,"outfit",show_error=True,restart=True
            )
        ).grid(row=0,column=8,sticky="w",padx=(0,12))

        outfit_condition_hint=tk.Label(
            outfit_controls,
            text=(
                "지정 기간 최대 185일 · 코디 변화 최대 10건"
            ),
            bg=self.BG,fg=self.MUTED,font=("맑은 고딕",8)
        )
        outfit_condition_hint.grid(
            row=0,column=9,sticky="w"
        )

        tk.Label(
            outfit_controls,
            text=(
                "Open API 과거 데이터 조회 시작일: 2023-12-21  ·  "
                "전일 캐릭터/캐시 장비 데이터는 02:00 KST 이후 제공"
            ),
            bg=self.BG,
            fg="#D8A85D",
            font=("맑은 고딕",8,"bold"),
            anchor="w",
            justify="left",
        ).grid(
            row=1,column=0,columnspan=10,
            sticky="w",pady=(6,0)
        )

        tk.Label(
            outfit_controls,
            text=(
                "※ 달력에서도 2023-12-21 이전 날짜는 선택할 수 없습니다. "
                "선택 기간 중 해당 캐릭터의 과거 데이터가 없는 날짜는 건너뜁니다."
            ),
            bg=self.BG,
            fg=self.MUTED,
            font=("맑은 고딕",8),
            anchor="w",
            justify="left",
        ).grid(
            row=2,column=0,columnspan=10,
            sticky="w",pady=(3,0)
        )

        outfit_status=tk.Label(
            outfit_tab,
            text="코디 기록 탭을 선택하면 지정 기간을 날짜별로 조회합니다.",
            bg=self.BG,fg=self.MUTED,font=("맑은 고딕",8)
        )
        outfit_status.pack(fill="x",anchor="w",pady=(0,7))

        outfit_scroll=VerticalScrolledFrame(outfit_tab,bg=self.BG)
        outfit_scroll.pack(fill="both",expand=True,pady=(0,8))

        ctx={
            "win":win,
            "nickname":nickname,
            "preview_world":preview_world,
            "preview_level":preview_level,
            "preview_job":preview_job,
            "preview_guild":preview_guild,
            "title_label":title_label,
            "status_label":status_label,
            "priority_label":priority_label,
            "notebook":notebook,
            "overview_tab":overview_tab,
            "timeline_tab":timeline_tab,
            "outfit_tab":outfit_tab,
            "outfit_start_var":outfit_start_var,
            "outfit_end_var":outfit_end_var,
            "outfit_start_entry":outfit_start_entry,
            "outfit_end_entry":outfit_end_entry,
            "outfit_condition_hint":outfit_condition_hint,
            "outfit_range_key":(
                outfit_start_var.get(),outfit_end_var.get()
            ),
            "timeline_filters":timeline_filters,
            "timeline_limit_var":timeline_limit_var,
            "timeline_limit_entry":timeline_limit_entry,
            "timeline_limit":10,
            "timeline_status":timeline_status,
            "timeline_scroll":timeline_scroll,
            "timeline_events":[],
            "outfit_limit_var":outfit_limit_var,
            "outfit_limit_entry":outfit_limit_entry,
            "outfit_limit":10,
            "outfit_status":outfit_status,
            "outfit_scroll":outfit_scroll,
            "outfits":[],
            "photos":[],
            "api_key":api_key,
            "ocid":None,
            "current_basic":None,
            "active_section":"overview",
            "task_serial":0,
            "task_cancel_event":None,
            "timeline_loaded":False,
            "outfit_loaded":False,
        }
        self.detail_windows[token]=ctx

        outfit_start_entry.bind(
            "<FocusOut>",
            lambda e,t=token:self._normalize_outfit_range(
                t,"start",show_error=False,restart=True
            )
        )
        outfit_end_entry.bind(
            "<FocusOut>",
            lambda e,t=token:self._normalize_outfit_range(
                t,"end",show_error=False,restart=True
            )
        )
        outfit_start_entry.bind(
            "<Return>",
            lambda e,t=token:(
                self._normalize_outfit_range(
                    t,"start",show_error=True,restart=True
                ),
                "break"
            )[1]
        )
        outfit_end_entry.bind(
            "<Return>",
            lambda e,t=token:(
                self._normalize_outfit_range(
                    t,"end",show_error=True,restart=True
                ),
                "break"
            )[1]
        )
        timeline_limit_entry.bind(
            "<FocusOut>",
            lambda e,t=token:self._normalize_detail_limit(
                t,"timeline",show_error=False,restart=True
            )
        )
        timeline_limit_entry.bind(
            "<Return>",
            lambda e,t=token:(
                self._normalize_detail_limit(
                    t,"timeline",show_error=True,restart=True
                ),
                "break"
            )[1]
        )
        outfit_limit_entry.bind(
            "<FocusOut>",
            lambda e,t=token:self._normalize_detail_limit(
                t,"outfit",show_error=False,restart=True
            )
        )
        outfit_limit_entry.bind(
            "<Return>",
            lambda e,t=token:(
                self._normalize_detail_limit(
                    t,"outfit",show_error=True,restart=True
                ),
                "break"
            )[1]
        )

        self._render_timeline_events(token)
        self._render_detail_outfits(token,[],0,0)

        notebook.bind(
            "<<NotebookTabChanged>>",
            lambda e,t=token:self._detail_tab_changed(t)
        )
        notebook.select(overview_tab)

        self.after_idle(
            lambda:self._show_owned_detail_window(win,self,center=True)
        )

    def _detail_worker(self, token, nickname, api_key, cancel_event):
        def emit(*parts):
            self.event_q.put(parts)

        client=AdaptiveApiClient(
            api_key,
            cancel_event,
            log_cb=lambda msg:None,
            base_interval=0.20,
            minimum_interval=0.20,
            cache_dir=self.app_dir / "api_cache",
            cooldown_cb=lambda sec:emit(
                "detail_status",token,
                f"API 제한 대기 {sec}초..." if sec else "API 재시도 중..."
            ),
            pause_event=None,
        )

        try:
            emit("detail_status",token,"캐릭터 식별자 확인 중...")
            id_data=client.get_json("id",{"character_name":nickname})
            ocid=clean_text(id_data.get("ocid"))
            if not ocid:
                raise RuntimeError("캐릭터 식별자를 찾을 수 없습니다.")

            emit("detail_status",token,"현재 기본정보 불러오는 중...")
            basic=client.get_json("character/basic",{"ocid":ocid})
            emit("detail_basic",token,ocid,basic)
            emit("detail_ready",token,ocid,basic)

            current_image=clean_text(basic.get("character_image"))
            if current_image:
                threading.Thread(
                    target=self._detail_image_worker,
                    args=(token,current_image,cancel_event),
                    daemon=True,
                ).start()

        except InterruptedError:
            return
        except Exception as e:
            emit("detail_error",token,str(e))

    def _detail_image_worker(self, token, image_url, cancel_event):
        if cancel_event.is_set():
            return
        raw=_download_image_bytes(image_url)
        if cancel_event.is_set():
            return
        self.event_q.put(("detail_image",token,image_url,raw))


    def _subtract_calendar_months(self, day, months):
        months=max(1,int(months))
        total=day.year*12+(day.month-1)-months
        year=total//12
        month=total%12+1
        last=calendar.monthrange(year,month)[1]
        return day.replace(year=year,month=month,day=min(day.day,last))

    def _normalize_detail_limit(
        self, token, section, show_error=False, restart=False
    ):
        ctx=self.detail_windows.get(token)
        if not ctx:
            return 10

        var_key=f"{section}_limit_var"
        value_key=f"{section}_limit"
        var=ctx.get(var_key)
        old_value=max(1,int(ctx.get(value_key,10) or 10))

        try:
            raw=(var.get() if var is not None else str(old_value)).strip()
            value=int(raw)
            if value<1:
                raise ValueError
        except Exception:
            if var is not None:
                var.set(str(old_value))
            if show_error:
                messagebox.showerror(
                    "조회 개수 확인",
                    "조회 개수는 1 이상의 정수로 입력해 주세요.",
                    parent=ctx.get("win"),
                )
            return old_value

        if var is not None:
            var.set(str(value))
        ctx[value_key]=value

        if section=="outfit":
            try:
                start=parse_flexible_search_date(ctx["outfit_start_var"].get())
                end=parse_flexible_search_date(ctx["outfit_end_var"].get())
                days=max(1,(end-start).days+1)
            except Exception:
                days=0
            ctx["outfit_condition_hint"].configure(
                text=(
                    (f"지정 기간 {days}일 · " if days else "지정 기간 · ")
                    + f"코디 변화 최대 {value}건"
                )
            )

        if restart and value!=old_value:
            if section=="timeline":
                ctx["timeline_loaded"]=False
                current=[
                    ev for ev in ctx.get("timeline_events",[])
                    if ev.get("type")=="current"
                ]
                ctx["timeline_events"]=current
                self._render_timeline_events(token)
            else:
                ctx["outfit_loaded"]=False
                ctx["outfits"]=[]
                self._render_detail_outfits(token,[],0,0)

            try:
                current_tab=ctx["notebook"].nametowidget(
                    ctx["notebook"].select()
                )
            except Exception:
                current_tab=None

            wanted_tab=(
                ctx.get("timeline_tab") if section=="timeline"
                else ctx.get("outfit_tab")
            )
            if current_tab is wanted_tab:
                if section=="timeline":
                    self._start_timeline_history(token)
                else:
                    self._start_outfit_history(token)

        return value


    def _normalize_outfit_range(
        self, token, changed=None, show_error=False, restart=False
    ):
        ctx=self.detail_windows.get(token)
        if not ctx:
            return None

        latest=latest_complete_historical_date_kst()

        try:
            start=parse_flexible_search_date(
                ctx["outfit_start_var"].get()
            )
            end=parse_flexible_search_date(
                ctx["outfit_end_var"].get()
            )
        except ValueError as e:
            if show_error:
                messagebox.showerror(
                    "코디 조회 날짜 확인",
                    str(e),
                    parent=ctx["win"],
                )
            return None

        start=max(DETAIL_HISTORY_START,min(start,latest))
        end=max(DETAIL_HISTORY_START,min(end,latest))

        # If the user crosses the range, keep it valid automatically.
        if start>end:
            if changed=="end":
                start=end
            else:
                end=start

        ctx["outfit_start_var"].set(start.isoformat())
        ctx["outfit_end_var"].set(end.isoformat())

        new_key=(start.isoformat(),end.isoformat())
        old_key=ctx.get("outfit_range_key")
        ctx["outfit_range_key"]=new_key

        days=max(1,(end-start).days+1)
        target=max(1,int(ctx.get("outfit_limit",10) or 10))
        ctx["outfit_condition_hint"].configure(
            text=(
                f"지정 기간 {days}일 · 코디 변화 최대 {target}건"
            )
        )

        if restart and new_key!=old_key:
            old=ctx.get("task_cancel_event")
            if old is not None and ctx.get("active_section")=="outfit":
                old.set()

            ctx["task_serial"]=int(ctx.get("task_serial",0))+1
            ctx["task_cancel_event"]=None
            ctx["outfit_loaded"]=False
            ctx["outfits"]=[]
            self._render_detail_outfits(token,[],0,0)

            try:
                current=ctx["notebook"].nametowidget(
                    ctx["notebook"].select()
                )
            except Exception:
                current=None

            if current is ctx.get("outfit_tab"):
                ctx["active_section"]="overview"
                self._start_outfit_history(token)

        return start,end



    def _open_outfit_date_picker(self, token, which):
        ctx=self.detail_windows.get(token)
        if not ctx:
            return

        if which=="start":
            var=ctx["outfit_start_var"]
            anchor_widget=ctx["outfit_start_entry"]
        else:
            var=ctx["outfit_end_var"]
            anchor_widget=ctx["outfit_end_entry"]

        latest=latest_complete_historical_date_kst()
        try:
            selected=parse_flexible_search_date(var.get())
        except Exception:
            selected=latest
        selected=max(DETAIL_HISTORY_START,min(selected,latest))

        popup=tk.Toplevel(ctx["win"])
        popup.withdraw()
        popup.configure(bg=self.PANEL)
        popup.resizable(False,False)
        popup.overrideredirect(True)

        state={"year":selected.year,"month":selected.month}
        title_var=tk.StringVar()

        outer=tk.Frame(
            popup,
            bg=self.PANEL,
            highlightthickness=1,
            highlightbackground=self.BORDER,
        )
        outer.pack(fill="both",expand=True)

        head=tk.Frame(outer,bg=self.PANEL)
        head.pack(fill="x",padx=8,pady=(7,4))
        head.grid_columnconfigure(1,weight=1)

        weekdays=tk.Frame(outer,bg=self.PANEL)
        weekdays.pack(fill="x",padx=9)

        days_frame=tk.Frame(outer,bg=self.PANEL)
        days_frame.pack(padx=9,pady=(0,6))

        def close_popup():
            self._safe_destroy_popup(popup)

        def choose(day):
            var.set(day.isoformat())
            close_popup()
            self._normalize_outfit_range(
                token,which,show_error=False,restart=True
            )

        def render():
            for child in days_frame.winfo_children():
                child.destroy()

            year,month=state["year"],state["month"]
            title_var.set(f"{year}년 {month}월")
            weeks=calendar.monthcalendar(year,month)

            for r,week in enumerate(weeks):
                for c,num in enumerate(week):
                    days_frame.grid_columnconfigure(c,weight=1)

                    if not num:
                        tk.Label(
                            days_frame,
                            text="",
                            bg=self.PANEL,
                            width=3,
                        ).grid(row=r,column=c,padx=1,pady=1)
                        continue

                    day=datetime(year,month,num).date()
                    allowed=DETAIL_HISTORY_START<=day<=latest
                    is_selected=(day==selected)

                    tk.Button(
                        days_frame,
                        text=str(num),
                        width=3,
                        height=1,
                        relief="flat",
                        bd=0,
                        bg=(
                            "#2A68A8"
                            if is_selected else "#101A28"
                        ),
                        fg=(
                            "#FFFFFF"
                            if allowed else "#566173"
                        ),
                        activebackground="#26496B",
                        activeforeground="#FFFFFF",
                        disabledforeground="#566173",
                        font=(
                            "맑은 고딕",8,
                            "bold" if is_selected else "normal"
                        ),
                        command=(
                            (lambda d=day:choose(d))
                            if allowed else None
                        ),
                        state="normal" if allowed else "disabled",
                    ).grid(row=r,column=c,padx=1,pady=1)

            popup.update_idletasks()

        ttk.Button(
            head,
            text="‹",
            style="Ghost.TButton",
            width=3,
            command=lambda:self._shift_calendar_month(
                state,-1,render,DETAIL_HISTORY_START,latest
            ),
        ).grid(row=0,column=0,sticky="w")

        tk.Label(
            head,
            textvariable=title_var,
            bg=self.PANEL,
            fg=self.TEXT,
            font=("맑은 고딕",9,"bold"),
            anchor="center",
        ).grid(row=0,column=1,sticky="ew",padx=5)

        ttk.Button(
            head,
            text="›",
            style="Ghost.TButton",
            width=3,
            command=lambda:self._shift_calendar_month(
                state,1,render,DETAIL_HISTORY_START,latest
            ),
        ).grid(row=0,column=2,sticky="e")

        tk.Button(
            head,
            text="×",
            command=close_popup,
            bg=self.PANEL,
            fg="#DDE7F4",
            activebackground="#472229",
            activeforeground="#FFFFFF",
            relief="flat",
            bd=0,
            padx=6,
            pady=0,
            cursor="hand2",
            font=("Segoe UI",13,"bold"),
        ).grid(row=0,column=3,sticky="e",padx=(3,0))

        for i,name in enumerate(("월","화","수","목","금","토","일")):
            weekdays.grid_columnconfigure(i,weight=1)
            tk.Label(
                weekdays,
                text=name,
                bg=self.PANEL,
                fg=self.MUTED,
                font=("맑은 고딕",8,"bold"),
                width=3,
            ).grid(row=0,column=i,pady=(0,3))

        render()
        popup.bind("<Escape>",lambda e:close_popup())

        self.after_idle(
            lambda:self._show_borderless_popup(popup,anchor_widget)
        )

    def _outfit_query_window(self, ctx):
        latest=latest_complete_historical_date_kst()

        try:
            start=parse_flexible_search_date(
                ctx["outfit_start_var"].get()
            )
            end=parse_flexible_search_date(
                ctx["outfit_end_var"].get()
            )
        except Exception:
            end=latest
            start=self._subtract_calendar_months(end,6)

        start=max(DETAIL_HISTORY_START,min(start,latest))
        end=max(DETAIL_HISTORY_START,min(end,latest))
        if start>end:
            start=end

        days=max(1,(end-start).days+1)
        label=f"{start.isoformat()} ~ {end.isoformat()}"
        return start,end,days,label

    def _detail_tab_changed(self, token):
        ctx=self.detail_windows.get(token)
        if not ctx:
            return

        notebook=ctx.get("notebook")
        try:
            current=notebook.nametowidget(notebook.select())
        except Exception:
            return

        if current is ctx.get("timeline_tab"):
            section="timeline"
        elif current is ctx.get("outfit_tab"):
            section="outfit"
        else:
            section="overview"

        if ctx.get("active_section")==section:
            return

        # Cancel the previous tab's worker before starting another one.
        old_cancel=ctx.get("task_cancel_event")
        if old_cancel is not None:
            old_cancel.set()

        ctx["task_serial"]=int(ctx.get("task_serial",0))+1
        ctx["task_cancel_event"]=None
        ctx["active_section"]=section

        if section=="overview":
            ctx["status_label"].configure(
                text="원하는 탭을 선택하면 해당 정보만 조회합니다."
            )
            return

        if section=="timeline":
            if ctx.get("timeline_loaded"):
                ctx["status_label"].configure(text="타임라인 조회 완료")
                return
            self._start_timeline_history(token)
        else:
            if ctx.get("outfit_loaded"):
                ctx["status_label"].configure(text="코디 기록 조회 완료")
                return
            self._start_outfit_history(token)

    def _new_detail_task(self, token, section):
        ctx=self.detail_windows.get(token)
        if not ctx:
            return None,None

        old=ctx.get("task_cancel_event")
        if old is not None:
            old.set()

        ctx["task_serial"]=int(ctx.get("task_serial",0))+1
        serial=ctx["task_serial"]
        cancel_event=threading.Event()
        ctx["task_cancel_event"]=cancel_event
        ctx["active_section"]=section
        return serial,cancel_event

    def _detail_event_is_current(self, token, serial, section=None):
        ctx=self.detail_windows.get(token)
        if not ctx:
            return False
        if int(ctx.get("task_serial",-1))!=int(serial):
            return False
        if section is not None and ctx.get("active_section")!=section:
            return False
        return True




    def _start_timeline_history(self, token):
        ctx=self.detail_windows.get(token)
        if not ctx:
            return

        target=self._normalize_detail_limit(
            token,"timeline",show_error=True,restart=False
        )
        serial,cancel_event=self._new_detail_task(token,"timeline")
        if cancel_event is None:
            return

        ctx["timeline_status"].configure(
            text=f"최근 날짜부터 과거 방향으로 레벨 이력 {target}건을 확인합니다..."
        )
        ctx["status_label"].configure(text="타임라인 조회 중...")
        threading.Thread(
            target=self._timeline_worker_precise,
            args=(token,serial,cancel_event),
            daemon=True,
        ).start()

    def _current_outfit_worker(self, token, ocid, basic, api_key, cancel_event):
        def emit(*parts):
            self.event_q.put(parts)

        client=AdaptiveApiClient(
            api_key,cancel_event,
            log_cb=lambda msg:None,
            base_interval=0.20,
            minimum_interval=0.20,
            cache_dir=self.app_dir / "api_cache",
            cooldown_cb=lambda sec:emit(
                "detail_history_status",token,"outfit",
                f"API 제한 대기 {sec}초..." if sec else "API 재시도 중..."
            ),
            pause_event=None,
        )

        try:
            cash=client.get_json("character/cashitem-equipment",{"ocid":ocid})
            ctx=self.detail_windows.get(token)
            row={
                "date":datetime.now(KST).date().isoformat(),
                "summary":_cash_summary(cash),
                "items":_cash_item_list(cash),
                "image_bytes":(ctx or {}).get("current_image_bytes"),
                "current":True,
            }
            emit("detail_outfit_current",token,row,cash)
        except InterruptedError:
            return
        except Exception as e:
            emit(
                "detail_history_status",token,"outfit",
                f"현재 코디 조회 실패: {e}"
            )




    def _start_outfit_history(self, token):
        ctx=self.detail_windows.get(token)
        if not ctx:
            return

        normalized=self._normalize_outfit_range(
            token,changed=None,show_error=True,restart=False
        )
        if normalized is None:
            return

        serial,cancel_event=self._new_detail_task(token,"outfit")
        if cancel_event is None:
            return

        target=self._normalize_detail_limit(
            token,"outfit",show_error=True,restart=False
        )
        start,end=normalized
        ctx["outfit_status"].configure(
            text=(
                f"{start.isoformat()} ~ {end.isoformat()} · "
                f"코디 변화 최대 {target}건을 확인합니다..."
            )
        )
        ctx["status_label"].configure(text="코디 기록 조회 중...")
        threading.Thread(
            target=self._outfit_worker_precise,
            args=(token,serial,cancel_event),
            daemon=True,
        ).start()

    def _detail_get_identity_basic(self, token, serial, cancel_event, section):
        ctx=self.detail_windows.get(token)
        if not ctx:
            raise InterruptedError()

        if ctx.get("ocid") and ctx.get("current_basic"):
            return ctx["ocid"],dict(ctx["current_basic"])

        client=AdaptiveApiClient(
            ctx.get("api_key",""),
            cancel_event,
            log_cb=lambda msg:None,
            base_interval=0.20,
            minimum_interval=0.20,
            cache_dir=self.app_dir / "api_cache",
            cooldown_cb=lambda sec:self.event_q.put((
                "detail_task_status",token,serial,section,
                f"API 제한 대기 {sec}초..." if sec else "API 재시도 중..."
            )),
            pause_event=None,
        )

        self.event_q.put((
            "detail_task_status",token,serial,section,"캐릭터 식별자 확인 중..."
        ))
        id_data=client.get_json(
            "id",{"character_name":ctx.get("nickname","")}
        )
        ocid=clean_text(id_data.get("ocid"))
        if not ocid:
            raise RuntimeError("캐릭터 식별자를 찾을 수 없습니다.")

        self.event_q.put((
            "detail_task_status",token,serial,section,"현재 기본정보 확인 중..."
        ))
        basic=client.get_json("character/basic",{"ocid":ocid})

        self.event_q.put((
            "detail_identity",token,serial,section,ocid,basic
        ))
        return ocid,basic



    def _timeline_worker(self, token, serial, cancel_event):
        section="timeline"
        def emit(kind,*parts):
            self.event_q.put((kind,token,serial,section,*parts))

        try:
            ocid,basic=self._detail_get_identity_basic(
                token,serial,cancel_event,section
            )
            if cancel_event.is_set():
                raise InterruptedError()

            ctx=self.detail_windows.get(token)
            api_key=(ctx or {}).get("api_key","")
            client=AdaptiveApiClient(
                api_key,cancel_event,
                log_cb=lambda msg:None,
                # Fast detail scan. Service-stage keys can use this comfortably.
                # Development keys will automatically back off on 429.
                base_interval=0.08,
                minimum_interval=0.05,
                cache_dir=self.app_dir / "api_cache",
                cooldown_cb=lambda sec:emit(
                    "detail_task_status",
                    f"API 제한 대기 {sec}초..." if sec else "API 재시도 중..."
                ),
                pause_event=None,
            )

            today=datetime.now(KST).date()
            latest=latest_complete_historical_date_kst()
            current_level=0
            try:
                current_level=int((basic or {}).get("character_level") or 0)
            except Exception:
                current_level=0

            target_count=max(1,int((ctx or {}).get("timeline_limit",10) or 10))
            level_floor=max(1,current_level-target_count+1)
            cache={today.isoformat():basic}

            def get_basic(day):
                if cancel_event.is_set():
                    raise InterruptedError()
                key=day.isoformat()
                if key in cache:
                    return cache[key]
                try:
                    data=client.get_json(
                        "character/basic",
                        {"ocid":ocid,"date":key},
                        retries=3,
                        allow_missing=True,
                    )
                except Exception:
                    data=None
                cache[key]=data
                return data

            def has_data(data):
                return bool(data and clean_text(data.get("character_name")))

            def level_of(data):
                try:
                    return int((data or {}).get("character_level") or 0)
                except Exception:
                    return 0

            def field(data,key):
                return clean_text((data or {}).get(key))

            # ------------------------------------------------
            # 1) Find the earliest date relevant to last 10 levels.
            # ------------------------------------------------
            emit(
                "detail_task_status",
                f"최근 {target_count}레벨 시작 지점을 빠르게 찾는 중..."
            )

            start_day=DETAIL_HISTORY_START
            latest_data=get_basic(latest) if latest>=DETAIL_HISTORY_START else None

            if has_data(latest_data) and level_of(latest_data)>=level_floor:
                lo=DETAIL_HISTORY_START
                hi=latest
                while lo<hi:
                    mid=lo+timedelta(days=(hi-lo).days//2)
                    data=get_basic(mid)
                    if has_data(data) and level_of(data)>=level_floor:
                        hi=mid
                    else:
                        lo=mid+timedelta(days=1)
                start_day=lo
            else:
                # If historical data is sparse, cap the fast scan to 730 days.
                start_day=max(
                    DETAIL_HISTORY_START,
                    latest-timedelta(days=729),
                )

            total_span=max(0,(latest-start_day).days)
            emit(
                "detail_task_status",
                f"빠른 탐색 범위 설정 완료 · 약 {total_span+1}일"
            )

            # ------------------------------------------------
            # 2) Build 7-day anchor snapshots.
            # ------------------------------------------------
            anchor_step=7
            anchor_days=[start_day]
            d=start_day
            while d<latest:
                d=min(latest,d+timedelta(days=anchor_step))
                if d!=anchor_days[-1]:
                    anchor_days.append(d)

            # Add live/current endpoint separately.
            if today>latest:
                anchor_days.append(today)

            anchors=[]
            for idx,day in enumerate(anchor_days):
                if cancel_event.is_set():
                    raise InterruptedError()
                data=get_basic(day)
                if has_data(data):
                    anchors.append((day,data))
                if idx%8==0 or idx==len(anchor_days)-1:
                    emit(
                        "detail_task_status",
                        f"빠른 기준점 확인 중 · {idx+1}/{len(anchor_days)}"
                    )

            if not anchors:
                emit("detail_timeline_done",[],0)
                return

            events=[]
            level_event_count=0

            def event_key(ev):
                return (ev.get("type"),ev.get("date"),ev.get("text"))

            def normalized():
                seen={}
                for ev in events:
                    seen[event_key(ev)]=ev
                out=list(seen.values())
                order={"nickname":0,"guild":1,"world":2,"gender":3,"level":4}
                out.sort(
                    key=lambda e:(e.get("date",""),-order.get(e.get("type"),9)),
                    reverse=True,
                )
                return out

            def push(message):
                emit(
                    "detail_timeline_progress",
                    normalized(),
                    len(cache),
                    max(1,len(anchor_days)),
                    level_event_count,
                )
                emit("detail_task_status",message)

            def first_level_date(lo_day,hi_day,target):
                lo,hi=lo_day,hi_day
                while lo<hi:
                    mid=lo+timedelta(days=(hi-lo).days//2)
                    if level_of(get_basic(mid))>=target:
                        hi=mid
                    else:
                        lo=mid+timedelta(days=1)
                return lo if level_of(get_basic(lo))>=target else None

            # Daily-scan only a small changed anchor interval.
            def scan_field_changes(lo_day,hi_day,newer_endpoint):
                found=[]
                newer_day=hi_day
                newer=newer_endpoint
                day=hi_day-timedelta(days=1)
                while day>=lo_day:
                    older=get_basic(day)
                    if not has_data(older):
                        day-=timedelta(days=1)
                        continue

                    event_date=newer_day.isoformat()
                    for key,etype,label in (
                        ("character_name","nickname","닉네임"),
                        ("character_guild_name","guild","길드"),
                        ("world_name","world","월드"),
                        ("character_gender","gender","성별"),
                    ):
                        old=field(older,key)
                        new=field(newer,key)
                        if old==new:
                            continue

                        if etype=="guild":
                            if old and new:
                                msg=f"{old} → {new}"
                            elif new:
                                msg=f"{new} 길드 가입"
                            else:
                                msg=f"{old} 길드 탈퇴"
                        elif etype=="world":
                            msg=f"{old} → {new} 월드 이동"
                        elif etype=="nickname":
                            msg=f"{old} → {new}"
                        else:
                            msg=f"{old} → {new}"

                        found.append({
                            "type":etype,
                            "date":event_date,
                            "text":msg,
                            "detail":f"동일 OCID의 일 단위 {label} 변화",
                        })

                    newer_day=day
                    newer=older
                    day-=timedelta(days=1)
                return found

            # ------------------------------------------------
            # 3) Analyze recent intervals first.
            # ------------------------------------------------
            intervals=list(zip(anchors,anchors[1:]))
            for idx,((old_day,old_data),(new_day,new_data)) in enumerate(
                reversed(intervals),start=1
            ):
                if cancel_event.is_set():
                    raise InterruptedError()

                # Exact level-up dates.
                old_lv=level_of(old_data)
                new_lv=level_of(new_data)
                if new_lv>old_lv:
                    targets=list(range(max(old_lv+1,level_floor),new_lv+1))
                    for target in reversed(targets):
                        found=first_level_date(old_day,new_day,target)
                        if found:
                            events.append({
                                "type":"level",
                                "date":found.isoformat(),
                                "text":f"Lv.{target} 달성",
                                "detail":"빠른 기준점 탐색 후 일 단위 정확 날짜 확인",
                            })
                            level_event_count+=1
                            push(
                                f"레벨업 {level_event_count}/{target_count} · "
                                f"타임라인 이벤트 {len(normalized())}건"
                            )

                # Other changes: only open the interval if endpoints differ.
                fields=("character_name","character_guild_name","world_name","character_gender")
                if any(field(old_data,k)!=field(new_data,k) for k in fields):
                    changes=scan_field_changes(old_day,new_day,new_data)
                    if changes:
                        events.extend(changes)
                        push(
                            f"닉네임/길드/월드/성별 변화 확인 · "
                            f"이벤트 {len(normalized())}건"
                        )

                if idx%5==0:
                    emit(
                        "detail_task_status",
                        f"빠른 타임라인 분석 중 · {idx}/{max(1,len(intervals))} 구간"
                    )

            final_events=normalized()
            emit("detail_timeline_done",final_events,level_event_count)

        except InterruptedError:
            return
        except Exception as e:
            emit("detail_task_error",str(e))


    def _timeline_worker_precise(self, token, serial, cancel_event):
        section="timeline"
        def emit(kind,*parts):
            self.event_q.put((kind,token,serial,section,*parts))

        try:
            ocid,basic=self._detail_get_identity_basic(
                token,serial,cancel_event,section
            )
            if cancel_event.is_set():
                raise InterruptedError()

            ctx=self.detail_windows.get(token)
            api_key=(ctx or {}).get("api_key","")
            client=AdaptiveApiClient(
                api_key,cancel_event,
                log_cb=lambda msg:None,
                # Safe for development-stage 5 req/sec.
                base_interval=0.18,
                minimum_interval=0.18,
                cache_dir=self.app_dir / "api_cache",
                cooldown_cb=lambda sec:emit(
                    "detail_task_status",
                    f"API 제한 대기 {sec}초..." if sec else "API 재시도 중..."
                ),
                pause_event=None,
            )

            today=datetime.now(KST).date()
            latest=latest_complete_historical_date_kst()
            max_days=max(1,(latest-DETAIL_HISTORY_START).days+1)
            target_count=max(1,int((ctx or {}).get("timeline_limit",10) or 10))
            events=[]
            level_event_count=0

            newer_day=today
            newer=basic

            def level_of(data):
                try:
                    return int((data or {}).get("character_level") or 0)
                except Exception:
                    return 0

            def field(data,key):
                return clean_text((data or {}).get(key))

            def normalized():
                seen={}
                for ev in events:
                    seen[(ev.get("type"),ev.get("date"),ev.get("text"))]=ev
                out=list(seen.values())
                order={"nickname":0,"guild":1,"world":2,"gender":3,"level":4}
                out.sort(
                    key=lambda e:(e.get("date",""),-order.get(e.get("type"),9)),
                    reverse=True,
                )
                return out

            for offset in range(max_days):
                if cancel_event.is_set():
                    raise InterruptedError()

                day=latest-timedelta(days=offset)
                if day<DETAIL_HISTORY_START:
                    break

                try:
                    older=client.get_json(
                        "character/basic",
                        {"ocid":ocid,"date":day.isoformat()},
                        retries=3,
                        allow_missing=True,
                    )
                except Exception:
                    older=None

                if not older:
                    if offset%10==0:
                        emit(
                            "detail_task_status",
                            f"{offset+1}일 확인 · 이벤트 {len(events)}건"
                        )
                    continue

                event_date=newer_day.isoformat()
                changed=False

                old_lv=level_of(older)
                new_lv=level_of(newer)
                if new_lv>old_lv:
                    for lv in range(new_lv,old_lv,-1):
                        if level_event_count>=target_count:
                            break
                        events.append({
                            "type":"level",
                            "date":event_date,
                            "text":f"Lv.{lv} 달성",
                            "detail":"하루 단위 캐릭터 정보 비교",
                        })
                        level_event_count+=1
                        changed=True

                for key,etype,label in (
                    ("character_name","nickname","닉네임"),
                    ("character_guild_name","guild","길드"),
                    ("world_name","world","월드"),
                    ("character_gender","gender","성별"),
                ):
                    old=field(older,key)
                    new=field(newer,key)
                    if old==new:
                        continue

                    if etype=="guild":
                        if old and new:
                            msg=f"{old} → {new}"
                        elif new:
                            msg=f"{new} 길드 가입"
                        else:
                            msg=f"{old} 길드 탈퇴"
                    elif etype=="world":
                        msg=f"{old} → {new} 월드 이동"
                    elif etype=="nickname":
                        msg=f"{old} → {new}"
                    else:
                        msg=f"{old} → {new}"

                    events.append({
                        "type":etype,
                        "date":event_date,
                        "text":msg,
                        "detail":f"하루 단위 {label} 정보 비교",
                    })
                    changed=True

                if changed:
                    current=normalized()
                    emit(
                        "detail_timeline_progress",
                        current,
                        offset+1,
                        max_days,
                        level_event_count,
                    )

                newer_day=day
                newer=older

                if offset%5==0:
                    emit(
                        "detail_task_status",
                        f"{offset+1}일 확인 · "
                        f"이벤트 {len(normalized())}건 · 레벨 {level_event_count}/{target_count}"
                    )

                if level_event_count>=target_count:
                    break

            emit("detail_timeline_done",normalized(),level_event_count)

        except InterruptedError:
            return
        except Exception as e:
            emit("detail_task_error",str(e))


    def _outfit_worker(self, token, serial, cancel_event):
        section="outfit"
        def emit(kind,*parts):
            self.event_q.put((kind,token,serial,section,*parts))

        try:
            ocid,basic=self._detail_get_identity_basic(
                token,serial,cancel_event,section
            )
            if cancel_event.is_set():
                raise InterruptedError()

            ctx=self.detail_windows.get(token)
            api_key=(ctx or {}).get("api_key","")
            client=AdaptiveApiClient(
                api_key,cancel_event,
                log_cb=lambda msg:None,
                base_interval=0.08,
                minimum_interval=0.05,
                cache_dir=self.app_dir / "api_cache",
                cooldown_cb=lambda sec:emit(
                    "detail_task_status",
                    f"API 제한 대기 {sec}초..." if sec else "API 재시도 중..."
                ),
                pause_event=None,
            )

            today=datetime.now(KST).date()
            latest=latest_complete_historical_date_kst()
            window=self._outfit_query_window(ctx)
            if len(window)==4:
                history_start,history_end,max_days,scope_label=window
            else:
                history_start,max_days,scope_label=window
                history_end=latest
            target_count=max(1,int((ctx or {}).get("outfit_limit",10) or 10))
            ctx["outfit_scope_label"]=scope_label

            # Current outfit immediately.
            try:
                current_cash=client.get_json(
                    "character/cashitem-equipment",{"ocid":ocid}
                )
            except Exception:
                current_cash={}

            current_image=clean_text((basic or {}).get("character_image"))
            outfits=[{
                "date":"현재",
                "summary":_cash_summary(current_cash),
                "items":_cash_item_list(current_cash),
                "image_bytes":None,
                "image_url":current_image,
                "current":True,
            }]
            emit("detail_outfit_progress",list(outfits),0,max_days)

            if current_image:
                threading.Thread(
                    target=self._detail_outfit_image_worker,
                    args=(token,serial,section,"현재",current_image,cancel_event),
                    daemon=True,
                ).start()

            cache={today.isoformat():basic}

            def get_basic(day):
                if cancel_event.is_set():
                    raise InterruptedError()
                key=day.isoformat()
                if key in cache:
                    return cache[key]
                try:
                    data=client.get_json(
                        "character/basic",
                        {"ocid":ocid,"date":key},
                        retries=3,
                        allow_missing=True,
                    )
                except Exception:
                    data=None
                cache[key]=data
                return data

            def image_of(data):
                return clean_text((data or {}).get("character_image"))

            # 3-day anchors.
            anchor_step=3
            anchor_days=[history_start]
            d=history_start
            while d<latest:
                d=min(latest,d+timedelta(days=anchor_step))
                if d!=anchor_days[-1]:
                    anchor_days.append(d)
            anchor_days.append(today)

            anchors=[]
            for idx,day in enumerate(anchor_days):
                data=get_basic(day)
                if data:
                    anchors.append((day,data))
                if idx%10==0 or idx==len(anchor_days)-1:
                    emit(
                        "detail_task_status",
                        f"코디 기준점 확인 중 · {idx+1}/{len(anchor_days)}"
                    )

            async_image_dates=set()

            def add_outfit(day,data):
                nonlocal outfits
                image=image_of(data)
                if not image:
                    return

                date_str=day.isoformat()
                if any(x.get("date")==date_str for x in outfits):
                    return

                try:
                    cash=client.get_json(
                        "character/cashitem-equipment",
                        {"ocid":ocid,"date":date_str},
                        retries=3,
                        allow_missing=True,
                    ) or {}
                except Exception:
                    cash={}

                row={
                    "date":date_str,
                    "summary":_cash_summary(cash),
                    "items":_cash_item_list(cash),
                    "image_bytes":None,
                    "image_url":image,
                    "current":False,
                }
                outfits.append(row)
                # Keep current first, then dates descending.
                current=[x for x in outfits if x.get("current")]
                hist=[x for x in outfits if not x.get("current")]
                hist.sort(key=lambda x:x.get("date",""),reverse=True)
                outfits=current+hist
                emit(
                    "detail_outfit_progress",
                    list(outfits),
                    len(cache),
                    max_days,
                )

                if date_str not in async_image_dates:
                    async_image_dates.add(date_str)
                    threading.Thread(
                        target=self._detail_outfit_image_worker,
                        args=(token,serial,section,date_str,image,cancel_event),
                        daemon=True,
                    ).start()

            # Recent intervals first.
            for idx,((old_day,old_data),(new_day,new_data)) in enumerate(
                reversed(list(zip(anchors,anchors[1:]))),start=1
            ):
                history_count=sum(
                    1 for x in outfits if not x.get("current")
                )
                if history_count>=target_count:
                    break
                old_img=image_of(old_data)
                new_img=image_of(new_data)

                if old_img!=new_img:
                    # Only this tiny 3-day interval needs daily precision.
                    newer_day=new_day
                    newer_data=new_data
                    day=new_day-timedelta(days=1)
                    while (
                        day>=old_day
                        and sum(1 for x in outfits if not x.get("current"))<target_count
                    ):
                        older=get_basic(day)
                        if older:
                            if image_of(older)!=image_of(newer_data):
                                # newer_day is the first day of the newer appearance.
                                add_outfit(newer_day,newer_data)
                            newer_day=day
                            newer_data=older
                        day-=timedelta(days=1)

                if idx%8==0:
                    emit(
                        "detail_task_status",
                        f"빠른 코디 탐색 중 · {idx}구간 · {len(outfits)}건 발견"
                    )

            emit(
                "detail_outfit_done",
                list(outfits),
                min(max_days,len(cache)),
                max_days,
            )

        except InterruptedError:
            return
        except Exception as e:
            emit("detail_task_error",str(e))

    def _outfit_worker_precise(self, token, serial, cancel_event):
        section="outfit"
        def emit(kind,*parts):
            self.event_q.put((kind,token,serial,section,*parts))

        try:
            ocid,basic=self._detail_get_identity_basic(
                token,serial,cancel_event,section
            )
            if cancel_event.is_set():
                raise InterruptedError()

            ctx=self.detail_windows.get(token)
            api_key=(ctx or {}).get("api_key","")
            client=AdaptiveApiClient(
                api_key,cancel_event,
                log_cb=lambda msg:None,
                base_interval=0.18,
                minimum_interval=0.18,
                cache_dir=self.app_dir / "api_cache",
                cooldown_cb=lambda sec:emit(
                    "detail_task_status",
                    f"API 제한 대기 {sec}초..." if sec else "API 재시도 중..."
                ),
                pause_event=None,
            )

            today=datetime.now(KST).date()
            history_start,history_end,max_days,scope_label=(
                self._outfit_query_window(ctx)
            )
            target_count=max(1,int((ctx or {}).get("outfit_limit",10) or 10))

            try:
                current_cash=client.get_json(
                    "character/cashitem-equipment",{"ocid":ocid}
                )
            except Exception:
                current_cash={}

            current_image=clean_text((basic or {}).get("character_image"))
            outfits=[{
                "date":"현재",
                "summary":_cash_summary(current_cash),
                "items":_cash_item_list(current_cash),
                "image_bytes":None,
                "image_url":current_image,
                "current":True,
            }]
            emit("detail_outfit_progress",list(outfits),0,max_days)

            if current_image:
                threading.Thread(
                    target=self._detail_outfit_image_worker,
                    args=(token,serial,section,"현재",current_image,cancel_event),
                    daemon=True,
                ).start()

            last_image=current_image
            image_dates={"현재"}

            for offset in range(max_days):
                if cancel_event.is_set():
                    raise InterruptedError()
                history_count=sum(
                    1 for x in outfits if not x.get("current")
                )
                if history_count>=target_count:
                    break

                day=history_end-timedelta(days=offset)
                if day<history_start:
                    break

                try:
                    hist=client.get_json(
                        "character/basic",
                        {"ocid":ocid,"date":day.isoformat()},
                        retries=3,
                        allow_missing=True,
                    )
                except Exception:
                    hist=None

                if not hist:
                    continue

                image=clean_text(hist.get("character_image"))
                if not image:
                    continue

                # Moving recent -> past: when the image differs, the current
                # day is the first observed day of the older appearance.
                if image!=last_image:
                    date_str=day.isoformat()
                    try:
                        cash=client.get_json(
                            "character/cashitem-equipment",
                            {"ocid":ocid,"date":date_str},
                            retries=3,
                            allow_missing=True,
                        ) or {}
                    except Exception:
                        cash={}

                    row={
                        "date":date_str,
                        "summary":_cash_summary(cash),
                        "items":_cash_item_list(cash),
                        "image_bytes":None,
                        "image_url":image,
                        "current":False,
                    }
                    outfits.append(row)
                    last_image=image

                    emit(
                        "detail_outfit_progress",
                        list(outfits),
                        offset+1,
                        max_days,
                    )

                    if date_str not in image_dates:
                        image_dates.add(date_str)
                        threading.Thread(
                            target=self._detail_outfit_image_worker,
                            args=(
                                token,serial,section,date_str,
                                image,cancel_event
                            ),
                            daemon=True,
                        ).start()

                if offset%5==0:
                    emit(
                        "detail_task_status",
                        f"코디 조회 · {offset+1}/{max_days}일 · "
                        f"{len(outfits)}건 발견"
                    )

            emit(
                "detail_outfit_done",
                list(outfits),
                min(max_days,offset+1 if 'offset' in locals() else 0),
                max_days,
            )

        except InterruptedError:
            return
        except Exception as e:
            emit("detail_task_error",str(e))


    def _detail_outfit_image_worker(
        self, token, serial, section, row_date, image_url, cancel_event
    ):
        if cancel_event.is_set():
            return
        raw=_download_image_bytes(image_url)
        if cancel_event.is_set():
            return
        self.event_q.put((
            "detail_outfit_image",
            token,serial,section,row_date,raw
        ))

    def _detail_photo(self, ctx, raw):
        if not raw:
            return None
        try:
            encoded=base64.b64encode(raw).decode("ascii")
            photo=tk.PhotoImage(data=encoded)
            ctx["photos"].append(photo)
            return photo
        except Exception:
            return None


    def _render_detail_basic(self, token, ocid, basic):
        ctx=self.detail_windows.get(token)
        if not ctx:
            return
        win=ctx["win"]
        if not win.winfo_exists():
            return

        ctx["ocid"]=ocid
        ctx["current_basic"]=basic or {}
        ctx["current_image_url"]=clean_text((basic or {}).get("character_image"))

        name=clean_text((basic or {}).get("character_name")) or ctx["nickname"]
        world=clean_text((basic or {}).get("world_name"))
        level=clean_text((basic or {}).get("character_level"))
        job=clean_text((basic or {}).get("character_class"))
        guild=clean_text((basic or {}).get("character_guild_name")) or "-"
        gender=clean_text((basic or {}).get("character_gender")) or "-"

        ctx["title_label"].configure(text=name)
        ctx["info_label"].configure(
            text=(
                f"월드  {world or '-'}     레벨  Lv.{level or '-'}     직업  {job or '-'}\\n"
                f"길드  {guild}     성별  {gender}\\n\\n"
                "현재 정보 표시 완료 · 과거 이력을 순차적으로 불러오고 있습니다."
            )
        )
        ctx["status_label"].configure(text="현재 정보 완료 · 과거 이력 조회 중...")

        current_event={
            "type":"current",
            "date":"현재",
            "text":f"Lv.{level or '-'} · {world or '-'} · {job or '-'}",
            "detail":f"길드: {guild} · 성별: {gender}",
        }
        historical=[
            ev for ev in ctx.get("timeline_events",[])
            if ev.get("type")!="current"
        ]
        ctx["timeline_events"]=[current_event] + historical
        self._render_timeline_events(token)

        # Preload today's outfit immediately.  Past outfit history is still
        # lazy and starts only when the outfit tab is opened.
        threading.Thread(
            target=self._current_outfit_worker,
            args=(
                token,ocid,dict(basic or {}),
                ctx.get("api_key",""),
                ctx.get("cancel_event"),
            ),
            daemon=True,
        ).start()

        self._start_timeline_history(token)


    def _render_detail_image(self, token, image_url, raw):
        ctx=self.detail_windows.get(token)
        if not ctx:
            return
        ctx["current_image_url"]=image_url or ""
        ctx["current_image_bytes"]=raw
        photo=self._detail_photo(ctx,raw)
        if photo is not None:
            ctx["image_label"].configure(image=photo,text="",width=0,height=0)
        else:
            ctx["image_label"].configure(text="캐릭터 이미지\\n표시 불가")

        outfits=ctx.get("outfits") or []
        if outfits and outfits[0].get("current"):
            outfits[0]["image_bytes"]=raw
            ctx["outfits"]=outfits
            self._render_detail_outfits(token,outfits,0,120)

    def _render_detail_timeline(self, token, events, meta):
        ctx=self.detail_windows.get(token)
        if not ctx:
            return
        ctx["timeline_loading"]=False
        ctx["timeline_loaded"]=True
        current=[
            ev for ev in ctx.get("timeline_events",[])
            if ev.get("type")=="current"
        ]
        ctx["timeline_events"]=current + list(events or [])
        first=meta.get("first_date") or "확인 가능한 최초일"
        ctx["timeline_status"].configure(
            text=(
                f"{first} 이후 · 최근 {max(1,int(ctx.get('timeline_limit',10) or 10))}레벨 + 닉네임/길드/월드/성별 변화"
            )
        )
        self._render_timeline_events(token)

    def _render_timeline_events(self, token):
        ctx=self.detail_windows.get(token)
        if not ctx:
            return
        parent=ctx["timeline_scroll"].interior
        for child in parent.winfo_children():
            child.destroy()

        filters=ctx["timeline_filters"]
        events=[
            ev for ev in ctx.get("timeline_events",[])
            if filters.get(ev.get("type")) is None
            or filters[ev.get("type")].get()
        ]

        colors={
            "current":("#172A3F","#A9D8FF","현재"),
            "nickname":("#2A1638","#E6B8FF","닉네임"),
            "guild":("#123326","#A9F0CA","길드"),
            "world":("#132D42","#A9D8FF","월드"),
            "gender":("#2D2140","#E6C4FF","성별"),
            "level":("#3A2A17","#FFD6A0","레벨"),
        }

        if not events:
            loading=(ctx.get("active_section")=="timeline")
            tk.Label(
                parent,
                text=(
                    "최근 날짜부터 과거 방향으로 탐색 중입니다..."
                    if loading
                    else "타임라인 탭을 선택하면 조회를 시작합니다."
                ),
                bg=self.BG,fg=self.MUTED,font=("맑은 고딕",10),pady=24
            ).pack(fill="x")
            return

        for ev in events:
            card=tk.Frame(
                parent,bg=self.PANEL,highlightthickness=1,
                highlightbackground=self.BORDER
            )
            card.pack(fill="x",padx=(2,10),pady=5)
            # 날짜 아래 카테고리 배지가 잘리지 않도록 좌측 영역에 최소 높이를 확보합니다.
            left=tk.Frame(card,bg=self.PANEL,width=136,height=50)
            left.pack(side="left",fill="y",padx=(14,10),pady=8)
            left.pack_propagate(False)
            tk.Label(
                left,text=ev.get("date","-"),bg=self.PANEL,fg=self.MUTED,
                font=("맑은 고딕",9),anchor="w",justify="left"
            ).pack(anchor="w")
            bg,fg,label=colors.get(ev.get("type"),("#202633",self.TEXT,"이력"))
            badge=tk.Label(
                left,text=label,bg=bg,fg=fg,padx=8,pady=2,
                font=("맑은 고딕",8,"bold"),anchor="w",justify="left"
            )
            badge.pack(anchor="w",pady=(6,0))

            right=tk.Frame(card,bg=self.PANEL)
            right.pack(side="left",fill="both",expand=True,padx=(0,14),pady=10)
            tk.Label(
                right,text=ev.get("text",""),bg=self.PANEL,fg=self.TEXT,
                anchor="w",justify="left",font=("맑은 고딕",10,"bold")
            ).pack(fill="x")
            detail=clean_text(ev.get("detail"))
            if detail in ("하루 단위 캐릭터 정보 비교", "동일 OCID의 일 단위 닉네임 변화", "동일 OCID의 일 단위 길드 변화", "동일 OCID의 일 단위 월드 변화", "동일 OCID의 일 단위 성별 변화", "하루 단위 닉네임 정보 비교", "하루 단위 길드 정보 비교", "하루 단위 월드 정보 비교", "하루 단위 성별 정보 비교"):
                detail=""
            if detail:
                tk.Label(
                    right,text=detail,bg=self.PANEL,fg=self.MUTED,
                    anchor="w",justify="left",font=("맑은 고딕",8)
                ).pack(fill="x",pady=(4,0))

        ctx["timeline_scroll"].scroll_to_top()

    def _render_detail_outfit_progress(self, token, outfits, scanned, max_days):
        # Reuse the final gallery renderer so newly discovered outfits appear
        # immediately while the background scan continues.
        self._render_detail_outfits(token,outfits,scanned,max_days)
        ctx=self.detail_windows.get(token)
        if ctx and not ctx.get("outfit_loaded"):
            history_count=sum(1 for x in (outfits or []) if not x.get("current"))
            target_count=max(1,int(ctx.get("outfit_limit",10) or 10))
            ctx["outfit_status"].configure(
                text=(
                    f"코디 변화 {history_count}/{target_count}건 발견 · "
                    f"최근 {scanned}/{max_days}일 탐색 중..."
                )
            )

    def _render_detail_outfits(self, token, outfits, scanned, max_days):
        ctx=self.detail_windows.get(token)
        if not ctx:
            return
        ctx["outfits"]=outfits or []
        parent=ctx["outfit_scroll"].interior
        for child in parent.winfo_children():
            child.destroy()

        cols=3
        for c in range(cols):
            parent.grid_columnconfigure(c,weight=1,uniform="outfit")

        if not ctx["outfits"]:
            tk.Label(
                parent,
                text=(
                    "최근 코디를 탐색 중입니다..."
                    if ctx.get("active_section")=="outfit"
                    else "코디 기록 탭을 선택하면 조회를 시작합니다."
                ),
                bg=self.BG,fg=self.MUTED,font=("맑은 고딕",10),pady=24
            ).grid(row=0,column=0,columnspan=cols,sticky="ew")
            ctx["outfit_status"].configure(
                text=(
                    "코디 기록 조회 중..."
                    if ctx.get("active_section")=="outfit"
                    else "코디 기록 탭을 선택하면 조회를 시작합니다."
                )
            )
            return

        for idx,row in enumerate(ctx["outfits"]):
            r=idx//cols
            c=idx%cols
            card=tk.Frame(
                parent,bg=self.PANEL,highlightthickness=1,
                highlightbackground=self.BORDER
            )
            card.grid(row=r,column=c,sticky="nsew",padx=6,pady=6)
            photo=self._detail_photo(ctx,row.get("image_bytes"))
            image=tk.Label(
                card,bg=self.PANEL,fg=self.MUTED,
                text="이미지 없음" if photo is None else "",
                image=photo if photo is not None else "",
                padx=10,pady=10
            )
            image.pack(pady=(12,4))
            tk.Label(
                card,text=f"♡  {row.get('date','-')}",
                bg=self.PANEL,fg=self.MUTED,font=("맑은 고딕",9)
            ).pack(pady=(2,6))
            ttk.Button(
                card,text="코디 상세",style="Ghost.TButton",
                command=lambda i=idx,t=token:self._open_outfit_detail(t,i)
            ).pack(pady=(0,12))

        history_count=sum(
            1 for x in ctx["outfits"] if not x.get("current")
        )
        target_count=max(1,int(ctx.get("outfit_limit",10) or 10))
        start=ctx["outfit_start_var"].get()
        end=ctx["outfit_end_var"].get()

        if history_count>=target_count:
            msg=(
                f"{start} ~ {end} · 코디 변화 {history_count}/{target_count}건 확인 완료"
            )
        else:
            msg=(
                f"{start} ~ {end} · 코디 변화 {history_count}건 · "
                f"{scanned}일 확인"
            )
        ctx["outfit_status"].configure(text=msg)
        ctx["outfit_scroll"].scroll_to_top()

    def _open_outfit_detail(self, token, index):
        ctx=self.detail_windows.get(token)
        if not ctx:
            return
        try:
            row=ctx["outfits"][index]
        except Exception:
            return

        pop=tk.Toplevel(ctx["win"])
        pop.title(f"코디 상세 · {row.get('date','')}")
        pop.geometry("520x620")
        pop.minsize(420,460)
        pop.configure(bg=self.BG)
        try:
            if self.window_icon is not None:
                pop.iconphoto(True,self.window_icon)
        except Exception:
            pass

        tk.Label(
            pop,text=row.get("date",""),bg=self.BG,fg=self.TEXT,
            font=("맑은 고딕",15,"bold")
        ).pack(pady=(16,8))
        photo=self._detail_photo(ctx,row.get("image_bytes"))
        img=tk.Label(pop,bg=self.BG,fg=self.MUTED)
        if photo is not None:
            img.configure(image=photo)
        else:
            img.configure(text="이미지 표시 불가")
        img.pack(pady=(0,10))

        body=tk.Frame(pop,bg=self.PANEL)
        body.pack(fill="both",expand=True,padx=16,pady=(0,10))
        body.grid_rowconfigure(0,weight=1)
        body.grid_columnconfigure(0,weight=1)
        txt=tk.Text(
            body,wrap="word",bg="#0A1018",fg="#DCE6F3",
            relief="flat",borderwidth=0,padx=12,pady=12,
            font=("맑은 고딕",9)
        )
        sb=ttk.Scrollbar(body,orient="vertical",command=txt.yview)
        txt.configure(yscrollcommand=sb.set)
        txt.grid(row=0,column=0,sticky="nsew")
        sb.grid(row=0,column=1,sticky="ns")
        items=row.get("items") or []
        if items:
            for item in items:
                part=item.get("part") or "부위 미상"
                txt.insert("end",f"• {part}\n  {item.get('name','')}\n\n")
        else:
            txt.insert("end","코디 아이템 정보를 확인할 수 없습니다.")
        txt.configure(state="disabled")
        ttk.Button(pop,text="닫기",style="Ghost.TButton",command=pop.destroy).pack(pady=(0,14))



    def _handle_detail_event(self, ev):
        kind=ev[0]

        if kind in (
            "detail_task_status","detail_identity",
            "detail_timeline_progress","detail_timeline_done",
            "detail_outfit_progress","detail_outfit_done",
            "detail_outfit_image","detail_task_error"
        ):
            token,serial,section=ev[1],ev[2],ev[3]
            if not self._detail_event_is_current(token,serial,section):
                return
            ctx=self.detail_windows.get(token)
            if not ctx:
                return

            if kind=="detail_task_status":
                msg=ev[4]
                ctx["status_label"].configure(text=msg)
                if section=="timeline":
                    ctx["timeline_status"].configure(text=msg)
                else:
                    ctx["outfit_status"].configure(text=msg)
                return

            if kind=="detail_identity":
                _,_,_,_,ocid,basic=ev
                ctx["ocid"]=ocid
                ctx["current_basic"]=basic or {}
                return

            if kind=="detail_timeline_progress":
                events,days_checked,max_days,level_count=ev[4],ev[5],ev[6],ev[7]
                ctx["timeline_events"]=list(events or [])
                self._render_timeline_events(token)
                target_count=max(1,int(ctx.get("timeline_limit",10) or 10))
                ctx["timeline_status"].configure(
                    text=(
                        f"최근 → 과거 · {days_checked}일 확인 · "
                        f"이벤트 {len(events)}건 · 레벨 {level_count}/{target_count}"
                    )
                )
                return

            if kind=="detail_timeline_done":
                events,level_count=ev[4],ev[5]
                ctx["timeline_events"]=list(events or [])
                ctx["timeline_loaded"]=True
                self._render_timeline_events(token)
                ctx["timeline_status"].configure(
                    text=(f"조회 완료 · 이벤트 {len(events)}건 · 레벨 {level_count}/"
                          f"{max(1,int(ctx.get('timeline_limit',10) or 10))}건")
                )
                ctx["status_label"].configure(text="타임라인 조회 완료")
                return

            if kind=="detail_outfit_progress":
                outfits,scanned,max_days=ev[4],ev[5],ev[6]
                ctx["outfits"]=list(outfits or [])
                self._render_detail_outfits(token,ctx["outfits"],scanned,max_days)
                return

            if kind=="detail_outfit_image":
                row_date,raw=ev[4],ev[5]
                changed=False
                for row in ctx.get("outfits",[]):
                    if row.get("date")==row_date:
                        row["image_bytes"]=raw
                        changed=True
                        break
                if changed:
                    self._render_detail_outfits(
                        token,ctx.get("outfits",[]),0,120
                    )
                return

            if kind=="detail_outfit_done":
                outfits,scanned,max_days=ev[4],ev[5],ev[6]
                ctx["outfits"]=list(outfits or [])
                ctx["outfit_loaded"]=True
                self._render_detail_outfits(token,ctx["outfits"],scanned,max_days)
                ctx["status_label"].configure(text="코디 기록 조회 완료")
                return

            if kind=="detail_task_error":
                msg=ev[4]
                ctx["status_label"].configure(text="상세 조회 오류")
                if section=="timeline":
                    ctx["timeline_status"].configure(text="타임라인 조회 오류")
                else:
                    ctx["outfit_status"].configure(text="코디 기록 조회 오류")
                messagebox.showerror(
                    "캐릭터 상세정보 오류",msg,parent=ctx["win"]
                )
                return

        # Ignore legacy/stale detail events from previous builds/workers.

    def _insert_result(self,row):
        vals=[row.get(k,"") for k in ("닉네임","월드","레벨","직업","길드","장비명","스타포스","추가옵션","잠재등급","잠재1","잠재2","잠재3","에디등급","에디1","에디2","에디3","장비출처")]
        self.tree.insert("","end",values=vals)

    def _append_log(self,msg):
        self.log_text.insert("end",msg+"\n"); self.log_text.see("end")

    def _export_csv(self):
        if not self.results:
            messagebox.showinfo("결과 없음","저장할 결과가 없습니다."); return
        path=filedialog.asksaveasfilename(title="결과 CSV 저장",defaultextension=".csv",filetypes=[("CSV","*.csv")],initialfile="maple_equipment_results.csv")
        if not path: return
        fields=list(self.results[0].keys())
        with open(path,"w",encoding="utf-8-sig",newline="") as f:
            w=csv.DictWriter(f,fieldnames=fields); w.writeheader(); w.writerows(self.results)
        messagebox.showinfo("저장 완료",path)


if __name__=="__main__":
    App().mainloop()
