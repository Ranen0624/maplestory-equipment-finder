﻿@echo off
cd /d "%~dp0"
start "" wscript.exe "%~dp0메이플 장비 검색기.vbs"
