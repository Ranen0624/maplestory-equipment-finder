# -*- coding: utf-8 -*-
from __future__ import annotations
from PySide6.QtCore import Qt, QSize
from PySide6.QtGui import QPixmap, QIcon
from PySide6.QtWidgets import QFrame,QLabel,QPushButton,QHBoxLayout,QVBoxLayout,QButtonGroup,QDialog,QWidget,QSizePolicy,QMessageBox
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent

SHELL_QSS = r"""
QWidget{font-family:"Malgun Gothic";font-size:12px;color:#EEF5FF;}
#shellRoot{background:#061225;border:1px solid #1B3B61;}
#integratedTitlebar{background:qlineargradient(x1:0,y1:0,x2:1,y2:0,stop:0 #0B1734,stop:1 #07111F);border-bottom:1px solid #1B3B61;}
#brandTitle{font-size:16px;font-weight:800;} #version{color:#8EA2C4;font-size:11px;} #brandSub{color:#6F89B0;font-size:8px;letter-spacing:2px;}
QPushButton{border:none;}
#navButton{background:transparent;color:#B9C7E0;padding:10px 8px;border-radius:7px;font-weight:650;min-width:92px;max-width:92px;}
#navButton:hover{background:#112849;color:#FFFFFF;}
#navButton:checked{background:qlineargradient(x1:0,y1:0,x2:1,y2:1,stop:0 #2B3C9A,stop:1 #432BB3);border:1px solid #7B74FF;color:white;}
#appSwitch{min-width:38px;max-width:38px;min-height:38px;max-height:38px;background:#091B31;border:1px solid #294C73;border-radius:9px;color:#A9BCDA;font-size:16px;font-weight:900;padding:0;}
#appSwitch:hover{background:#123154;border-color:#5987B7;color:#FFFFFF;}
#appSwitch:checked{background:qlineargradient(x1:0,y1:0,x2:1,y2:1,stop:0 #3448A9,stop:1 #5B31C9);border:1px solid #8C82FF;color:#FFFFFF;}
#windowButton,#closeButton{background:transparent;color:#D5DEF0;font-size:18px;min-width:42px;max-width:42px;min-height:38px;max-height:38px;}
#windowButton:hover{background:#132B4A;} #closeButton:hover{background:#C43B51;color:white;}
#navSep{background:#203A5A;min-width:1px;max-width:1px;min-height:24px;max-height:24px;}
#appRailLabel{font-size:8px;color:#6F89B0;font-weight:800;letter-spacing:1px;}
QMessageBox{background:#0A1A2F;}
QMessageBox QLabel{color:#EEF5FF;background:transparent;min-width:0px;}
QMessageBox QPushButton{background:#102842;color:#EAF3FF;border:1px solid #31577E;border-radius:6px;padding:7px 18px;min-width:72px;}
QMessageBox QPushButton:hover{background:#1B3B60;border-color:#6696CA;}
#confirmDialog{background:#07162A;border:1px solid #4967B0;border-radius:10px;}
#confirmHeader{background:#0D2140;border-bottom:1px solid #294D7A;border-top-left-radius:10px;border-top-right-radius:10px;}
#confirmBody{background:#07162A;border-bottom-left-radius:10px;border-bottom-right-radius:10px;}
#confirmIcon{background:#1689D7;color:white;border-radius:14px;font-size:18px;font-weight:900;}
#confirmTitle{color:#F1F6FF;font-size:15px;font-weight:850;}
#confirmMessage{color:#D4E1F3;font-size:13px;line-height:1.5;}
#confirmClose{background:transparent;color:#BFD0E7;border:none;font-size:19px;}
#confirmClose:hover{background:#B73C55;color:white;border-radius:5px;}
#confirmSecondary{background:#0D2139;border:1px solid #31577E;border-radius:6px;color:#DDE9FA;padding:8px 16px;font-weight:700;}
#confirmSecondary:hover{background:#173251;border-color:#5987B7;}
#confirmPrimary{background:qlineargradient(x1:0,y1:0,x2:1,y2:0,stop:0 #586BFF,stop:1 #8156FF);border:1px solid #9486FF;border-radius:6px;color:white;padding:8px 18px;font-weight:850;}
#confirmPrimary:hover{border-color:#C0B7FF;}
"""

class IntegratedTitleBar(QFrame):
    def __init__(self, window):
        super().__init__(); self.window=window; self.drag_pos=None
        self.setObjectName('integratedTitlebar'); self.setFixedHeight(60)
        lay=QHBoxLayout(self); lay.setContentsMargins(18,0,10,0); lay.setSpacing(9)
        self.icon=QLabel(); self.icon.setFixedSize(38,38); self.icon.setAlignment(Qt.AlignCenter); lay.addWidget(self.icon)
        brand=QVBoxLayout(); brand.setSpacing(0)
        row=QHBoxLayout(); row.setSpacing(10)
        self.title=QLabel('Maple Tools'); self.title.setObjectName('brandTitle'); row.addWidget(self.title)
        self.version=QLabel('PERSONAL ALPHA'); self.version.setObjectName('version'); row.addWidget(self.version); row.addStretch()
        brand.addLayout(row)
        self.sub=QLabel('M A P L E   T O O L S'); self.sub.setObjectName('brandSub'); brand.addWidget(self.sub)
        lay.addLayout(brand); lay.addStretch()
        self.nav_group=QButtonGroup(self); self.nav_group.setExclusive(True); self.nav=[]
        for i in range(5):
            b=QPushButton(); b.setObjectName('navButton'); b.setCheckable(True); b.setCursor(Qt.PointingHandCursor); b.setFixedWidth(92)
            b.clicked.connect(lambda checked=False, idx=i: self.window.show_current_page(idx))
            lay.addWidget(b); self.nav.append(b); self.nav_group.addButton(b,i)
        sep=QFrame(); sep.setObjectName('navSep'); lay.addWidget(sep)
        app_label=QLabel('APP'); app_label.setObjectName('appRailLabel'); lay.addWidget(app_label)
        self.app_group=QButtonGroup(self); self.app_group.setExclusive(True); self.app_buttons={}
        app_defs = [
            ('home', BASE_DIR/'home_app_icon.png', 'MapleTools 홈'),
            ('equipment', BASE_DIR/'eq_app_icon.png', '장비 검색기'),
            ('union', BASE_DIR/'app_icon.png', '유니온챔피언 검색기'),
        ]
        for mid,icon_path,tip in app_defs:
            b=QPushButton(); b.setObjectName('appSwitch'); b.setCheckable(True); b.setToolTip(tip)
            b.setIcon(QIcon(str(icon_path))); b.setIconSize(QSize(28,28))
            b.clicked.connect(lambda checked=False, m=mid: self.window.switch_app(m)); self.app_group.addButton(b); lay.addWidget(b); self.app_buttons[mid]=b
        sep2=QFrame(); sep2.setObjectName('navSep'); lay.addWidget(sep2)
        for text,slot,obj in [('—',window.showMinimized,'windowButton'),('□',window.toggle_maximize,'windowButton'),('×',window.close,'closeButton')]:
            b=QPushButton(text); b.setObjectName(obj); b.clicked.connect(slot); lay.addWidget(b)

    def set_module(self, title, version, sub, icon_path, nav_labels, active_idx=0):
        self.title.setText(title); self.version.setText(version); self.sub.setText(sub)
        pm=QPixmap(str(icon_path))
        if not pm.isNull(): self.icon.setPixmap(pm.scaled(34,34,Qt.KeepAspectRatio,Qt.SmoothTransformation))
        for i,b in enumerate(self.nav):
            b.setText(nav_labels[i] if i < len(nav_labels) else '')
            b.setVisible(i < len(nav_labels))
            b.setChecked(i==active_idx)

    def mousePressEvent(self,e):
        if e.button()==Qt.LeftButton: self.drag_pos=e.globalPosition().toPoint()-self.window.frameGeometry().topLeft()
    def mouseMoveEvent(self,e):
        if self.drag_pos is not None and e.buttons() & Qt.LeftButton and not self.window.isMaximized(): self.window.move(e.globalPosition().toPoint()-self.drag_pos)
    def mouseReleaseEvent(self,e): self.drag_pos=None
    def mouseDoubleClickEvent(self,e):
        if e.button()==Qt.LeftButton:self.window.toggle_maximize()



def show_notice(parent, title, message, level='info', button_text='OK'):
    """Compact standard QMessageBox with the normal Windows title bar."""
    box = QMessageBox(parent)
    box.setWindowTitle(title)
    icon_map = {
        'info': QMessageBox.Information,
        'warning': QMessageBox.Warning,
        'error': QMessageBox.Critical,
    }
    box.setIcon(icon_map.get(level, QMessageBox.Information))
    box.setText(message)
    box.setTextFormat(Qt.PlainText)
    box.setStandardButtons(QMessageBox.Ok)
    ok = box.button(QMessageBox.Ok)
    if ok is not None:
        ok.setText(button_text)
        ok.setMinimumWidth(78)

    lines = str(message).splitlines() or ['']
    longest = max((len(line) for line in lines), default=0)
    for label in box.findChildren(QLabel):
        if label.text() == message:
            label.setMinimumWidth(0)
            if longest <= 74:
                label.setWordWrap(False)
                natural = label.fontMetrics().horizontalAdvance(max(lines, key=len)) + 8
                label.setMinimumWidth(min(natural, 560))
                label.setMaximumWidth(560)
            else:
                label.setWordWrap(True)
                label.setMaximumWidth(520)

    box.setStyleSheet(
        'QMessageBox { background:#0A1A2F; }'
        'QMessageBox QLabel { color:#EEF5FF; background:transparent; min-width:0px; }'
        'QMessageBox QPushButton { background:#102842; color:#EAF3FF; border:1px solid #31577E;'
        ' border-radius:6px; padding:6px 16px; min-width:78px; min-height:26px; }'
        'QMessageBox QPushButton:hover { background:#1B3B60; border-color:#6696CA; }'
    )
    box.exec()

