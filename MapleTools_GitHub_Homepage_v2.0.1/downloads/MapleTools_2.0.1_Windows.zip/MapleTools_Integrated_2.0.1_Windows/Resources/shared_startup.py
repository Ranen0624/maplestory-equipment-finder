# -*- coding: utf-8 -*-
from __future__ import annotations
from PySide6.QtCore import QObject, Signal, QSettings


class SharedStartupStore(QObject):
    changed = Signal(str)

    # Keep stable internal IDs so a future MapleTools home screen can be added
    # without changing the saved preference format.
    VALID = {'equipment', 'union', 'home'}

    def __init__(self):
        super().__init__()
        self.settings = QSettings('MapleTools', 'Integrated')

    def get_startup_view(self) -> str:
        value = str(self.settings.value('ui/startup_view_v2', 'home') or 'home').strip()
        return value if value in self.VALID else 'home'

    def set_startup_view(self, value: str):
        value = str(value or '').strip()
        if value not in self.VALID:
            raise ValueError('지원하지 않는 시작 화면입니다.')
        self.settings.setValue('ui/startup_view_v2', value)
        self.settings.sync()
        self.changed.emit(value)


STARTUP_STORE = SharedStartupStore()
