# -*- coding: utf-8 -*-
from __future__ import annotations
import threading, webbrowser
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed
from urllib.parse import quote
from urllib.request import Request, urlopen
from datetime import timedelta, date as pydate
from PySide6.QtCore import Qt, Signal, QThread, QDate, QPoint
from PySide6.QtGui import QPixmap, QColor, QPalette, QTextCharFormat
from PySide6.QtWidgets import (
    QWidget, QFrame, QLabel, QPushButton, QHBoxLayout, QVBoxLayout, QTableWidget,
    QTableWidgetItem, QHeaderView, QAbstractItemView, QCheckBox, QSpinBox,
    QScrollArea, QDialog, QDateEdit, QTabWidget, QSizePolicy
)
import equipment_engine as engine
from equipment_module import EQUIP_QSS, L
from shared_calendar import PopupDatePicker
from shared_api import API_STORE

BASE_DIR = Path(__file__).resolve().parent




def _calendar_yesterday_kst():
    return engine.datetime.now(engine.KST).date() - timedelta(days=1)

def _make_detail_date_picker(value_qdate, minimum_qdate, maximum_qdate):
    return PopupDatePicker(
        value=value_qdate.toString('yyyy-MM-dd'),
        minimum_qdate=minimum_qdate, maximum_qdate=maximum_qdate,
        icon_path=BASE_DIR/'calendar_picker.png'
    )


class DetailDragBar(QFrame):
    def __init__(self, dialog, nickname):
        super().__init__(dialog)
        self.dialog = dialog
        self.setObjectName('detailTopBar')
        h = QHBoxLayout(self)
        h.setContentsMargins(18, 10, 8, 10)
        h.setSpacing(10)
        titles = QVBoxLayout()
        titles.setSpacing(0)
        self.title = L(nickname, 'detailDialogTitle')
        self.status = L('원하는 탭을 선택하면 해당 정보만 조회합니다.', 'detailDialogSub')
        titles.addWidget(self.title)
        titles.addWidget(self.status)
        h.addLayout(titles, 1)
        self.scouter = QPushButton('MapleScouter 열기')
        self.scouter.setObjectName('ghostButton')
        h.addWidget(self.scouter)
        close = QPushButton('×')
        close.setObjectName('detailCloseButton')
        close.setFixedSize(36, 36)
        close.clicked.connect(dialog.reject)
        h.addWidget(close)

    def mousePressEvent(self, e):
        if e.button() == Qt.LeftButton:
            wh = self.dialog.windowHandle()
            if wh is not None:
                try:
                    wh.startSystemMove()
                    e.accept()
                    return
                except Exception:
                    pass
        super().mousePressEvent(e)


class _DetailApiThread(QThread):
    status = Signal(str)
    failed = Signal(str)

    def __init__(self, nickname, app_dir, parent=None):
        super().__init__(parent)
        self.nickname = nickname
        self.app_dir = Path(app_dir)
        self.stop_event = threading.Event()

    def stop(self):
        self.stop_event.set()

    def _client(self):
        return engine.AdaptiveApiClient(
            API_STORE.get_key(),
            self.stop_event,
            log_cb=lambda x: None,
            base_interval=engine.SERVICE_REQUEST_INTERVAL,
            minimum_interval=engine.SERVICE_REQUEST_INTERVAL,
            cache_dir=self.app_dir / 'api_cache',
            cooldown_cb=lambda sec: self.status.emit(
                f'API 제한 대기 {sec}초...' if sec else 'API 재시도 중...'
            ),
            pause_event=None,
        )

    def _identity(self, client):
        self.status.emit('캐릭터 식별자 확인 중...')
        ident = client.get_json('id', {'character_name': self.nickname})
        ocid = engine.clean_text((ident or {}).get('ocid'))
        if not ocid:
            raise RuntimeError('캐릭터 식별자를 찾을 수 없습니다.')
        self.status.emit('현재 캐릭터 정보 확인 중...')
        basic = client.get_json('character/basic', {'ocid': ocid}) or {}
        return ocid, basic


class DetailIdentityThread(_DetailApiThread):
    ready = Signal(object)

    def run(self):
        try:
            client = self._client()
            ocid, basic = self._identity(client)
            self.ready.emit({'ocid': ocid, 'basic': basic})
        except InterruptedError:
            return
        except Exception as e:
            self.failed.emit(str(e))


class DetailTimelineThread(_DetailApiThread):
    ready = Signal(object)
    partial = Signal(object)

    def __init__(self, nickname, app_dir, target_count, parent=None):
        super().__init__(nickname, app_dir, parent)
        self.target_count = max(1, int(target_count))

    def run(self):
        try:
            client = self._client()
            ocid, basic = self._identity(client)
            today = engine.datetime.now(engine.KST).date()
            latest = _calendar_yesterday_kst()
            current_level = int((basic or {}).get('character_level') or 0)
            level_floor = max(1, current_level - self.target_count + 1)
            cache = {today.isoformat(): basic}

            def get_basic(day):
                if self.stop_event.is_set():
                    raise InterruptedError()
                key = day.isoformat()
                if key in cache:
                    return cache[key]
                try:
                    data = client.get_json(
                        'character/basic',
                        {'ocid': ocid, 'date': key},
                        retries=3,
                        allow_missing=True,
                    )
                except Exception:
                    data = None
                cache[key] = data
                return data

            def has_data(data):
                return bool(data and engine.clean_text(data.get('character_name')))

            def level_of(data):
                try:
                    return int((data or {}).get('character_level') or 0)
                except Exception:
                    return 0

            def field(data, key):
                return engine.clean_text((data or {}).get(key))

            self.status.emit(f'최근 {self.target_count}레벨 시작 지점을 찾는 중...')
            start_day = engine.DETAIL_HISTORY_START
            latest_data = get_basic(latest) if latest >= engine.DETAIL_HISTORY_START else None
            if has_data(latest_data) and level_of(latest_data) >= level_floor:
                lo, hi = engine.DETAIL_HISTORY_START, latest
                while lo < hi:
                    mid = lo + timedelta(days=(hi - lo).days // 2)
                    data = get_basic(mid)
                    if has_data(data) and level_of(data) >= level_floor:
                        hi = mid
                    else:
                        lo = mid + timedelta(days=1)
                start_day = lo
            else:
                start_day = max(engine.DETAIL_HISTORY_START, latest - timedelta(days=729))

            events = []
            level_event_count = 0

            def normalized():
                uniq = {}
                for ev in events:
                    uniq[(ev.get('type'), ev.get('date'), ev.get('text'))] = ev
                order = {'nickname': 0, 'guild': 1, 'world': 2, 'gender': 3, 'level': 4}
                out = list(uniq.values())
                out.sort(
                    key=lambda e: (e.get('date', ''), -order.get(e.get('type'), 9)),
                    reverse=True,
                )
                return out

            def emit_partial():
                self.partial.emit({
                    'ocid': ocid,
                    'basic': basic,
                    'events': [dict(x) for x in normalized()],
                    'level_count': level_event_count,
                })

            def first_level_date(lo_day, hi_day, target):
                lo, hi = lo_day, hi_day
                while lo < hi:
                    mid = lo + timedelta(days=(hi - lo).days // 2)
                    if level_of(get_basic(mid)) >= target:
                        hi = mid
                    else:
                        lo = mid + timedelta(days=1)
                return lo if level_of(get_basic(lo)) >= target else None

            def scan_field_changes(lo_day, hi_day, newer_endpoint):
                newer_day = hi_day
                newer = newer_endpoint
                day = hi_day - timedelta(days=1)
                while day >= lo_day:
                    older = get_basic(day)
                    if not has_data(older):
                        day -= timedelta(days=1)
                        continue
                    event_date = newer_day.isoformat()
                    for key, etype, label in (
                        ('character_name', 'nickname', '닉네임'),
                        ('character_guild_name', 'guild', '길드'),
                        ('world_name', 'world', '월드'),
                        ('character_gender', 'gender', '성별'),
                    ):
                        old = field(older, key)
                        new = field(newer, key)
                        if old == new:
                            continue
                        if etype == 'guild':
                            if old and new:
                                msg = f'{old} → {new}'
                            elif new:
                                msg = f'{new} 길드 가입'
                            else:
                                msg = f'{old} 길드 탈퇴'
                        elif etype == 'world':
                            msg = f'{old} → {new} 월드 이동'
                        else:
                            msg = f'{old} → {new}'
                        events.append({
                            'type': etype,
                            'date': event_date,
                            'text': msg,
                            'detail': '',
                        })
                        # A found change is painted immediately instead of waiting
                        # for every historical anchor to finish.
                        emit_partial()
                    newer_day, newer = day, older
                    day -= timedelta(days=1)

            # Work backwards from the newest completed historical day.  The old
            # implementation fetched every weekly anchor before displaying the first
            # result, which could leave this tab blank for a long time.
            self.status.emit('타임라인 탐색 중 · 최근 기록부터 찾는 즉시 표시합니다...')
            newer_day = latest
            newer_data = latest_data
            if not has_data(newer_data):
                probe = latest
                while probe >= start_day and not has_data(newer_data):
                    newer_data = get_basic(probe)
                    if has_data(newer_data):
                        newer_day = probe
                        break
                    probe -= timedelta(days=1)

            if not has_data(newer_data):
                self.ready.emit({'ocid': ocid, 'basic': basic, 'events': [], 'level_count': 0})
                return

            interval_total = max(1, ((newer_day - start_day).days + 6) // 7)
            interval_idx = 0
            while newer_day > start_day:
                if self.stop_event.is_set():
                    raise InterruptedError()
                old_day = max(start_day, newer_day - timedelta(days=7))
                old_data = get_basic(old_day)
                if not has_data(old_data):
                    # If a sampled day is unavailable, walk backwards a few days and
                    # keep the last valid newer endpoint rather than blocking all UI.
                    probe = old_day
                    found = None
                    for _ in range(7):
                        if probe < start_day:
                            break
                        data = get_basic(probe)
                        if has_data(data):
                            found = (probe, data)
                            break
                        probe -= timedelta(days=1)
                    if found is None:
                        newer_day = old_day
                        continue
                    old_day, old_data = found

                old_lv, new_lv = level_of(old_data), level_of(newer_data)
                if new_lv > old_lv:
                    targets = list(range(max(old_lv + 1, level_floor), new_lv + 1))
                    for target in reversed(targets):
                        found = first_level_date(old_day, newer_day, target)
                        if found:
                            events.append({
                                'type': 'level',
                                'date': found.isoformat(),
                                'text': f'Lv.{target} 달성',
                                'detail': '',
                            })
                            level_event_count += 1
                            emit_partial()

                fields = (
                    'character_name', 'character_guild_name',
                    'world_name', 'character_gender',
                )
                if any(field(old_data, k) != field(newer_data, k) for k in fields):
                    scan_field_changes(old_day, newer_day, newer_data)

                interval_idx += 1
                self.status.emit(
                    f'타임라인 탐색 · {min(interval_idx, interval_total)}/{interval_total}구간 · '
                    f'발견 {len(normalized())}건 · 즉시 표시 중'
                )
                newer_day, newer_data = old_day, old_data

            self.ready.emit({
                'ocid': ocid,
                'basic': basic,
                'events': normalized(),
                'level_count': level_event_count,
            })
        except InterruptedError:
            return
        except Exception as e:
            self.failed.emit(str(e))


def _download_detail_image(url):
    if not url:
        return None
    try:
        req = Request(url, headers={'User-Agent': 'MapleTools/0.4.3e'})
        with urlopen(req, timeout=15) as r:
            return r.read()
    except Exception:
        return None


class DetailOutfitThread(_DetailApiThread):
    ready = Signal(object)
    partial = Signal(object)

    def __init__(self, nickname, app_dir, start_date, end_date, target_count, parent=None):
        super().__init__(nickname, app_dir, parent)
        self.start_date = start_date
        self.end_date = end_date
        self.target_count = max(1, int(target_count))

    def run(self):
        try:
            client = self._client()
            ocid, basic = self._identity(client)
            self.status.emit('현재 코디 정보를 불러오는 중...')
            current_cash = client.get_json(
                'character/cashitem-equipment', {'ocid': ocid}
            ) or {}
            current_image = engine.clean_text((basic or {}).get('character_image'))
            rows = [{
                'date': '현재',
                'summary': engine._cash_summary(current_cash),
                'items': engine._cash_item_list(current_cash),
                'image_url': current_image,
                'image_bytes': None,
                'current': True,
            }]
            total = max(1, (self.end_date - self.start_date).days + 1)

            def emit_rows(checked_value):
                self.partial.emit({
                    'rows': [dict(x) for x in rows],
                    'checked': checked_value,
                    'total': total,
                })

            # 텍스트 정보는 즉시 먼저 표시하고, 현재 이미지 다운로드와
            # 과거 기록 탐색은 병렬로 진행합니다.
            emit_rows(0)
            image_pool = ThreadPoolExecutor(max_workers=1)
            current_image_future = (
                image_pool.submit(_download_detail_image, current_image)
                if current_image else None
            )
            last_image = current_image
            checked = 0
            cursor = self.end_date

            while (
                cursor >= self.start_date
                and sum(1 for x in rows if not x.get('current')) < self.target_count
            ):
                if self.stop_event.is_set():
                    raise InterruptedError()
                chunk = []
                for _ in range(10):
                    if cursor < self.start_date:
                        break
                    chunk.append(cursor)
                    cursor -= timedelta(days=1)

                basics = {}

                def fetch(day):
                    if self.stop_event.is_set():
                        raise InterruptedError()
                    try:
                        data = client.get_json(
                            'character/basic',
                            {'ocid': ocid, 'date': day.isoformat()},
                            retries=3,
                            allow_missing=True,
                        )
                    except Exception:
                        data = None
                    return day, data

                with ThreadPoolExecutor(max_workers=min(12, len(chunk) or 1)) as ex:
                    futures = [ex.submit(fetch, d) for d in chunk]
                    for fut in as_completed(futures):
                        day, data = fut.result()
                        basics[day] = data

                for day in sorted(chunk, reverse=True):
                    checked += 1
                    data = basics.get(day)
                    image = engine.clean_text((data or {}).get('character_image'))
                    if not image:
                        continue
                    if image != last_image:
                        date_str = day.isoformat()
                        try:
                            cash = client.get_json(
                                'character/cashitem-equipment',
                                {'ocid': ocid, 'date': date_str},
                                retries=3,
                                allow_missing=True,
                            ) or {}
                        except Exception:
                            cash = {}
                        rows.append({
                            'date': date_str,
                            'summary': engine._cash_summary(cash),
                            'items': engine._cash_item_list(cash),
                            'image_url': image,
                            'image_bytes': None,
                            'current': False,
                        })
                        last_image = image
                        # 변화가 확인되는 즉시 카드부터 추가합니다.
                        emit_rows(checked)
                        rows[-1]['image_bytes'] = _download_detail_image(image)
                        # 이미지까지 준비되면 같은 카드를 즉시 갱신합니다.
                        emit_rows(checked)
                        if sum(1 for x in rows if not x.get('current')) >= self.target_count:
                            break
                if current_image_future is not None and current_image_future.done() and rows[0].get('image_bytes') is None:
                    try:
                        rows[0]['image_bytes'] = current_image_future.result()
                        emit_rows(checked)
                    except Exception:
                        pass
                self.status.emit(
                    f'코디 기록 조회 · {min(checked, total)}/{total}일 · '
                    f'변화 {sum(1 for x in rows if not x.get("current"))}건 · 발견 즉시 표시'
                )

            if current_image_future is not None and rows[0].get('image_bytes') is None:
                try:
                    rows[0]['image_bytes'] = current_image_future.result(timeout=15)
                    emit_rows(checked)
                except Exception:
                    pass
            image_pool.shutdown(wait=False, cancel_futures=False)

            self.ready.emit({
                'ocid': ocid,
                'basic': basic,
                'rows': rows,
                'checked': min(checked, total),
                'total': total,
            })
        except InterruptedError:
            return
        except Exception as e:
            self.failed.emit(str(e))


def _tight_crop_pixmap(pm):
    """Crop transparent padding around Maple character renders."""
    if pm is None or pm.isNull():
        return pm
    img = pm.toImage()
    if not img.hasAlphaChannel():
        return pm
    w, h = img.width(), img.height()
    min_x, min_y, max_x, max_y = w, h, -1, -1
    # Character API images are small enough for a direct alpha scan.
    for y in range(h):
        for x in range(w):
            if img.pixelColor(x, y).alpha() > 8:
                if x < min_x: min_x = x
                if y < min_y: min_y = y
                if x > max_x: max_x = x
                if y > max_y: max_y = y
    if max_x < min_x or max_y < min_y:
        return pm
    pad = 3
    min_x = max(0, min_x - pad)
    min_y = max(0, min_y - pad)
    max_x = min(w - 1, max_x + pad)
    max_y = min(h - 1, max_y + pad)
    return pm.copy(min_x, min_y, max_x - min_x + 1, max_y - min_y + 1)


class OutfitImageCard(QFrame):
    """Large image-only outfit card with a double-click callback."""
    def __init__(self, row, callback, parent=None):
        super().__init__(parent)
        self.outfit_row = row
        self._callback = callback
        self.setObjectName('outfitCard')
        self.setCursor(Qt.PointingHandCursor)
        self.setToolTip('더블클릭하면 이 코디의 아이템 목록을 확인할 수 있습니다.')

    def mouseDoubleClickEvent(self, e):
        if e.button() == Qt.LeftButton and self._callback:
            self._callback(self, self.outfit_row)
            e.accept()
            return
        super().mouseDoubleClickEvent(e)


class OutfitItemsPopup(QFrame):
    """Small side popup listing the cash items for one outfit snapshot."""
    def __init__(self, row, parent=None):
        super().__init__(parent, Qt.Popup | Qt.FramelessWindowHint)
        self.setObjectName('outfitPopup')
        self.setAttribute(Qt.WA_DeleteOnClose, True)
        self.setFixedWidth(390)

        root = QVBoxLayout(self)
        root.setContentsMargins(14, 12, 14, 12)
        root.setSpacing(8)

        top = QHBoxLayout()
        date_text = '현재 코디' if row.get('current') else (row.get('date') or '코디 기록')
        items = row.get('items') or []
        top.addWidget(L(f'{date_text} · {len(items)}개', 'outfitPopupTitle'))
        top.addStretch(1)
        close = QPushButton('×')
        close.setObjectName('outfitPopupClose')
        close.setFixedSize(27, 27)
        close.clicked.connect(self.close)
        top.addWidget(close)
        root.addLayout(top)

        scroll = QScrollArea()
        scroll.setObjectName('outfitPopupScroll')
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        scroll.setFixedHeight(min(330, max(120, 28 * max(1, len(items)))))
        host = QWidget()
        vv = QVBoxLayout(host)
        vv.setContentsMargins(4, 4, 4, 4)
        vv.setSpacing(5)
        if items:
            for item in items:
                part = engine.clean_text(item.get('part')) or '기타'
                name = engine.clean_text(item.get('name')) or '-'
                lab = L(f'{part}  ·  {name}', 'outfitPopupItem')
                lab.setWordWrap(True)
                vv.addWidget(lab)
        else:
            lab = L('표시할 캐시 장비 정보가 없습니다.', 'mutedText')
            lab.setWordWrap(True)
            vv.addWidget(lab)
        vv.addStretch(1)
        scroll.setWidget(host)
        root.addWidget(scroll)

    def keyPressEvent(self, e):
        if e.key() == Qt.Key_Escape:
            self.close()
            e.accept()
            return
        super().keyPressEvent(e)


class EquipmentDetailDialog(QDialog):
    def __init__(self, parent, row):
        super().__init__(parent)
        self.row = row
        self.nickname = engine.clean_text(row.get('닉네임'))
        self.app_dir = getattr(parent, 'app_dir', BASE_DIR.parent)
        self.current_basic = {}
        self.ocid = ''
        self.timeline_events = []
        self.outfit_rows = []
        self.identity_thread = None
        self.history_thread = None
        self.timeline_loaded = False
        self.outfit_loaded = False
        self._outfit_popup = None
        self.setWindowFlags(Qt.Dialog | Qt.FramelessWindowHint)
        self.setModal(True)
        self.resize(1040, 760)
        self.setMinimumSize(900, 650)
        self.setObjectName('detailDialog')
        self.setStyleSheet(EQUIP_QSS + """
            #detailDialog{background:#061225;border:1px solid #244D78;}
            #detailTopBar{background:#08182B;border-bottom:1px solid #1D426B;}
            #detailDialogTitle{font-size:21px;font-weight:900;color:#F3E9FF;}
            #detailDialogSub{font-size:10px;color:#8EA7C8;}
            #detailCloseButton{background:transparent;border:none;color:#E9F1FB;font-size:22px;font-weight:900;}
            #detailCloseButton:hover{background:#B83B5E;border-radius:5px;}
            #detailSummary{background:#091B31;border:1px solid #244D78;border-radius:8px;}
            #detailSummaryMain{font-size:13px;font-weight:800;color:#EAF3FF;}
            #historyCard{background:#08192D;border:1px solid #1B426C;border-radius:8px;}
            #historyDate{background:#26376F;color:#DCE3FF;border-radius:10px;padding:4px 9px;font-weight:900;}
            #historyTitle{font-size:14px;font-weight:900;color:#EAF3FF;}
            #historyDetail{font-size:10px;color:#83A0C5;}
            #outfitImage{background:#06101E;border:1px solid #284D77;border-radius:7px;color:#617A9C;}
            #outfitSummary{font-size:12px;font-weight:800;color:#DDE9F8;}

            #timelineBadge{background:#182C57;border:1px solid #405F9A;border-radius:9px;color:#C9D8F0;padding:3px 8px;font-size:9px;font-weight:800;}
            #timelineBadge[kind="nickname"]{background:#30245F;border-color:#7459C9;color:#E2D8FF;}
            #timelineBadge[kind="guild"]{background:#173B50;border-color:#3C7897;color:#CFEFFF;}
            #timelineBadge[kind="world"]{background:#163D3A;border-color:#3D827A;color:#D6FFF6;}
            #timelineBadge[kind="gender"]{background:#4B2A48;border-color:#985A8E;color:#FFE0FA;}
            #timelineBadge[kind="level"]{background:#3D3518;border-color:#8A7B3B;color:#FFF2B8;}
            #timelineBadge[kind="current"]{background:#26376F;border-color:#526DC6;color:#E9EDFF;}
            #outfitCard{background:#07172A;border:1px solid #1B426C;border-radius:10px;}
            #outfitCard:hover{border-color:#4D70A8;background:#091C33;}
            #outfitImageLarge{background:transparent;border:none;color:#617A9C;}
            #outfitHint{font-size:10px;color:#607FA8;}
            #outfitInlineHint{font-size:9px;color:#8F82FF;font-weight:700;}
            #outfitPopup{background:#08182C;border:1px solid #355B89;border-radius:9px;}
            #outfitPopupTitle{font-size:14px;font-weight:900;color:#EAF3FF;}
            #outfitPopupClose{background:transparent;border:none;color:#C8D8EE;font-size:18px;font-weight:900;}
            #outfitPopupClose:hover{background:#B83B5E;color:white;border-radius:5px;}
            #outfitPopupScroll{background:#061321;border:1px solid #173A5F;border-radius:6px;}
            #outfitPopupItem{font-size:11px;color:#C7D7EA;padding:3px 5px;}
            QTabWidget::pane{border:1px solid #244D78;background:#061225;top:-1px;}
            QTabBar::tab{background:#0A1C32;color:#9FB2CC;border:1px solid #244D78;padding:9px 20px;}
            QTabBar::tab:selected{background:#172C50;color:white;border-bottom:2px solid #7964FF;}
        """)
        root = QVBoxLayout(self)
        root.setContentsMargins(1, 1, 1, 1)
        root.setSpacing(0)
        self.top = DetailDragBar(self, self.nickname or '상세 정보')
        self.top.scouter.clicked.connect(self._open_scouter)
        root.addWidget(self.top)

        body = QWidget()
        bv = QVBoxLayout(body)
        bv.setContentsMargins(18, 12, 18, 16)
        bv.setSpacing(10)
        self.summary = QFrame()
        self.summary.setObjectName('detailSummary')
        sh = QVBoxLayout(self.summary)
        sh.setContentsMargins(15, 10, 15, 10)
        sh.setSpacing(3)
        self.summary_main = L(self._preview_summary(), 'detailSummaryMain')
        sh.addWidget(self.summary_main)
        self.summary_sub = L('현재 캐릭터 정보를 불러오는 중...', 'detailDialogSub')
        sh.addWidget(self.summary_sub)
        bv.addWidget(self.summary)

        self.tabs = QTabWidget()
        bv.addWidget(self.tabs, 1)
        self._build_guide_tab()
        self._build_timeline_tab()
        self._build_outfit_tab()
        self.tabs.currentChanged.connect(self._tab_changed)
        root.addWidget(body, 1)
        self._start_identity()

    def _preview_summary(self):
        return (
            f"월드  {self.row.get('월드', '-') or '-'}     "
            f"레벨  Lv.{self.row.get('레벨', '-') or '-'}     "
            f"직업  {self.row.get('직업', '-') or '-'}     "
            f"길드  {self.row.get('길드', '-') or '-'}"
        )

    def _open_scouter(self):
        if self.nickname:
            webbrowser.open(
                f'https://maplescouter.com/ko/info?name={quote(self.nickname)}'
            )

    def _build_guide_tab(self):
        tab = QWidget()
        lay = QHBoxLayout(tab)
        lay.setContentsMargins(14, 14, 14, 14)
        lay.setSpacing(12)
        left = QFrame()
        left.setObjectName('historyCard')
        lv = QVBoxLayout(left)
        lv.setContentsMargins(14, 12, 14, 12)
        lv.addWidget(L('검색된 장비 정보', 'subSectionTitle'))
        table = QTableWidget(0, 2)
        table.setHorizontalHeaderLabels(['항목', '값'])
        table.verticalHeader().setVisible(False)
        table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeToContents)
        table.horizontalHeader().setSectionResizeMode(1, QHeaderView.Stretch)
        table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        table.setSelectionMode(QAbstractItemView.NoSelection)
        for k, val in self.row.items():
            if val in ('', None):
                continue
            r = table.rowCount()
            table.insertRow(r)
            table.setItem(r, 0, QTableWidgetItem(str(k)))
            table.setItem(r, 1, QTableWidgetItem(str(val)))
        lv.addWidget(table, 1)
        lay.addWidget(left, 3)

        right = QFrame()
        right.setObjectName('historyCard')
        rv = QVBoxLayout(right)
        rv.setContentsMargins(18, 15, 18, 15)
        rv.addWidget(L('상세 조회 안내', 'subSectionTitle'))
        info = L(
            '• 타임라인\n'
            '  최근 날짜부터 과거 방향으로 확인하며 레벨업·닉네임·길드·월드·성별 변화를 찾습니다.\n'
            '  기본 10레벨이며 원하는 개수로 변경할 수 있습니다.\n\n'
            '• 코디 기록\n'
            '  시작일과 종료일 사이의 캐릭터 외형 변화를 확인하고 당시 캐시 장비를 표시합니다.\n'
            '  기본 변화 10건, 최대 조회 기간은 185일입니다.\n\n'
            '• MapleScouter 열기\n'
            '  상단 버튼으로 현재 캐릭터를 MapleScouter에서 바로 조회합니다.',
            'helpText',
        )
        info.setWordWrap(True)
        info.setAlignment(Qt.AlignTop)
        rv.addWidget(info)
        rv.addStretch(1)
        lay.addWidget(right, 2)
        self.tabs.addTab(tab, '안내')

    def _build_timeline_tab(self):
        tab = QWidget()
        v = QVBoxLayout(tab)
        v.setContentsMargins(12, 12, 12, 12)
        v.setSpacing(8)
        ctl = QFrame()
        ctl.setObjectName('historyCard')
        h = QHBoxLayout(ctl)
        h.setContentsMargins(12, 8, 12, 8)
        h.setSpacing(8)
        h.addWidget(L('표시 항목', 'fieldLabel'))
        self.t_filters = {}
        for key, text in [
            ('nickname', '닉네임'), ('guild', '길드'), ('world', '월드'),
            ('gender', '성별'), ('level', '레벨')
        ]:
            cb = QCheckBox(text)
            cb.setChecked(True)
            cb.toggled.connect(self._render_timeline)
            self.t_filters[key] = cb
            h.addWidget(cb)
        h.addStretch(1)
        h.addWidget(L('레벨 이력 수', 'fieldLabel'))
        self.timeline_limit = QSpinBox()
        self.timeline_limit.setRange(1, 50)
        self.timeline_limit.setValue(10)
        self.timeline_limit.setFixedWidth(70)
        h.addWidget(self.timeline_limit)
        q = QPushButton('조회')
        q.setObjectName('ghostButton')
        q.clicked.connect(lambda: self._start_timeline(force=True))
        h.addWidget(q)
        v.addWidget(ctl)
        self.timeline_status = L(
            '타임라인 탭을 선택하면 날짜별 조회를 시작합니다.', 'mutedText'
        )
        v.addWidget(self.timeline_status)
        self.timeline_scroll = QScrollArea()
        self.timeline_scroll.setWidgetResizable(True)
        self.timeline_host = QWidget()
        self.timeline_layout = QVBoxLayout(self.timeline_host)
        self.timeline_layout.setContentsMargins(3, 3, 3, 3)
        self.timeline_layout.setSpacing(7)
        self.timeline_layout.addStretch(1)
        self.timeline_scroll.setWidget(self.timeline_host)
        v.addWidget(self.timeline_scroll, 1)
        self.tabs.addTab(tab, '타임라인')

    def _build_outfit_tab(self):
        tab = QWidget()
        v = QVBoxLayout(tab)
        v.setContentsMargins(12, 12, 12, 12)
        v.setSpacing(8)
        ctl = QFrame()
        ctl.setObjectName('historyCard')
        h = QHBoxLayout(ctl)
        h.setContentsMargins(12, 8, 12, 8)
        h.setSpacing(8)
        latest = _calendar_yesterday_kst()
        end_q = QDate(latest.year, latest.month, latest.day)
        start_q = end_q.addMonths(-6)
        hist = engine.DETAIL_HISTORY_START
        hist_q = QDate(hist.year, hist.month, hist.day)
        if start_q < hist_q:
            start_q = hist_q
        h.addWidget(L('시작 날짜', 'fieldLabel'))
        self.outfit_start = _make_detail_date_picker(start_q, hist_q, end_q)
        self.outfit_start.setFixedWidth(170)
        h.addWidget(self.outfit_start)
        h.addWidget(L('끝 날짜', 'fieldLabel'))
        self.outfit_end = _make_detail_date_picker(end_q, hist_q, end_q)
        self.outfit_end.setFixedWidth(170)
        h.addWidget(self.outfit_end)
        h.addWidget(L('코디 변화 수', 'fieldLabel'))
        self.outfit_limit = QSpinBox()
        self.outfit_limit.setRange(1, 50)
        self.outfit_limit.setValue(10)
        self.outfit_limit.setFixedWidth(70)
        h.addWidget(self.outfit_limit)
        h.addStretch(1)
        q = QPushButton('조회')
        q.setObjectName('ghostButton')
        q.clicked.connect(lambda: self._start_outfit(force=True))
        h.addWidget(q)
        v.addWidget(ctl)
        status_row = QHBoxLayout()
        status_row.setContentsMargins(0, 0, 0, 0)
        status_row.setSpacing(12)
        self.outfit_status = L(
            '코디 기록 탭을 선택하면 지정 기간을 조회합니다.', 'mutedText'
        )
        self.outfit_status.setWordWrap(False)
        self.outfit_status.setSizePolicy(QSizePolicy.Preferred, QSizePolicy.Fixed)
        status_row.addWidget(self.outfit_status)
        status_row.addStretch(1)
        self.outfit_inline_hint = L(
            '※ 코디를 더블클릭하면 상세 코디 아이템을 확인할 수 있습니다.',
            'outfitInlineHint',
        )
        self.outfit_inline_hint.setWordWrap(False)
        self.outfit_inline_hint.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
        self.outfit_inline_hint.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
        status_row.addWidget(self.outfit_inline_hint)
        v.addLayout(status_row)
        self.outfit_scroll = QScrollArea()
        self.outfit_scroll.setWidgetResizable(True)
        self.outfit_host = QWidget()
        self.outfit_layout = QVBoxLayout(self.outfit_host)
        self.outfit_layout.setContentsMargins(3, 3, 3, 3)
        self.outfit_layout.setSpacing(8)
        self.outfit_layout.addStretch(1)
        self.outfit_scroll.setWidget(self.outfit_host)
        v.addWidget(self.outfit_scroll, 1)
        self.tabs.addTab(tab, '코디 기록')

    def _start_identity(self):
        self.identity_thread = DetailIdentityThread(
            self.nickname, self.app_dir, self
        )
        self.identity_thread.status.connect(self._set_header_status)
        self.identity_thread.ready.connect(self._identity_ready)
        self.identity_thread.failed.connect(
            lambda e: self._set_header_status(f'현재 정보 조회 실패: {e}')
        )
        self.identity_thread.start()

    def _identity_ready(self, data):
        self.ocid = data.get('ocid', '')
        self.current_basic = data.get('basic') or {}
        b = self.current_basic
        name = engine.clean_text(b.get('character_name')) or self.nickname
        world = engine.clean_text(b.get('world_name')) or self.row.get('월드', '-')
        level = b.get('character_level') or self.row.get('레벨', '-')
        job = engine.clean_text(b.get('character_class')) or self.row.get('직업', '-')
        guild = engine.clean_text(b.get('character_guild_name')) or '-'
        gender = engine.clean_text(b.get('character_gender')) or '-'
        self.top.title.setText(name)
        self.summary_main.setText(
            f'월드  {world}     레벨  Lv.{level}     직업  {job}     길드  {guild}'
        )
        self.summary_sub.setText(f'성별  {gender}     ·     현재 정보 표시 완료')
        self._set_header_status('현재 정보 완료 · 원하는 탭을 선택하세요.')

    def _set_header_status(self, text):
        self.top.status.setText(str(text))

    def _tab_changed(self, idx):
        self._cancel_history()
        if idx == 1 and not self.timeline_loaded:
            self._start_timeline()
        elif idx == 2 and not self.outfit_loaded:
            self._start_outfit()
        elif idx == 0:
            self._set_header_status('원하는 탭을 선택하면 해당 정보만 조회합니다.')

    def _cancel_history(self):
        if self.history_thread and self.history_thread.isRunning():
            self.history_thread.stop()
        self.history_thread = None

    def _start_timeline(self, force=False):
        self._cancel_history()
        self.timeline_loaded = False
        self.timeline_status.setText(
            '고속 타임라인 조회 중 · 레벨/닉네임/길드/월드/성별 변화를 확인합니다...'
        )
        th = DetailTimelineThread(
            self.nickname, self.app_dir, self.timeline_limit.value(), self
        )
        self.history_thread = th
        self.timeline_events = []
        self._render_timeline()
        self._set_header_status('타임라인 조회 시작...')
        th.status.connect(self._timeline_status_changed)
        th.partial.connect(self._timeline_partial)
        th.ready.connect(self._timeline_ready)
        th.failed.connect(self._timeline_failed)
        th.start()

    def _timeline_status_changed(self, text):
        self.timeline_status.setText(text)
        self._set_header_status(text)

    def _timeline_partial(self, data):
        self.current_basic = data.get('basic') or self.current_basic
        self.timeline_events = data.get('events') or []
        self._render_timeline()
        self.timeline_status.setText(
            f"타임라인 조회 중 · 발견 {len(self.timeline_events)}건 · "
            f"레벨 이력 {data.get('level_count', 0)}건"
        )

    def _timeline_failed(self, error):
        text = f'조회 실패: {error}'
        self.timeline_status.setText(text)
        self._set_header_status(text)

    def _timeline_ready(self, data):
        self.current_basic = data.get('basic') or self.current_basic
        self.timeline_events = data.get('events') or []
        self.timeline_loaded = True
        self.timeline_status.setText(
            f"타임라인 조회 완료 · 이벤트 {len(self.timeline_events)}건 · "
            f"레벨 이력 {data.get('level_count', 0)}건"
        )
        self._set_header_status('타임라인 조회 완료')
        self._render_timeline()

    def _clear_layout(self, lay):
        while lay.count() > 1:
            item = lay.takeAt(0)
            w = item.widget()
            child = item.layout()
            if w is not None:
                w.deleteLater()
            elif child is not None:
                self._clear_layout(child)

    def _render_timeline(self, *_):
        self._clear_layout(self.timeline_layout)
        events = [
            e for e in self.timeline_events
            if self.t_filters.get(e.get('type')) is None
            or self.t_filters[e.get('type')].isChecked()
        ]
        if not events:
            hint_text = (
                '타임라인을 조회하면 변화 이력이 여기에 표시됩니다.'
                if not self.timeline_loaded
                else '선택한 범위에서 표시할 변화 이력이 없습니다.'
            )
            hint = L(hint_text, 'mutedText')
            hint.setAlignment(Qt.AlignCenter)
            self.timeline_layout.insertWidget(0, hint)
            return
        badge_labels = {
            'nickname': '닉네임',
            'guild': '길드',
            'world': '월드',
            'gender': '성별',
            'level': '레벨',
        }
        for ev in events:
            card = QFrame()
            card.setObjectName('historyCard')
            h = QHBoxLayout(card)
            h.setContentsMargins(12, 9, 12, 9)
            h.setSpacing(12)

            date_col = QVBoxLayout()
            date_col.setSpacing(6)
            d = L(ev.get('date', '-'), 'historyDate')
            d.setFixedWidth(105)
            d.setAlignment(Qt.AlignCenter)
            date_col.addWidget(d)
            badge = L(badge_labels.get(ev.get('type'), '변경'), 'timelineBadge')
            badge.setProperty('kind', ev.get('type') or 'other')
            badge.setFixedWidth(76)
            badge.setAlignment(Qt.AlignCenter)
            date_col.addWidget(badge, 0, Qt.AlignHCenter)
            date_col.addStretch(1)
            h.addLayout(date_col)

            vv = QVBoxLayout()
            vv.setSpacing(2)
            vv.addWidget(L(ev.get('text', ''), 'historyTitle'))
            detail_text = engine.clean_text(ev.get('detail'))
            if detail_text:
                vv.addWidget(L(detail_text, 'historyDetail'))
            h.addLayout(vv, 1)
            self.timeline_layout.insertWidget(
                self.timeline_layout.count() - 1, card
            )

    def _outfit_dates(self):
        s = self.outfit_start.date()
        e = self.outfit_end.date()
        start = pydate(s.year(), s.month(), s.day())
        end = pydate(e.year(), e.month(), e.day())
        latest = _calendar_yesterday_kst()
        start = max(engine.DETAIL_HISTORY_START, min(start, latest))
        end = max(engine.DETAIL_HISTORY_START, min(end, latest))
        if start > end:
            start, end = end, start
        if (end - start).days + 1 > 185:
            start = end - timedelta(days=184)
            self.outfit_start.setDate(QDate(start.year, start.month, start.day))
        return start, end

    def _start_outfit(self, force=False):
        self._cancel_history()
        self.outfit_loaded = False
        try:
            start, end = self._outfit_dates()
        except Exception as e:
            text = f'조회 준비 실패: {e}'
            self.outfit_status.setText(text)
            self._set_header_status(text)
            return
        self.outfit_rows = []
        self._render_outfits()
        self.outfit_status.setText(
            f'{start.isoformat()} ~ {end.isoformat()} · '
            f'코디 변화 최대 {self.outfit_limit.value()}건 조회를 시작합니다...'
        )
        self._set_header_status('코디 기록 조회 시작...')
        th = DetailOutfitThread(
            self.nickname,
            self.app_dir,
            start,
            end,
            self.outfit_limit.value(),
            self,
        )
        self.history_thread = th
        th.status.connect(self._outfit_status_changed)
        th.partial.connect(self._outfit_partial)
        th.ready.connect(self._outfit_ready)
        th.failed.connect(self._outfit_failed)
        th.start()

    def _outfit_failed(self, error):
        text = f'조회 실패: {error}'
        self.outfit_status.setText(text)
        self._set_header_status(text)

    def _outfit_status_changed(self, text):
        self.outfit_status.setText(text)
        self._set_header_status(text)

    def _outfit_partial(self, data):
        self.outfit_rows = data.get('rows') or []
        self._render_outfits()
        self.outfit_status.setText(
            f"코디 기록 조회 중 · {data.get('checked', 0)}/{data.get('total', 0)}일 · "
            f"발견 {max(0, len(self.outfit_rows) - 1)}건 · 화면 즉시 갱신"
        )

    def _outfit_ready(self, data):
        self.current_basic = data.get('basic') or self.current_basic
        self.outfit_rows = data.get('rows') or []
        self.outfit_loaded = True
        self._render_outfits()
        self.outfit_status.setText(
            f"코디 기록 조회 완료 · {data.get('checked', 0)}/{data.get('total', 0)}일 확인 · "
            f"{len(self.outfit_rows)}건 표시"
        )
        self._set_header_status('코디 기록 조회 완료')

    def _render_outfits(self):
        self._clear_layout(self.outfit_layout)
        if not self.outfit_rows:
            hint = L(
                '코디 기록을 조회하면 현재 및 과거 외형 변화가 여기에 표시됩니다.',
                'mutedText',
            )
            hint.setAlignment(Qt.AlignCenter)
            self.outfit_layout.insertWidget(0, hint)
            return

        # Compact 3-column gallery.  The previous 600×600 image card showed only
        # one outfit at a time; ~200px character renders let several snapshots be
        # compared without losing the full character silhouette.
        per_row = 3
        row_box = None
        row_layout = None
        for idx, row in enumerate(self.outfit_rows):
            if idx % per_row == 0:
                row_box = QWidget(self.outfit_host)
                row_layout = QHBoxLayout(row_box)
                row_layout.setContentsMargins(0, 0, 0, 0)
                row_layout.setSpacing(9)
                self.outfit_layout.insertWidget(
                    self.outfit_layout.count() - 1, row_box
                )

            card = OutfitImageCard(row, self._show_outfit_items, row_box)
            card.setMinimumWidth(210)
            card.setMaximumWidth(300)
            v = QVBoxLayout(card)
            v.setContentsMargins(9, 9, 9, 10)
            v.setSpacing(6)

            date_badge = L(row.get('date', '-') or '-', 'historyDate')
            date_badge.setAlignment(Qt.AlignCenter)
            date_badge.setAttribute(Qt.WA_TransparentForMouseEvents, True)
            v.addWidget(date_badge, 0, Qt.AlignHCenter)

            image = QLabel('이미지 없음')
            image.setObjectName('outfitImageLarge')
            image.setFixedSize(200, 200)
            image.setAlignment(Qt.AlignCenter)
            image.setAttribute(Qt.WA_TransparentForMouseEvents, True)
            raw = row.get('image_bytes')
            if raw:
                pm = QPixmap()
                if pm.loadFromData(raw):
                    pm = _tight_crop_pixmap(pm)
                    image.setPixmap(
                        pm.scaled(
                            190, 190, Qt.KeepAspectRatio, Qt.SmoothTransformation
                        )
                    )
                    image.setText('')
            v.addWidget(image, 0, Qt.AlignHCenter)
            row_layout.addWidget(card, 1)

            if idx % per_row == per_row - 1:
                row_box = None
                row_layout = None

        if row_layout is not None:
            # Keep incomplete final rows aligned to the same three logical
            # columns as every full row.  Existing cards stay in columns 1/2
            # from the left; only the missing right-side slots remain empty.
            remainder = len(self.outfit_rows) % per_row
            missing = (per_row - remainder) % per_row
            for _ in range(missing):
                row_layout.addStretch(1)

    def _show_outfit_items(self, card, row):
        old = getattr(self, '_outfit_popup', None)
        if old is not None:
            try:
                old.close()
            except Exception:
                pass
        popup = OutfitItemsPopup(row, self)
        self._outfit_popup = popup
        popup.destroyed.connect(
            lambda *_args, p=popup: setattr(self, '_outfit_popup', None)
            if self._outfit_popup is p else None
        )
        popup.adjustSize()

        # Prefer the right side of the selected card; fall back to its left side
        # when the popup would leave the current screen.
        yoff = max(0, (card.height() - popup.height()) // 2)
        right_pos = card.mapToGlobal(QPoint(card.width() + 8, yoff))
        screen = card.screen()
        geo = screen.availableGeometry() if screen is not None else None
        if geo is not None and right_pos.x() + popup.width() > geo.right():
            pos = card.mapToGlobal(QPoint(-popup.width() - 8, yoff))
        else:
            pos = right_pos
        if geo is not None:
            x = max(geo.left() + 4, min(pos.x(), geo.right() - popup.width() - 4))
            y = max(geo.top() + 4, min(pos.y(), geo.bottom() - popup.height() - 4))
            pos = QPoint(x, y)
        popup.move(pos)
        popup.show()
        popup.raise_()

    def reject(self):
        if self._outfit_popup is not None:
            try:
                self._outfit_popup.close()
            except Exception:
                pass
            self._outfit_popup = None
        self._cancel_history()
        if self.identity_thread and self.identity_thread.isRunning():
            self.identity_thread.stop()
        super().reject()

    def closeEvent(self, e):
        if self._outfit_popup is not None:
            try:
                self._outfit_popup.close()
            except Exception:
                pass
            self._outfit_popup = None
        self._cancel_history()
        if self.identity_thread and self.identity_thread.isRunning():
            self.identity_thread.stop()
        super().closeEvent(e)
