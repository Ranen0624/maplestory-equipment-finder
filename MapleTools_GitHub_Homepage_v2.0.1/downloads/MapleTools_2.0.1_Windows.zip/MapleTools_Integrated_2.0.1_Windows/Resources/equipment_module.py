# -*- coding: utf-8 -*-
from __future__ import annotations
import csv, threading, time
from pathlib import Path
from datetime import datetime, timedelta
from PySide6.QtCore import Qt, Signal, QThread, QDate, QTimer, QSize, QStringListModel
from PySide6.QtGui import QPixmap, QIcon, QPalette, QColor, QTextCharFormat
from PySide6.QtWidgets import (
    QWidget, QFrame, QLabel, QPushButton, QHBoxLayout, QVBoxLayout, QGridLayout,
    QStackedWidget, QLineEdit, QComboBox, QSpinBox, QCheckBox, QTableWidget,
    QTableWidgetItem, QHeaderView, QAbstractItemView, QFileDialog, QMessageBox,
    QPlainTextEdit, QScrollArea, QCompleter, QDialog, QSplitter, QSizePolicy,
    QDateEdit, QProgressBar, QCalendarWidget, QToolButton, QMenu, QWidgetAction
)
import equipment_engine as engine
from shared_api import API_STORE
from shared_calendar import PopupDatePicker
from shared_startup import STARTUP_STORE
from common_shell import show_notice

BASE_DIR = Path(__file__).resolve().parent
APP_VERSION = '2.0.1'

EQUIP_QSS = r"""
QWidget{font-family:"Malgun Gothic";font-size:12px;color:#EEF5FF;}
#eqRoot,#eqMainArea,#eqPage,#eqScrollHost,#resultsHost,#logsHost{background:#061225;}
#eqSidebar{background:#07101F;border-right:1px solid #1B3B61;}
#eqFooter{background:#08162A;border-top:1px solid #18395E;min-height:40px;}
#statusDot{color:#6DF2A8;font-size:15px;} #statusLabel{color:#C1D2E9;} #footerMeta{color:#70AEE9;}
#pageHeader{background:transparent;} #pageTitle{font-size:24px;font-weight:900;color:#F1E9FF;} #pageSub{color:#96ACC8;}
#sectionPanel,#metricBox,#detailCard,#sideStatus,#settingsCard{background:qlineargradient(x1:0,y1:0,x2:1,y2:1,stop:0 #091A30,stop:1 #07172B);border:1px solid #17436D;border-radius:10px;}
#sectionHeader{background:#0B2039;border:0;border-bottom:1px solid #183D63;border-top-left-radius:9px;border-top-right-radius:9px;}
#sectionBadge{background:qlineargradient(x1:0,y1:0,x2:1,y2:1,stop:0 #63BAFF,stop:1 #8C79FF);color:#061225;border-radius:6px;font-size:15px;font-weight:900;}
#subSectionTitle{font-size:16px;font-weight:900;color:#63D6FF;} #mutedText{color:#8EA7C8;} #fieldLabel{font-weight:700;color:#DDE9F8;}
#microText{color:#7593B9;font-size:10px;} #countBadge{background:#2A347E;color:#D7DAFF;border-radius:12px;padding:4px 11px;font-weight:900;}
#metricCaption{color:#91A8C6;font-size:10px;font-weight:700;} #metricValue{color:#F5F8FF;font-size:21px;font-weight:900;} #metricSub{color:#6F8DB4;font-size:9px;}
QComboBox,QSpinBox,QLineEdit,QDateEdit{background:#08182B;border:1px solid #31577E;border-radius:5px;padding:6px 8px;color:white;min-height:23px;}
QComboBox:enabled:hover,QSpinBox:enabled:hover,QLineEdit:enabled:hover,QDateEdit:enabled:hover{border-color:#6696CA;}
QComboBox:disabled,QSpinBox:disabled,QLineEdit:disabled,QDateEdit:disabled{background:#071426;border-color:#203D5C;color:#5F7898;}
QComboBox::drop-down,QSpinBox::up-button,QSpinBox::down-button,QDateEdit::drop-down{border:none;width:24px;}
QComboBox QAbstractItemView{background:#0C1C31;color:white;selection-background-color:#263F72;border:1px solid #31577E;}
#datePicker{background:#08182B;border:1px solid #31577E;border-radius:5px;}
#dateText{border:none;border-radius:5px 0 0 5px;background:transparent;padding:6px 8px;min-height:23px;}
#dateButton{background:#0E2743;border:none;border-left:1px solid #31577E;border-radius:0 5px 5px 0;padding:4px;}
#dateButton:hover{background:#173A60;}
#calendarMenu{background:#0B1B31;border:1px solid #31577E;padding:4px;}
QCalendarWidget QWidget{background:#0B1B31;color:#EAF3FF;}
QCalendarWidget QToolButton{background:#102742;color:#EAF3FF;border:none;border-radius:4px;padding:5px;}
QCalendarWidget QToolButton:hover{background:#173A60;}
QCalendarWidget QAbstractItemView{background:#08182B;color:#EAF3FF;selection-background-color:#3D4DCC;selection-color:white;}
QCalendarWidget QSpinBox{background:#102742;color:white;border:1px solid #31577E;}
#searchButton{min-height:44px;border-radius:7px;background:qlineargradient(x1:0,y1:0,x2:1,y2:0,stop:0 #8068FF,stop:.5 #4051FF,stop:1 #9551F6);color:white;font-size:18px;font-weight:900;}
#searchButton:hover{border:1px solid #B8A8FF;} #ghostButton{background:#0D2139;border:1px solid #31577E;border-radius:6px;color:#DDE9FA;padding:8px 13px;font-weight:700;} #ghostButton:hover{background:#173251;border-color:#5987B7;}
#miniButton{background:#0B1B30;border:1px solid #294E77;border-radius:5px;color:#9DB5D3;min-width:29px;max-width:29px;min-height:29px;max-height:29px;padding:0;font-weight:900;} #miniButton:enabled:hover{background:#173251;color:white;} #miniButton:disabled{background:#071426;border-color:#203D5C;color:#4E6785;}
#actionBar{background:#081A2F;border:1px solid #19466F;border-radius:9px;}
QTableWidget{background:#07172A;border:1px solid #173A5F;border-radius:7px;color:#DFEBFA;selection-background-color:#173B69;gridline-color:#143252;}
QHeaderView::section{background:#0D2744;color:#C9D9ED;border:none;border-right:1px solid #193B60;border-bottom:1px solid #193B60;padding:8px 5px;font-weight:700;}
QTableWidget::item{padding:5px;} QTableWidget::item:selected{background:#173B69;}
QScrollBar:vertical{background:#071223;width:10px;margin:0;} QScrollBar::handle:vertical{background:#2E5279;border-radius:5px;min-height:30px;} QScrollBar::add-line,QScrollBar::sub-line{height:0;}
#logBox,#detailText{background:#061321;border:1px solid #173A5F;border-radius:7px;color:#BBD0E8;padding:8px;font-family:Consolas,"Malgun Gothic";}
#helpText{font-size:14px;color:#CFDCF0;} #settingLabel{color:#A9BDD4;font-weight:700;}
#liveState{font-size:18px;font-weight:900;color:#E9F2FF;} #liveSub{color:#8EA7C8;} #warningText{color:#F9B35C;}
QCheckBox{color:#DDE9F8;spacing:7px;} QCheckBox::indicator{width:16px;height:16px;}
QProgressBar{background:#07182A;border:1px solid #244B76;border-radius:5px;min-height:9px;max-height:9px;text-align:center;} QProgressBar::chunk{background:qlineargradient(x1:0,y1:0,x2:1,y2:0,stop:0 #5D78FF,stop:1 #9659FF);border-radius:4px;}
QSplitter::handle{background:#15385E;width:2px;}
"""


class EquipmentSearchThread(QThread):
    log = Signal(str)
    status = Signal(str)
    progress = Signal(str, int, int)
    result_found = Signal(object)
    completed = Signal(object)
    failed = Signal(str)

    def __init__(self, cfg, app_dir, resume=False, catalog_cb=None, parent=None):
        super().__init__(parent)
        self.cfg = cfg
        self.app_dir = Path(app_dir)
        self.resume = resume
        self.catalog_cb = catalog_cb
        self.stop_event = threading.Event()

    def stop(self):
        self.stop_event.set()

    def run(self):
        try:
            cfg = self.cfg
            cp = engine.Checkpoint(self.app_dir, cfg)
            if self.resume and cp.exists():
                cp.load()
            client = engine.AdaptiveApiClient(
                cfg['api_key'], self.stop_event,
                log_cb=lambda x: self.log.emit(str(x)),
                base_interval=cfg['base_interval'],
                cache_dir=self.app_dir/'api_cache',
                minimum_interval=engine.SERVICE_REQUEST_INTERVAL,
            )
            if not cp.data.get('candidates'):
                self.status.emit('랭킹 후보 수집 중...')
                cand = engine.collect_candidates(
                    client, cfg,
                    lambda x: self.log.emit(str(x)),
                    lambda a,b,c: self.progress.emit(a,b,c)
                )
                cp.data['candidates'] = cand
                cp.data['phase'] = 'scanning'
                cp.save()
                self.log.emit(f'후보 수집 완료 · {len(cand):,}명')
            for r in cp.data.get('results') or []:
                if self.resume:
                    self.result_found.emit(r)
            self.status.emit('장비 조건 검사 중...')
            engine.scan_candidates(
                client, cfg, cp,
                lambda x: self.log.emit(str(x)),
                lambda a,b,c: self.progress.emit(a,b,c),
                lambda r: self.result_found.emit(r),
                self.catalog_cb,
            )
            cp.data['phase'] = 'done'
            cp.save()
            self.completed.emit({
                'results': len(cp.data.get('results') or []),
                'candidates': len(cp.data.get('candidates') or []),
                '429': client.total_429,
                'cache_hits': getattr(client, 'cache_hits', 0),
            })
        except InterruptedError:
            self.completed.emit({'stopped': True})
        except Exception as e:
            self.failed.emit(str(e))


class SidebarArt(QLabel):
    def __init__(self):
        super().__init__()
        self.src = QPixmap(str(BASE_DIR/'eq_sidebar_art.png'))
        self.setObjectName('eqSidebar')
        self.setFixedWidth(312)
        self.setAlignment(Qt.AlignCenter)
        self.setStyleSheet('background:#07162A;')
        self.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Expanding)
        self._sync_banner_size()

    def _sync_banner_size(self):
        if self.src.isNull() or self.height() <= 0:
            return
        fitted = self.src.scaledToHeight(max(1, self.height()), Qt.SmoothTransformation)
        target_w = max(312, int(round(self.height() * 683 / 1536)))
        if self.width() != target_w:
            self.setFixedWidth(target_w)
        self.setPixmap(fitted)

    def showEvent(self, e):
        super().showEvent(e)
        QTimer.singleShot(0, self._sync_banner_size)

    def resizeEvent(self, e):
        super().resizeEvent(e)
        self._sync_banner_size()


def L(text, obj=''):
    x = QLabel(text)
    if obj:
        x.setObjectName(obj)
    return x


def _dim_unavailable_calendar_dates(calendar, minimum_qdate, maximum_qdate):
    """Visually dim calendar dates that cannot be selected."""
    disabled = QColor('#46566B')

    def refresh(year=None, month=None):
        year = int(year or calendar.yearShown())
        month = int(month or calendar.monthShown())
        first = QDate(year, month, 1)
        if not first.isValid():
            return
        # QCalendarWidget may show days from the previous/next month.
        # Formatting a generous 6-week neighborhood covers every visible cell.
        start = first.addDays(-14)
        end = first.addMonths(1).addDays(14)
        d = start
        while d <= end:
            fmt = QTextCharFormat()
            # Out-of-range dates and dates belonging to the adjacent month are
            # deliberately low-contrast. Adjacent-month dates remain clickable
            # when they are inside the valid range.
            if (d < minimum_qdate or d > maximum_qdate
                    or d.year() != year or d.month() != month):
                fmt.setForeground(disabled)
            calendar.setDateTextFormat(d, fmt)
            d = d.addDays(1)

    calendar.currentPageChanged.connect(refresh)
    refresh(calendar.yearShown(), calendar.monthShown())


class DatePicker(PopupDatePicker):
    """Equipment search date picker backed by the shared custom calendar."""
    def __init__(self, value='', parent=None):
        start = engine.OPENAPI_HISTORY_START
        yesterday = engine.today_kst() - timedelta(days=1)
        minimum = QDate(start.year, start.month, start.day)
        maximum = QDate(yesterday.year, yesterday.month, yesterday.day)
        super().__init__(
            value=value, minimum_qdate=minimum, maximum_qdate=maximum,
            icon_path=BASE_DIR/'calendar_picker.png', parent=parent
        )


def themed_confirm(parent, title, message, accept_text='불러오기', reject_text='새로 검색'):
    """Integrated dark confirmation dialog.

    Avoids the Windows-native white QMessageBox body inheriting the app's white
    text color, which made checkpoint prompts appear blank.
    Returns True when the left/primary button is chosen.
    """
    dlg = QDialog(parent)
    dlg.setObjectName('confirmDialog')
    dlg.setWindowFlags(Qt.Dialog | Qt.FramelessWindowHint)
    dlg.setModal(True)
    dlg.setMinimumWidth(430)
    root = QVBoxLayout(dlg)
    root.setContentsMargins(0, 0, 0, 0)
    root.setSpacing(0)

    head = QFrame()
    head.setObjectName('confirmHeader')
    hh = QHBoxLayout(head)
    hh.setContentsMargins(16, 11, 10, 11)
    icon = QLabel('?')
    icon.setObjectName('confirmIcon')
    icon.setAlignment(Qt.AlignCenter)
    icon.setFixedSize(28, 28)
    hh.addWidget(icon)
    ttl = QLabel(title)
    ttl.setObjectName('confirmTitle')
    hh.addWidget(ttl)
    hh.addStretch(1)
    close = QPushButton('×')
    close.setObjectName('confirmClose')
    close.setFixedSize(30, 30)
    close.clicked.connect(dlg.reject)
    hh.addWidget(close)
    root.addWidget(head)

    body = QWidget()
    body.setObjectName('confirmBody')
    bv = QVBoxLayout(body)
    bv.setContentsMargins(22, 18, 22, 20)
    bv.setSpacing(16)
    msg = QLabel(message)
    msg.setObjectName('confirmMessage')
    msg.setWordWrap(True)
    msg.setTextInteractionFlags(Qt.TextSelectableByMouse)
    bv.addWidget(msg)

    buttons = QHBoxLayout()
    buttons.addStretch(1)
    no = QPushButton(reject_text)
    no.setObjectName('confirmSecondary')
    yes = QPushButton(accept_text)
    yes.setObjectName('confirmPrimary')
    yes.setDefault(True)
    no.clicked.connect(dlg.reject)
    yes.clicked.connect(dlg.accept)
    buttons.addWidget(no)
    buttons.addWidget(yes)
    bv.addLayout(buttons)
    root.addWidget(body)

    return dlg.exec() == QDialog.Accepted


class StarforceSpinBox(QSpinBox):
    """Spin box whose special text can be replaced by typing immediately.

    The old implementation checked ``value()==minimum`` on every key press.
    With keyboardTracking(False), the internal value stays 0 until editing is
    committed, so every digit kept re-selecting/replacing the previous digit.
    Selection is now performed only when the field receives focus/click; after
    the first digit replaces the special text, subsequent digits append normally.
    """
    def focusInEvent(self, event):
        super().focusInEvent(event)
        QTimer.singleShot(0, self.selectAll)

    def mousePressEvent(self, event):
        super().mousePressEvent(event)
        QTimer.singleShot(0, self.selectAll)

    def keyPressEvent(self, event):
        key = event.key()
        le = self.lineEdit()

        # Backspace/Delete should be able to clear the special text immediately.
        # Do not use self.value() here because keyboardTracking(False) means that
        # value can remain 0 while the user is actively typing e.g. "22".
        if key in (Qt.Key_Backspace, Qt.Key_Delete):
            current = le.text().strip()
            if current == self.specialValueText():
                le.clear()
                event.accept()
                return

        # For numeric keys, QLineEdit already replaces the selected special text
        # on the first key. We intentionally do NOT re-select on later digits.
        super().keyPressEvent(event)


class MetricBox(QFrame):
    def __init__(self, caption, value='0', sub=''):
        super().__init__()
        self.setObjectName('metricBox')
        v = QVBoxLayout(self)
        v.setContentsMargins(14, 9, 14, 9)
        v.setSpacing(0)
        v.addWidget(L(caption, 'metricCaption'))
        self.value = L(value, 'metricValue')
        v.addWidget(self.value)
        self.sub = L(sub, 'metricSub')
        v.addWidget(self.sub)


class OptionRow(QWidget):
    def __init__(self, mode, idx):
        super().__init__()
        self.mode = mode
        self.idx = idx
        h = QHBoxLayout(self)
        h.setContentsMargins(0,0,0,0)
        h.setSpacing(6)
        n = L(f'옵션 {idx+1}', 'fieldLabel')
        n.setFixedWidth(45)
        h.addWidget(n)
        self.kind = QComboBox()
        self.kind.setEditable(True)
        self.kind.setInsertPolicy(QComboBox.NoInsert)
        names = []
        for d in engine.OPTION_TYPE_DEFS[mode]:
            name = d.get('display') or d.get('label')
            if name and name not in names:
                names.append(name)
        self.kind.addItems(names)
        self.kind.setCurrentIndex(-1)
        self._all_names = names
        self._comp_model = QStringListModel(names, self.kind)
        comp = QCompleter(self._comp_model, self.kind)
        comp.setCaseSensitivity(Qt.CaseInsensitive)
        comp.setFilterMode(Qt.MatchContains)
        comp.setCompletionMode(QCompleter.PopupCompletion)
        self.kind.setCompleter(comp)
        self._completer = comp
        self.kind.lineEdit().textEdited.connect(self._update_suggestions)
        self._completer.activated[str].connect(self._accept_completion)
        self.unit = QComboBox()
        self.unit.setFixedWidth(76)
        self.value = QLineEdit()
        self.value.setPlaceholderText('입력')
        self.value.setFixedWidth(100)
        self.clear_btn = QPushButton('×')
        self.clear_btn.setObjectName('miniButton')
        self.clear_btn.setToolTip('이 옵션 비우기')
        self.clear_btn.clicked.connect(self.clear)
        h.addWidget(self.kind,1)
        h.addWidget(self.unit)
        h.addWidget(self.value)
        h.addWidget(self.clear_btn)
        self.kind.currentTextChanged.connect(self.sync)
        self.unit.currentTextChanged.connect(self.sync_value)
        self.sync()

    def _update_suggestions(self, text):
        q = (text or '').strip()
        suggestions = engine._family_suggestions(q, self.mode, limit=30) if q else list(self._all_names)
        self._comp_model.setStringList(suggestions)
        if q and suggestions and self.kind.isEnabled():
            # The dynamic model already contains only matching canonical names.
            # Clear QCompleter's original typed prefix (e.g. "힘") so a canonical
            # candidate such as "STR" is actually visible in the popup.
            self._completer.setCompletionPrefix('')
            self._completer.complete()

    def _accept_completion(self, text):
        canonical = (text or '').strip()
        if not canonical:
            return
        self.kind.setEditText(canonical)
        self.sync()

    def sync(self):
        fam = engine._resolve_family(self.mode, self.kind.currentText())
        units = engine._family_units(self.mode, fam) if fam else []
        cur = self.unit.currentText()
        self.unit.blockSignals(True)
        self.unit.clear()
        self.unit.addItems(units)

        if cur in units:
            self.unit.setCurrentText(cur)
        elif '%' in units:
            self.unit.setCurrentText('%')
        elif units:
            self.unit.setCurrentIndex(0)

        # No option name -> no unit control. A single supported unit is fixed
        # automatically; options that support multiple units (e.g. STR) let the
        # user choose between % and 수치.
        if not self.kind.isEnabled() or not fam or not units:
            self.unit.setEnabled(False)
        elif len(units) >= 2:
            self.unit.setEnabled(True)
        else:
            self.unit.setEnabled(False)

        self.unit.blockSignals(False)
        self.sync_value()

    def sync_value(self):
        off = self.unit.currentText() in ('', '값 없음')
        self.value.setEnabled(self.kind.isEnabled() and not off)
        if off:
            self.value.clear()

    def clear(self):
        self.kind.setCurrentIndex(-1)
        self.kind.setEditText('')
        self.unit.clear()
        self.value.clear()

    def set_enabled(self, enabled, clear=False):
        enabled = bool(enabled)
        if clear:
            self.clear()
        self.kind.setEnabled(enabled)
        self.clear_btn.setEnabled(enabled)
        if enabled:
            self.sync()
        else:
            # Preserve an existing condition when the grade is merely set to
            # 미적용. 잠재없음 passes clear=True and removes it explicitly.
            self.unit.setEnabled(False)
            self.value.setEnabled(False)

    def condition(self):
        t = engine.clean_text(self.kind.currentText())
        v = engine.clean_text(self.value.text())
        if not t and not v:
            return None
        if not t:
            raise ValueError(f'옵션 {self.idx+1}의 종류를 선택하세요.')
        fam = engine._resolve_family(self.mode, t)
        if not fam:
            raise ValueError(f'옵션 종류를 확인하세요: {t}')
        unit = engine.clean_text(self.unit.currentText())
        units = engine._family_units(self.mode, fam)
        if not unit and len(units) == 1:
            unit = units[0]
        d = engine._resolve_condition_def(self.mode, fam, unit)
        if not d:
            raise ValueError(f'옵션 {self.idx+1}의 단위를 확인하세요.')
        if unit == '값 없음':
            num = None
        else:
            if not v:
                raise ValueError(f'옵션 {self.idx+1}의 수치를 입력하세요.')
            try:
                num = float(v)
            except Exception:
                raise ValueError(f'옵션 {self.idx+1}의 수치는 숫자로 입력하세요.')
            if d.get('key') == 'cooldown':
                num = min(num, 2 if self.mode == 'potential' else 1)
        return {
            'slot': self.idx, 'key': d['key'], 'op': '정확히',
            'display': d.get('display') or d.get('label'),
            'kind': d.get('kind'), 'unit': unit, 'value': num,
        }


class FlameRow(QWidget):
    def __init__(self, idx):
        super().__init__()
        self.idx = idx
        h = QHBoxLayout(self)
        h.setContentsMargins(0,0,0,0)
        h.setSpacing(6)
        lab = L(f'옵션 {idx+1}', 'fieldLabel')
        lab.setFixedWidth(45)
        h.addWidget(lab)
        self.kind = QComboBox()
        self.kind.setEditable(True)
        names = [d['label'] for d in engine.FLAME_OPTION_DEFS]
        self.kind.addItems(names)
        self.kind.setCurrentIndex(-1)
        comp = QCompleter(names, self.kind)
        comp.setCaseSensitivity(Qt.CaseInsensitive)
        comp.setFilterMode(Qt.MatchContains)
        self.kind.setCompleter(comp)
        self.unit = QComboBox()
        self.unit.setFixedWidth(72)
        self.unit.setEnabled(False)
        self.value = QLineEdit()
        self.value.setFixedWidth(78)
        self.value.setPlaceholderText('입력')
        self.value.setEnabled(False)
        self.clear_btn = QPushButton('×')
        self.clear_btn.setObjectName('miniButton')
        self.clear_btn.clicked.connect(self.clear)
        h.addWidget(self.kind,1)
        h.addWidget(self.unit)
        h.addWidget(self.value)
        h.addWidget(self.clear_btn)
        self.kind.currentTextChanged.connect(self.sync)

    def sync(self):
        d = engine.FlameCatalog().resolve(self.kind.currentText())
        self.unit.blockSignals(True)
        self.unit.clear()
        if d:
            # 추가옵션은 옵션 종류마다 단위가 하나로 고정됩니다.
            # 단위는 표시만 하고 사용자가 변경하지 못하게 잠급니다.
            self.unit.addItem('%' if d.get('kind') == 'percent' else '수치')
            self.unit.setCurrentIndex(0)
            self.unit.setEnabled(False)
            self.value.setEnabled(True)
        else:
            self.unit.setEnabled(False)
            self.value.setEnabled(False)
            self.value.clear()
        self.unit.blockSignals(False)

    def clear(self):
        self.kind.setCurrentIndex(-1)
        self.kind.setEditText('')
        self.unit.clear()
        self.unit.setEnabled(False)
        self.value.clear()
        self.value.setEnabled(False)

    def set_enabled(self, enabled, clear=False):
        enabled = bool(enabled)
        if clear:
            self.clear()
        self.kind.setEnabled(enabled)
        self.clear_btn.setEnabled(enabled)
        if enabled:
            self.sync()
        else:
            self.unit.setEnabled(False)
            self.value.setEnabled(False)

    def condition(self):
        t = engine.clean_text(self.kind.currentText())
        v = engine.clean_text(self.value.text())
        if not t and not v:
            return None
        if not t or not v:
            raise ValueError(f'추가옵션 {self.idx+1}의 종류와 수치를 입력하세요.')
        d = engine.FlameCatalog().resolve(t)
        if not d:
            raise ValueError(f'추가옵션 종류를 확인하세요: {t}')
        try:
            num = float(v)
        except Exception:
            raise ValueError(f'추가옵션 {self.idx+1}의 수치는 숫자로 입력하세요.')
        return {
            'field': d['key'], 'label': d['label'],
            'unit': '%' if d.get('kind') == 'percent' else '수치',
            'op': '정확히', 'value': num,
        }


class EquipmentDetailDialog(QDialog):
    def __init__(self, parent, row):
        super().__init__(parent)
        self.setWindowTitle('장비 검색 결과 상세')
        self.resize(760, 650)
        self.setStyleSheet(EQUIP_QSS)
        v = QVBoxLayout(self)
        v.addWidget(L(f"{row.get('닉네임','')} · {row.get('장비명','')}", 'pageTitle'))
        v.addWidget(L(f"{row.get('월드','')}  |  Lv.{row.get('레벨','')}  |  {row.get('직업','')}", 'pageSub'))
        t = QTableWidget(0,2)
        t.setHorizontalHeaderLabels(['항목','값'])
        t.horizontalHeader().setSectionResizeMode(0,QHeaderView.ResizeToContents)
        t.horizontalHeader().setSectionResizeMode(1,QHeaderView.Stretch)
        t.verticalHeader().setVisible(False)
        t.setEditTriggers(QAbstractItemView.NoEditTriggers)
        for k,val in row.items():
            if val in ('',None):
                continue
            r = t.rowCount()
            t.insertRow(r)
            t.setItem(r,0,QTableWidgetItem(str(k)))
            t.setItem(r,1,QTableWidgetItem(str(val)))
        v.addWidget(t,1)
        b = QPushButton('닫기')
        b.setObjectName('ghostButton')
        b.clicked.connect(self.accept)
        v.addWidget(b)


class EquipmentModule(QWidget):
    NAV_KEYS = ['search','results','logs','settings','help']
    NAV_LABELS = ['⌕  검색 조건','▦  검색 결과','▣  진행 로그','⚙  설정','?  도움말']

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName('eqRoot')
        self.setStyleSheet(EQUIP_QSS)
        self.results = []
        self.result_sigs = set()
        self.search_thread = None
        self.search_started_at = None
        self.last_candidate_total = 0
        self.last_scan_current = 0
        self.last_429 = 0
        self.app_dir = BASE_DIR.parent
        self.catalog = engine.EquipmentCatalog(
            BASE_DIR/'equipment_catalog.json',
            self.app_dir/'data'/'equipment_catalog_user.json'
        )
        try:
            engine.purge_expired_api_cache(self.app_dir/'api_cache')
        except Exception:
            pass

        root = QHBoxLayout(self)
        root.setContentsMargins(0,0,0,0)
        root.setSpacing(0)
        self.sidebar = SidebarArt()
        root.addWidget(self.sidebar)

        right = QWidget()
        right.setObjectName('eqMainArea')
        rv = QVBoxLayout(right)
        rv.setContentsMargins(16,8,16,0)
        rv.setSpacing(8)
        root.addWidget(right,1)

        self.stack = QStackedWidget()
        rv.addWidget(self.stack,1)
        self.pages = {}
        for k in self.NAV_KEYS:
            w = QWidget()
            w.setObjectName('eqPage')
            self.pages[k] = w
            self.stack.addWidget(w)

        self._build_search()
        self._build_results()
        self._build_logs()
        self._build_settings()
        self._build_help()

        self.footer = QFrame()
        self.footer.setObjectName('eqFooter')
        fl = QHBoxLayout(self.footer)
        fl.setContentsMargins(8,0,8,0)
        fl.addWidget(L('●','statusDot'))
        self.status_label = L('검색을 시작할 수 있습니다.','statusLabel')
        fl.addWidget(self.status_label)
        fl.addStretch()
        self.footer_meta = L('데이터 출처: NEXON Open API','footerMeta')
        fl.addWidget(self.footer_meta)
        rv.addWidget(self.footer)

        self.elapsed_timer = QTimer(self)
        self.elapsed_timer.timeout.connect(self._refresh_elapsed)
        self.elapsed_timer.start(1000)
        self.show_page('search')

    # ---------- shared UI helpers ----------
    def _page_header(self, title, subtitle, right_widget=None):
        box = QFrame()
        box.setObjectName('pageHeader')
        h = QHBoxLayout(box)
        h.setContentsMargins(0,0,0,0)
        h.setSpacing(10)
        h.addWidget(L(title,'pageTitle'))
        h.addWidget(L(subtitle,'pageSub'))
        h.addStretch(1)
        if right_widget is not None:
            h.addWidget(right_widget)
        return box

    def _card(self, no, title, hint):
        card = QFrame()
        card.setObjectName('sectionPanel')
        v = QVBoxLayout(card)
        v.setContentsMargins(0,0,0,0)
        v.setSpacing(0)
        head = QFrame()
        head.setObjectName('sectionHeader')
        hh = QHBoxLayout(head)
        hh.setContentsMargins(12,8,12,8)
        hh.setSpacing(8)
        badge = L(str(no),'sectionBadge')
        badge.setFixedSize(34,30)
        badge.setAlignment(Qt.AlignCenter)
        hh.addWidget(badge)
        hh.addWidget(L(title,'subSectionTitle'))
        hh.addWidget(L(hint,'mutedText'))
        hh.addStretch(1)
        v.addWidget(head)
        body = QWidget()
        body_lay = QVBoxLayout(body)
        body_lay.setContentsMargins(12,10,12,11)
        body_lay.setSpacing(7)
        v.addWidget(body)
        return card, body_lay

    def _option_card(self, no, title, mode):
        card, body = self._card(no, title, '등급과 최대 3줄 옵션을 설정합니다.')

        # Compact one-line grade/order controls. These intentionally do not span
        # the full option-row width; the unused right side stays visually calm.
        top = QHBoxLayout()
        top.setContentsMargins(0,0,0,0)
        top.setSpacing(6)
        grade_lab = L('등급','fieldLabel')
        grade_lab.setFixedWidth(45)
        top.addWidget(grade_lab)
        grade = QComboBox()
        grade.addItems(engine.GRADES)
        grade.setFixedWidth(122)
        top.addWidget(grade)
        top.addSpacing(4)
        order_lab = L('옵션 순서','fieldLabel')
        order_lab.setFixedWidth(76)
        top.addWidget(order_lab)
        order = QComboBox()
        order.addItems(['순서 무관','순서까지 일치'])
        order.setFixedWidth(150)
        top.addWidget(order)
        top.addStretch(1)
        body.addLayout(top)

        rows = []
        for i in range(3):
            r = OptionRow(mode,i)
            rows.append(r)
            body.addWidget(r)

        note = L('등급만 선택하고 옵션을 비우면 해당 등급 전체를 검색합니다.','microText')
        body.addWidget(note)

        def sync_grade_state(value):
            no_potential = value == '잠재없음'
            editable = value not in ('미적용', '잠재없음')
            order.setEnabled(editable)
            for row in rows:
                row.set_enabled(editable, clear=no_potential)

        grade.currentTextChanged.connect(sync_grade_state)
        sync_grade_state(grade.currentText())
        return card, grade, order, rows

    # ---------- search page ----------
    def _build_search(self):
        p = self.pages['search']
        v = QVBoxLayout(p)
        v.setContentsMargins(0,0,0,0)
        v.setSpacing(8)

        reset = QPushButton('↻  기본값으로 초기화')
        reset.setObjectName('ghostButton')
        reset.clicked.connect(self.reset_all)
        v.addWidget(self._page_header('⌕  장비 검색','필요한 조건만 입력해 장비 보유 캐릭터를 검색합니다.',reset))

        sc = QScrollArea()
        sc.setWidgetResizable(True)
        sc.setFrameShape(QFrame.NoFrame)
        host = QWidget()
        host.setObjectName('eqScrollHost')
        sc.setWidget(host)
        v.addWidget(sc,1)
        grid = QGridLayout(host)
        grid.setContentsMargins(0,0,2,4)
        grid.setHorizontalSpacing(10)
        grid.setVerticalSpacing(10)
        grid.setColumnMinimumWidth(0,0)
        grid.setColumnMinimumWidth(1,0)
        grid.setColumnStretch(0,1)
        grid.setColumnStretch(1,1)

        # 01 Character
        c1, b1 = self._card(1,'캐릭터 검색 조건','날짜 · 레벨 · 직업 · 월드')
        g = QGridLayout()
        g.setHorizontalSpacing(10)
        g.setVerticalSpacing(8)
        g.setColumnMinimumWidth(0, 64)
        g.setColumnMinimumWidth(1, 0)
        g.setColumnMinimumWidth(2, 64)
        g.setColumnMinimumWidth(3, 0)
        g.setColumnStretch(1, 1)
        g.setColumnStretch(3, 1)

        g.addWidget(L('기준일','fieldLabel'),0,0)
        self.date = DatePicker((engine.today_kst() - timedelta(days=1)).isoformat())
        self.date.setMinimumWidth(0)
        self.date.setSizePolicy(QSizePolicy.Ignored, QSizePolicy.Fixed)
        g.addWidget(self.date,0,1)

        g.addWidget(L('레벨','fieldLabel'),0,2)
        self.lv_min = QSpinBox(); self.lv_max = QSpinBox()
        self.lv_min.setRange(1,300); self.lv_max.setRange(1,300)
        self.lv_min.setValue(295); self.lv_max.setValue(295)
        self.lv_min.setMinimumWidth(0); self.lv_max.setMinimumWidth(0)
        self.lv_min.setSizePolicy(QSizePolicy.Ignored, QSizePolicy.Fixed); self.lv_max.setSizePolicy(QSizePolicy.Ignored, QSizePolicy.Fixed)
        levels = QHBoxLayout(); levels.setContentsMargins(0,0,0,0); levels.setSpacing(6)
        levels.addWidget(self.lv_min, 1); levels.addWidget(QLabel('~')); levels.addWidget(self.lv_max, 1)
        g.addLayout(levels,0,3)

        g.addWidget(L('직업 대분류','fieldLabel'),1,0)
        self.job_group = QComboBox()
        self.job_group.addItems(list(engine.JOB_GROUPS.keys()))
        self.job_group.setCurrentText('전사')
        self.job_group.setMinimumWidth(0); self.job_group.setSizePolicy(QSizePolicy.Ignored, QSizePolicy.Fixed)
        g.addWidget(self.job_group,1,1)

        g.addWidget(L('세부 직업','fieldLabel'),1,2)
        self.job = QComboBox()
        self.job.setMinimumWidth(0); self.job.setSizePolicy(QSizePolicy.Ignored, QSizePolicy.Fixed)
        g.addWidget(self.job,1,3)
        self.job_group.currentTextChanged.connect(self.sync_jobs)
        self.sync_jobs(self.job_group.currentText())
        self.job.setCurrentText('히어로')

        g.addWidget(L('월드 유형','fieldLabel'),2,0)
        self.world_type_combo = QComboBox()
        self.world_type_combo.addItems(['전체','일반','에오스·핼리오스'])
        self.world_type_combo.setMinimumWidth(0); self.world_type_combo.setSizePolicy(QSizePolicy.Ignored, QSizePolicy.Fixed)
        self.world_type_combo.currentTextChanged.connect(self.sync_worlds)
        g.addWidget(self.world_type_combo,2,1)

        g.addWidget(L('월드','fieldLabel'),2,2)
        self.world_combo = QComboBox()
        self.world_combo.setMinimumWidth(0); self.world_combo.setSizePolicy(QSizePolicy.Ignored, QSizePolicy.Fixed)
        g.addWidget(self.world_combo,2,3)
        self.sync_worlds(self.world_type_combo.currentText())
        b1.addLayout(g)

        world_opts = QHBoxLayout(); world_opts.setContentsMargins(0,0,0,0); world_opts.setSpacing(10)
        self.presets = QCheckBox('프리셋 1~3 포함'); self.presets.setChecked(True)
        world_opts.addWidget(self.presets)
        world_opts.addWidget(L('월드 유형을 선택하면 특정 월드까지 지정할 수 있습니다.','microText'))
        world_opts.addStretch(1)
        b1.addLayout(world_opts)

        # 02 Equipment
        c2, b2 = self._card(2,'장비 검색 조건','장비명 · 일치 방식 · 스타포스')
        equip_wrap = QGridLayout(); equip_wrap.setContentsMargins(0,0,0,0); equip_wrap.setHorizontalSpacing(10); equip_wrap.setVerticalSpacing(8)
        equip_wrap.setColumnStretch(1, 1)
        equip_wrap.setColumnStretch(3, 0)
        equip_wrap.addWidget(L('장비명','fieldLabel'),0,0)
        self.item = QLineEdit(); self.item.setPlaceholderText('장비 이름을 입력하세요')
        comp = QCompleter(sorted(self.catalog.items), self.item)
        comp.setCaseSensitivity(Qt.CaseInsensitive); comp.setFilterMode(Qt.MatchContains)
        self.item.setCompleter(comp)
        equip_wrap.addWidget(self.item,0,1)
        self.item_mode = QComboBox(); self.item_mode.addItems(['정확히 일치','이름 포함']); self.item_mode.setFixedWidth(170)
        equip_wrap.addWidget(self.item_mode,0,2)
        equip_wrap.addWidget(L('스타포스','fieldLabel'),1,0)
        self.star = StarforceSpinBox(); self.star.setRange(0,30); self.star.setSpecialValueText('제한 없음'); self.star.setFixedWidth(155); self.star.setKeyboardTracking(False)
        equip_wrap.addWidget(self.star,1,1)
        equip_wrap.addWidget(L('0 = 제한 없음','microText'),1,2)
        b2.addLayout(equip_wrap)
        b2.addStretch(1)
        b2.addWidget(L(f'장비 자동완성 데이터 {len(self.catalog.items):,}개 · 검색 중 발견한 장비명은 자동 학습됩니다.','microText'))

        # 03/04 option cards
        c3, self.pot_grade, self.pot_order, self.pot_rows = self._option_card(3,'잠재능력','potential')
        c4, self.add_grade, self.add_order, self.add_rows = self._option_card(4,'에디셔널 잠재능력','additional')

        # Keep the two cards in each row visually locked together.
        # Row 0 uses c1's taller content as the natural row height; c2 expands to match it
        # instead of floating vertically in the middle of the grid cell.
        for half_card in (c1, c2):
            half_card.setMinimumWidth(0)
            half_card.setSizePolicy(QSizePolicy.Ignored, QSizePolicy.Expanding)
        for half_card in (c3, c4):
            half_card.setMinimumWidth(0)
            half_card.setSizePolicy(QSizePolicy.Ignored, QSizePolicy.Maximum)

        # 05 Flame options
        c5, b5 = self._card(5,'추가옵션','필요한 추가옵션 최대 4개를 입력합니다.')
        top5 = QHBoxLayout(); top5.setSpacing(6)
        flame_label = L('옵션','fieldLabel')
        flame_label.setFixedWidth(45)
        top5.addWidget(flame_label)
        self.flame_presence = QComboBox(); self.flame_presence.addItems(['미적용','적용']); self.flame_presence.setFixedWidth(120)
        top5.addWidget(self.flame_presence)
        top5.addSpacing(8)
        flame_note = L('미적용이면 추가옵션을 검사하지 않습니다. 적용 후 값을 비운 항목은 조건에 포함되지 않습니다.','microText')
        flame_note.setWordWrap(True)
        top5.addWidget(flame_note,1)
        b5.addLayout(top5)
        fg = QGridLayout(); fg.setHorizontalSpacing(10); fg.setVerticalSpacing(4)
        self.flame_rows = []
        for i in range(4):
            r = FlameRow(i); self.flame_rows.append(r)
            fg.addWidget(r, i//2, i%2)
        b5.addLayout(fg)

        def sync_flame_state(value):
            enabled = value == '적용'
            for row in self.flame_rows:
                row.set_enabled(enabled)

        self.flame_presence.currentTextChanged.connect(sync_flame_state)
        sync_flame_state(self.flame_presence.currentText())

        c5.setSizePolicy(QSizePolicy.Ignored, QSizePolicy.Maximum)
        grid.addWidget(c1,0,0)
        grid.addWidget(c2,0,1)
        grid.addWidget(c3,1,0)
        grid.addWidget(c4,1,1)
        grid.addWidget(c5,2,0,1,2)
        grid.setRowStretch(0, 0)
        grid.setRowStretch(1, 0)
        grid.setRowStretch(2, 0)
        grid.setRowStretch(3, 1)

        # fixed action bar
        action = QFrame(); action.setObjectName('actionBar')
        ah = QHBoxLayout(action); ah.setContentsMargins(10,8,10,8); ah.setSpacing(8)
        result_btn = QPushButton('▦  검색 결과 보기'); result_btn.setObjectName('ghostButton'); result_btn.clicked.connect(lambda:self.show_page('results'))
        ah.addWidget(result_btn)
        self.action_state = L('조건을 확인한 뒤 검색을 시작하세요.','mutedText')
        ah.addWidget(self.action_state)
        ah.addStretch(1)
        self.search_btn = QPushButton('⌕   검색 시작'); self.search_btn.setObjectName('searchButton'); self.search_btn.setMinimumWidth(420)
        self.search_btn.clicked.connect(self.start_search)
        ah.addWidget(self.search_btn)
        v.addWidget(action)

    # ---------- results page ----------
    def _build_results(self):
        p = self.pages['results']
        v = QVBoxLayout(p); v.setContentsMargins(6,4,6,10); v.setSpacing(8)
        csvb = QPushButton('↓  결과 내보내기 (CSV)'); csvb.setObjectName('ghostButton'); csvb.clicked.connect(self.export_csv)
        v.addWidget(self._page_header('검색 결과','조건과 일치한 장비 보유 캐릭터를 확인합니다.',csvb))

        metrics = QHBoxLayout(); metrics.setSpacing(8)
        self.metric_results = MetricBox('검색 결과','0','일치 캐릭터')
        self.metric_candidates = MetricBox('후보 캐릭터','0','스캔 대상')
        self.metric_progress = MetricBox('처리 진행','0%','현재 검색')
        self.metric_429 = MetricBox('429 대기','0','호출 제한 횟수')
        for m in (self.metric_results,self.metric_candidates,self.metric_progress,self.metric_429): metrics.addWidget(m)
        v.addLayout(metrics)

        split = QSplitter(Qt.Horizontal)
        left = QFrame(); left.setObjectName('sectionPanel'); lv = QVBoxLayout(left); lv.setContentsMargins(10,10,10,10); lv.setSpacing(7)
        hh = QHBoxLayout(); hh.addWidget(L('검색 목록','subSectionTitle')); self.count_badge = L('0명','countBadge'); hh.addWidget(self.count_badge); hh.addStretch(1); lv.addLayout(hh)
        self.table = QTableWidget(0,7)
        self.table.setHorizontalHeaderLabels(['닉네임','월드','직업','장비명','스타포스','잠재능력','에디셔널'])
        self.table.verticalHeader().setVisible(False)
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SingleSelection)
        self.table.setAlternatingRowColors(True)
        hdr = self.table.horizontalHeader()
        hdr.setDefaultAlignment(Qt.AlignCenter)
        # Keep identity/equipment columns stable; potential/additional share the
        # remaining width so long option strings cannot collapse the equipment name.
        for c in range(5):
            hdr.setSectionResizeMode(c, QHeaderView.Fixed)
        self.table.setColumnWidth(0, 110)   # 닉네임
        self.table.setColumnWidth(1, 78)    # 월드
        self.table.setColumnWidth(2, 82)    # 직업
        self.table.setColumnWidth(3, 205)   # 장비명
        self.table.setColumnWidth(4, 78)    # 스타포스
        hdr.setSectionResizeMode(5, QHeaderView.Stretch)
        hdr.setSectionResizeMode(6, QHeaderView.Stretch)
        hdr.setStretchLastSection(False)
        self.table.setTextElideMode(Qt.ElideRight)
        self.table.cellDoubleClicked.connect(self.open_detail)
        self.table.itemSelectionChanged.connect(self._update_detail_preview)
        lv.addWidget(self.table,1)
        split.addWidget(left)

        detail = QFrame(); detail.setObjectName('detailCard'); dv = QVBoxLayout(detail); dv.setContentsMargins(12,11,12,12); dv.setSpacing(7)
        dv.addWidget(L('선택한 장비 상세 정보','subSectionTitle'))
        dv.addWidget(L('행을 선택하면 장비 옵션과 캐릭터 정보가 표시됩니다.','mutedText'))
        self.detail_text = QPlainTextEdit(); self.detail_text.setObjectName('detailText'); self.detail_text.setReadOnly(True); self.detail_text.setPlaceholderText('검색 결과를 선택하세요.')
        dv.addWidget(self.detail_text,1)
        open_btn = QPushButton('상세 창 열기'); open_btn.setObjectName('ghostButton'); open_btn.clicked.connect(self._open_selected_detail); dv.addWidget(open_btn)
        split.addWidget(detail)
        split.setSizes([820,330])
        v.addWidget(split,1)

    # ---------- log page ----------
    def _build_logs(self):
        p = self.pages['logs']
        v = QVBoxLayout(p); v.setContentsMargins(6,4,6,10); v.setSpacing(8)
        clear = QPushButton('로그 비우기'); clear.setObjectName('ghostButton'); clear.clicked.connect(lambda:self.log_box.clear())
        v.addWidget(self._page_header('진행 로그','검색 진행 상황과 API 상태를 실시간으로 확인합니다.',clear))

        metrics = QHBoxLayout(); metrics.setSpacing(8)
        self.log_metric_scan = MetricBox('처리 캐릭터','0 / 0','현재 스캔')
        self.log_metric_match = MetricBox('매칭 결과','0','검색 결과')
        self.log_metric_stage = MetricBox('작업 단계','대기','')
        self.log_metric_elapsed = MetricBox('경과 시간','00:00:00','')
        for m in (self.log_metric_scan,self.log_metric_match,self.log_metric_stage,self.log_metric_elapsed): metrics.addWidget(m)
        v.addLayout(metrics)

        split = QSplitter(Qt.Horizontal)
        log_card = QFrame(); log_card.setObjectName('sectionPanel'); lcv = QVBoxLayout(log_card); lcv.setContentsMargins(10,10,10,10)
        lcv.addWidget(L('실시간 진행 로그','subSectionTitle'))
        self.log_box = QPlainTextEdit(); self.log_box.setReadOnly(True); self.log_box.setObjectName('logBox'); lcv.addWidget(self.log_box,1)
        split.addWidget(log_card)

        side = QFrame(); side.setObjectName('sideStatus'); sv = QVBoxLayout(side); sv.setContentsMargins(14,14,14,14); sv.setSpacing(10)
        sv.addWidget(L('실시간 상태','subSectionTitle'))
        self.live_state = L('대기','liveState'); self.live_state.setWordWrap(True); sv.addWidget(self.live_state)
        self.live_sub = L('검색을 시작하면 현재 작업 단계가 표시됩니다.','liveSub'); self.live_sub.setWordWrap(True); sv.addWidget(self.live_sub)
        self.live_progress = QProgressBar(); self.live_progress.setRange(0,1000); self.live_progress.setValue(0); self.live_progress.setTextVisible(False); sv.addWidget(self.live_progress)
        self.live_percent = L('0.0%','mutedText'); sv.addWidget(self.live_percent)
        sv.addStretch(1)
        self.log_stop_btn = QPushButton('■  검색 중지'); self.log_stop_btn.setObjectName('ghostButton'); self.log_stop_btn.clicked.connect(self.start_search); sv.addWidget(self.log_stop_btn)
        split.addWidget(side)
        split.setSizes([850,300])
        v.addWidget(split,1)

    # ---------- settings/help ----------
    def _build_settings(self):
        p=self.pages['settings']; v=QVBoxLayout(p); v.setContentsMargins(10,8,10,10); v.setSpacing(10)
        v.addWidget(self._page_header('설정','공통 NEXON Open API Key와 검색 엔진 상태를 관리합니다.'))
        box=QFrame(); box.setObjectName('settingsCard'); g=QGridLayout(box); g.setContentsMargins(20,18,20,18); g.setHorizontalSpacing(10); g.setVerticalSpacing(12)
        g.addWidget(L('API 연결','settingLabel'),0,0)
        self.api_state=L('', 'mutedText'); g.addWidget(self.api_state,0,1,1,4)
        g.addWidget(L('API Key','settingLabel'),1,0)
        self.api_edit=QLineEdit(); self.api_edit.setEchoMode(QLineEdit.EchoMode.Password); self.api_edit.setPlaceholderText('NEXON Open API Key 입력')
        g.addWidget(self.api_edit,1,1,1,2)
        self.api_save_btn=QPushButton('저장'); self.api_save_btn.setObjectName('ghostButton'); self.api_save_btn.clicked.connect(self._save_shared_api_key); g.addWidget(self.api_save_btn,1,3)
        self.api_logout_btn=QPushButton('로그아웃'); self.api_logout_btn.setObjectName('ghostButton'); self.api_logout_btn.clicked.connect(self._logout_shared_api_key); g.addWidget(self.api_logout_btn,1,4)
        g.addWidget(L('랭킹 병렬','settingLabel'),2,0); g.addWidget(L(f'{engine.SERVICE_RANK_WORKERS} 페이지','mutedText'),2,1)
        g.addWidget(L('캐릭터 병렬','settingLabel'),3,0); g.addWidget(L(f'{engine.SERVICE_SCAN_WORKERS} 명','mutedText'),3,1)
        g.addWidget(L('최대 동시 작업','settingLabel'),4,0); g.addWidget(L(f'{engine.SERVICE_MAX_INFLIGHT}','mutedText'),4,1)
        g.addWidget(L('다음 실행 첫 화면','settingLabel'),5,0)
        self.startup_combo=QComboBox(); self.startup_combo.addItem('MapleTools 홈','home'); self.startup_combo.addItem('장비 검색기','equipment'); self.startup_combo.addItem('유니온챔피언 검색기','union')
        self.startup_combo.setToolTip('프로그램을 다음에 실행할 때 처음 표시할 화면을 선택합니다.')
        self.startup_combo.currentIndexChanged.connect(self._save_startup_view); g.addWidget(self.startup_combo,5,1,1,2)
        g.addWidget(L('다음 실행부터 적용','mutedText'),5,3,1,2)
        g.setColumnStretch(1,1); g.setColumnStretch(2,1)
        v.addWidget(box); v.addStretch(1)
        API_STORE.changed.connect(self._sync_shared_api_ui)
        self._sync_shared_api_ui(API_STORE.get_key())
        STARTUP_STORE.changed.connect(self._sync_startup_ui)
        self._sync_startup_ui(STARTUP_STORE.get_startup_view())

    def _sync_shared_api_ui(self, key=''):
        if not hasattr(self, 'api_edit'): return
        key = str(key or API_STORE.get_key()).strip()
        if self.api_edit.text() != key: self.api_edit.setText(key)
        if key:
            self.api_state.setText('●  API Key 저장됨 · 장비/유니온 공통 적용')
            self.api_state.setStyleSheet('color:#62E7BD;font-weight:900;padding:8px 10px;background:#0B2B2D;border:1px solid #1E665D;border-radius:6px;')
        else:
            self.api_state.setText('●  API Key 미설정')
            self.api_state.setStyleSheet('color:#F4B85C;font-weight:900;padding:8px 10px;background:#2A2110;border:1px solid #6B5621;border-radius:6px;')

    def _save_shared_api_key(self):
        try:
            API_STORE.save_key(self.api_edit.text())
            self.status('API Key가 저장되었습니다. 두 검색기에 공통 적용됩니다.')
        except ValueError as e:
            QMessageBox.warning(self,'API Key',str(e))

    def _logout_shared_api_key(self):
        API_STORE.clear_key()
        self.api_edit.clear()
        self.status('저장된 API Key가 삭제되었습니다.')


    def _sync_startup_ui(self, value=''):
        if not hasattr(self, 'startup_combo'):
            return
        value = str(value or STARTUP_STORE.get_startup_view())
        idx = self.startup_combo.findData(value)
        if idx < 0:
            idx = self.startup_combo.findData('equipment')
        self.startup_combo.blockSignals(True)
        self.startup_combo.setCurrentIndex(max(0, idx))
        self.startup_combo.blockSignals(False)

    def _save_startup_view(self):
        if not hasattr(self, 'startup_combo'):
            return
        value = self.startup_combo.currentData()
        if value:
            STARTUP_STORE.set_startup_view(str(value))
            try:
                self.status('다음 실행 시 첫 화면 설정이 저장되었습니다.')
            except Exception:
                pass

    def _build_help(self):
        p=self.pages['help']; v=QVBoxLayout(p); v.setContentsMargins(10,8,10,10); v.setSpacing(10)
        v.addWidget(self._page_header('도움말','처음 사용하는 분을 위한 장비검색기 사용 방법입니다.'))
        c=QFrame(); c.setObjectName('settingsCard'); cv=QVBoxLayout(c); cv.setContentsMargins(18,14,18,14); cv.setSpacing(0)
        t=L('<b>메이플 장비 검색기 v2.0.1</b><br><br><b>1. 검색 조건 설정</b><br>① 기준일·레벨·직업·월드를 선택합니다. 기본 기준일은 전날로 설정됩니다.<br>② 장비명/스타포스, 잠재능력, 에디셔널 잠재능력, 추가옵션 중 필요한 조건을 입력합니다.<br>③ 2~5번 검색 조건 중 최소 하나는 설정해야 검색을 시작할 수 있습니다.<br><br><b>2. 옵션 입력 규칙</b><br>• 미적용: 해당 항목은 검색 조건에서 제외합니다.<br>• 잠재없음: 잠재능력 또는 에디셔널 잠재능력이 없는 장비만 검색합니다.<br>• 등급만 선택하고 옵션을 비우면 해당 등급 전체를 검색합니다.<br>• 옵션을 입력하면 단위(%/수치)를 확인하고 원하는 값을 입력합니다.<br>• 추가옵션은 선택한 옵션과 입력한 수치가 정확히 일치하는 장비를 검색합니다.<br><br><b>3. 검색 및 결과 확인</b><br>① 검색 시작을 누르면 결과가 확인되는 순서대로 검색 결과에 표시됩니다.<br>② 진행 로그에서 현재 검색 진행 상황을 확인할 수 있습니다.<br>③ 결과를 선택하면 우측에서 장비 옵션과 캐릭터 정보를 확인할 수 있습니다.<br>④ 상세 창에서는 캐릭터 정보, 타임라인, 코디 기록을 확인할 수 있습니다.<br>⑤ 필요한 경우 검색 결과를 CSV 파일로 저장할 수 있습니다.<br><br>※ 오늘 데이터는 갱신 시점에 따라 정상적으로 조회되지 않을 수 있어 전날 기준 조회를 권장합니다.<br>※ API Key는 설정에서 한 번 저장하면 장비검색기와 유니온챔피언 검색기에 공통 적용되며, 로그아웃하면 저장된 Key가 삭제됩니다.','helpText')
        t.setWordWrap(True); cv.addWidget(t); v.addWidget(c); v.addStretch(1)
    # ---------- state / config ----------
    def sync_jobs(self, group):
        cur = self.job.currentText() if self.job.count() else ''
        self.job.clear()
        self.job.addItems(engine.JOB_GROUPS.get(group,['전체']))
        if cur in engine.JOB_GROUPS.get(group,[]):
            self.job.setCurrentText(cur)

    def sync_worlds(self, world_type):
        """유니온 챔피언 검색기와 동일한 월드 유형/월드 연동."""
        current = self.world_combo.currentData() if self.world_combo.count() else ''
        self.world_combo.blockSignals(True)
        self.world_combo.clear()
        if world_type == '전체':
            self.world_combo.addItem('전체 월드','')
            self.world_combo.setCurrentIndex(0)
            self.world_combo.setEnabled(False)
        elif world_type == '에오스·핼리오스':
            for w in engine.SPECIAL_WORLDS:
                self.world_combo.addItem(w,w)
            self.world_combo.setEnabled(True)
            idx = self.world_combo.findData(current)
            self.world_combo.setCurrentIndex(idx if idx >= 0 else 0)
        else:  # 일반
            self.world_combo.addItem('전체 일반 월드','')
            for w in engine.NORMAL_WORLDS:
                self.world_combo.addItem(w,w)
            self.world_combo.setEnabled(True)
            idx = self.world_combo.findData(current)
            self.world_combo.setCurrentIndex(idx if idx >= 0 else 0)
        self.world_combo.blockSignals(False)

    def reset_all(self):
        self.date.setDate(QDate.fromString((engine.today_kst() - timedelta(days=1)).isoformat(),'yyyy-MM-dd'))
        self.lv_min.setValue(295); self.lv_max.setValue(295)
        self.job_group.setCurrentText('전사'); self.job.setCurrentText('히어로')
        self.world_type_combo.setCurrentText('전체'); self.sync_worlds('전체'); self.presets.setChecked(True)
        self.item.clear(); self.item_mode.setCurrentText('정확히 일치'); self.star.setValue(0)
        self.pot_grade.setCurrentText('미적용'); self.add_grade.setCurrentText('미적용')
        self.pot_order.setCurrentText('순서 무관'); self.add_order.setCurrentText('순서 무관')
        [r.clear() for r in self.pot_rows+self.add_rows]
        self.flame_presence.setCurrentText('미적용'); [r.clear() for r in self.flame_rows]
        self.status('초기화되었습니다.')
        self.action_state.setText('조건을 확인한 뒤 검색을 시작하세요.')

    def _conditions(self, rows, grade):
        if grade.currentText() == '미적용':
            return []
        return [c for r in rows if (c := r.condition())]

    def config(self):
        raw_date = self.date.text()
        try:
            d = engine.parse_flexible_search_date(raw_date)
        except ValueError as e:
            raise ValueError(str(e))
        if d < engine.OPENAPI_HISTORY_START:
            raise ValueError('메이플스토리 Open API 조회 날짜는 2023-12-21 이후여야 합니다.')
        if d > (engine.today_kst() - timedelta(days=1)):
            raise ValueError('오늘 날짜와 미래 날짜는 조회할 수 없습니다. 전날까지 선택해 주세요.')
        if not API_STORE.get_key():
            raise ValueError('설정에서 NEXON Open API Key를 입력하고 저장해 주세요.')
        mn,mx = self.lv_min.value(),self.lv_max.value()
        if mx < mn:
            raise ValueError('레벨 범위를 확인하세요.')
        world_type = self.world_type_combo.currentText()
        if world_type == '일반':
            wt = [0]
        elif world_type == '에오스·핼리오스':
            wt = [1]
        else:
            wt = [0,1]
        world_name = self.world_combo.currentData() or ''
        flames=[]
        if self.flame_presence.currentText() == '적용':
            flames=[c for r in self.flame_rows if (c:=r.condition())]
        return {
            'api_key':API_STORE.get_key(),
            'date':d.isoformat(), 'min_level':mn, 'max_level':mx,
            'job_group':self.job_group.currentText(), 'job':self.job.currentText(),
            'world_types':wt, 'world_name':world_name, 'include_presets':self.presets.isChecked(),
            'item_name':engine.clean_text(self.item.text()), 'item_name_mode':self.item_mode.currentText(),
            'starforce':'' if self.star.value()==0 else str(self.star.value()),
            'potential_grade':self.pot_grade.currentText(),
            'potential_conditions':self._conditions(self.pot_rows,self.pot_grade),
            'potential_order':self.pot_order.currentText(),
            'additional_grade':self.add_grade.currentText(),
            'additional_conditions':self._conditions(self.add_rows,self.add_grade),
            'additional_order':self.add_order.currentText(),
            'flame_presence':self.flame_presence.currentText(), 'flame_conditions':flames,
            'max_pages':300, 'base_interval':engine.SERVICE_REQUEST_INTERVAL,
            'service_high_speed':True, 'rank_workers':engine.SERVICE_RANK_WORKERS,
            'scan_workers':engine.SERVICE_SCAN_WORKERS, 'max_inflight':engine.SERVICE_MAX_INFLIGHT,
            'character_realtime':d==engine.today_kst(),
        }

    # ---------- search execution ----------
    def _has_equipment_filter(self):
        """Require at least one real condition from sections 2-5.

        Section 1 only narrows the candidate character population. Running with
        no equipment-side condition would otherwise scan every matching
        character, which is both slow and easy to trigger accidentally.
        """
        # 2. Equipment name or starforce
        if engine.clean_text(self.item.text()) or self.star.value() > 0:
            return True
        # 3/4. Any grade selection, including '잠재없음', is meaningful.
        if self.pot_grade.currentText() != '미적용':
            return True
        if self.add_grade.currentText() != '미적용':
            return True
        # 5. '적용' with empty rows intentionally means no flame/additional option.
        if self.flame_presence.currentText() == '적용':
            return True
        return False

    def start_search(self):
        if self.search_thread and self.search_thread.isRunning():
            self.search_thread.stop()
            self.status('중지 요청됨...')
            self.action_state.setText('현재 검색을 중지하는 중입니다...')
            self.live_state.setText('중지 요청')
            return
        if not self._has_equipment_filter():
            show_notice(
                self,
                '검색 조건',
                '장비 검색 조건 2~5 중 최소 하나를 설정해 주세요.\n'
                '예: 장비명/스타포스, 잠재능력 등급, 에디셔널 등급, 추가옵션 적용',
                level='info'
            )
            return
        try:
            cfg=self.config()
        except ValueError as e:
            show_notice(self, '입력 확인', str(e), level='warning'); return
        cp=engine.Checkpoint(self.app_dir,cfg); resume=False
        if cp.exists():
            try:
                cp.load(); phase=cp.data.get('phase',''); done=len(cp.data.get('completed',{})); total=len(cp.data.get('candidates',[]))
                if phase=='done':
                    use_saved=themed_confirm(
                        self,
                        '이전 검색 기록',
                        f'같은 조건으로 완료된 검색 기록이 있습니다.\n\n후보 {total:,}명  ·  완료 {done:,}명\n\n저장된 결과를 불러올까요?',
                        '저장 결과 불러오기',
                        '새로 검색'
                    )
                    if use_saved:
                        self.clear_results(); [self.on_result(r) for r in cp.data.get('results') or []]
                        self.last_candidate_total=total; self.metric_candidates.value.setText(f'{total:,}')
                        self.status(f'완료 · 결과 {len(self.results)}건'); self.show_page('results'); return
                    cp.discard_files()
                else:
                    resume=themed_confirm(
                        self,
                        '이어하기 가능한 검색',
                        f'같은 조건으로 진행하던 검색 기록이 있습니다.\n\n후보 {total:,}명  ·  완료 {done:,}명\n\n이어서 검색할까요?',
                        '이어서 검색',
                        '처음부터 검색'
                    )
                    if not resume: cp.discard_files()
            except Exception:
                try: cp.discard_files()
                except Exception: pass

        self.clear_results()
        self.log_box.appendPlainText('— 새 장비 검색 시작 —')
        self.search_btn.setText('■   검색 중지')
        self.action_state.setText('검색이 진행 중입니다. 진행 로그 탭에서 상세 상태를 확인할 수 있습니다.')
        self.status('검색 준비 중...')
        self.live_state.setText('검색 준비 중')
        self.live_sub.setText('랭킹 후보를 불러오기 위한 준비를 하고 있습니다.')
        self.live_progress.setValue(0); self.live_percent.setText('0.0%')
        self.log_metric_stage.value.setText('준비')
        self.search_started_at = time.monotonic()
        self.search_thread=EquipmentSearchThread(cfg,self.app_dir,resume,self.catalog.learn_many,self)
        self.search_thread.log.connect(self.log)
        self.search_thread.status.connect(self._thread_status)
        self.search_thread.progress.connect(self.on_progress)
        self.search_thread.result_found.connect(self.on_result)
        self.search_thread.completed.connect(self.on_done)
        self.search_thread.failed.connect(self.on_failed)
        self.search_thread.start()

    def clear_results(self):
        self.results=[]; self.result_sigs=set(); self.table.setRowCount(0); self.count_badge.setText('0명')
        self.metric_results.value.setText('0'); self.log_metric_match.value.setText('0'); self.detail_text.clear()

    def on_result(self,r):
        sig=(r.get('닉네임'),r.get('월드'),r.get('장비명'),r.get('스타포스'),r.get('잠재1'),r.get('잠재2'),r.get('잠재3'),r.get('에디1'),r.get('에디2'),r.get('에디3'))
        if sig in self.result_sigs: return
        self.result_sigs.add(sig); self.results.append(r)
        row=self.table.rowCount(); self.table.insertRow(row)
        pot=' / '.join(x for x in (r.get('잠재1'),r.get('잠재2'),r.get('잠재3')) if x)
        add=' / '.join(x for x in (r.get('에디1'),r.get('에디2'),r.get('에디3')) if x)
        vals=[r.get('닉네임',''),r.get('월드',''),r.get('직업',''),r.get('장비명',''),r.get('스타포스',''),pot,add]
        for c,val in enumerate(vals):
            item = QTableWidgetItem(str(val))
            item.setTextAlignment(Qt.AlignCenter)
            self.table.setItem(row,c,item)
        self.table.setRowHeight(row,48)
        n=len(self.results); self.count_badge.setText(f'{n}명'); self.metric_results.value.setText(f'{n:,}'); self.log_metric_match.value.setText(f'{n:,}')

    def on_progress(self,stage,cur,total):
        if stage=='rank':
            self.status(f'랭킹 후보 수집 · {cur}/{total} 페이지')
            self.live_state.setText('랭킹 후보 수집 중')
            self.live_sub.setText(f'{cur}/{total} 페이지 처리')
            self.log_metric_stage.value.setText('후보 수집')
            self.metric_progress.value.setText(f'{cur}/{total}p')
            pct=(cur/total*100) if total else 0
        else:
            self.last_candidate_total=total; self.last_scan_current=cur
            self.status(f'장비 검사 · {cur:,}/{total:,}')
            self.live_state.setText('장비 정보 조회 중')
            self.live_sub.setText(f'{cur:,} / {total:,} 캐릭터 처리')
            self.log_metric_stage.value.setText('장비 조회')
            self.metric_candidates.value.setText(f'{total:,}')
            self.metric_progress.value.setText(f'{(cur/total*100 if total else 0):.1f}%')
            self.log_metric_scan.value.setText(f'{cur:,} / {total:,}')
            pct=(cur/total*100) if total else 0
        self.live_progress.setValue(int(max(0,min(100,pct))*10)); self.live_percent.setText(f'{pct:.1f}%')

    def on_done(self,d):
        self.search_btn.setText('⌕   검색 시작')
        self.last_429=int(d.get('429') or 0); self.metric_429.value.setText(str(self.last_429))
        if d.get('candidates') is not None:
            self.last_candidate_total=int(d.get('candidates') or 0); self.metric_candidates.value.setText(f'{self.last_candidate_total:,}')
        msg='검색이 중지되었습니다.' if d.get('stopped') else f'검색 완료 · 결과 {len(self.results)}건'
        self.status(msg); self.action_state.setText(msg)
        self.footer_meta.setText(f"데이터 출처: NEXON Open API   |   마지막 갱신: {datetime.now().strftime('%Y-%m-%d %H:%M')}")
        if d.get('stopped'):
            self.live_state.setText('검색 중지됨'); self.log_metric_stage.value.setText('중지')
        else:
            self.live_state.setText('검색 완료'); self.live_sub.setText(f'매칭 결과 {len(self.results):,}건 · 429 {self.last_429}회'); self.live_progress.setValue(1000); self.live_percent.setText('100.0%'); self.log_metric_stage.value.setText('완료'); self.metric_progress.value.setText('100%'); self.show_page('results')
        self.search_started_at=None

    def on_failed(self,msg):
        self.search_btn.setText('⌕   검색 시작')
        self.status('오류가 발생했습니다.')
        self.action_state.setText('오류가 발생했습니다. 진행 로그를 확인하세요.')
        self.live_state.setText('오류'); self.live_sub.setText(str(msg)); self.log_metric_stage.value.setText('오류')
        self.log('오류 · '+msg); self.search_started_at=None
        show_notice(self, '검색 오류', msg, level='error')

    def _thread_status(self,msg):
        self.status(msg); self.live_sub.setText(str(msg))

    def log(self,msg):
        self.log_box.appendPlainText(str(msg))

    def status(self,msg):
        self.status_label.setText(str(msg))

    def _refresh_elapsed(self):
        if self.search_started_at is None: return
        sec=int(time.monotonic()-self.search_started_at)
        self.log_metric_elapsed.value.setText(f'{sec//3600:02d}:{(sec%3600)//60:02d}:{sec%60:02d}')

    # ---------- result detail ----------
    def _detail_for_row(self,row):
        if not row: return ''
        pot='\n'.join(x for x in [row.get('잠재1'),row.get('잠재2'),row.get('잠재3')] if x) or '-'
        add='\n'.join(x for x in [row.get('에디1'),row.get('에디2'),row.get('에디3')] if x) or '-'
        return (
            f"[캐릭터]\n{row.get('닉네임','')}  ·  {row.get('월드','')}\n"
            f"Lv.{row.get('레벨','')}  {row.get('직업','')}\n길드: {row.get('길드','') or '-'}\n\n"
            f"[장비]\n{row.get('장비명','')}\n부위: {row.get('부위','') or '-'}\n스타포스: {row.get('스타포스','') or '0'}\n출처: {row.get('장비출처','') or '-'}\n\n"
            f"[잠재능력 · {row.get('잠재등급','') or '-'}]\n{pot}\n\n"
            f"[에디셔널 · {row.get('에디등급','') or '-'}]\n{add}\n\n"
            f"[추가옵션]\n{row.get('추가옵션','') or '-'}"
        )

    def _update_detail_preview(self):
        r=self.table.currentRow()
        if 0<=r<len(self.results): self.detail_text.setPlainText(self._detail_for_row(self.results[r]))

    def _open_selected_detail(self):
        r=self.table.currentRow()
        if 0<=r<len(self.results):
            from equipment_detail import EquipmentDetailDialog as FullEquipmentDetailDialog
            FullEquipmentDetailDialog(self,self.results[r]).exec()
        else: show_notice(self, '상세 정보', '검색 결과를 먼저 선택하세요.', level='info')

    # ---------- navigation / export ----------
    def show_page(self,key):
        self.stack.setCurrentWidget(self.pages[key])

    def page_index(self):
        return self.stack.currentIndex()

    def export_csv(self):
        if not self.results:
            show_notice(self, 'CSV 저장', '저장할 결과가 없습니다.', level='info'); return
        path,_=QFileDialog.getSaveFileName(self,'결과 CSV 저장','equipment_results.csv','CSV (*.csv)')
        if not path: return
        fields=list(self.results[0].keys())
        with open(path,'w',encoding='utf-8-sig',newline='') as f:
            w=csv.DictWriter(f,fieldnames=fields); w.writeheader(); w.writerows(self.results)
        self.status('CSV 저장이 완료되었습니다.')

    def open_detail(self,row,col):
        if 0<=row<len(self.results):
            from equipment_detail import EquipmentDetailDialog as FullEquipmentDetailDialog
            FullEquipmentDetailDialog(self,self.results[row]).exec()

    def stop(self):
        if self.search_thread and self.search_thread.isRunning():
            self.search_thread.stop(); self.search_thread.wait(1500)
