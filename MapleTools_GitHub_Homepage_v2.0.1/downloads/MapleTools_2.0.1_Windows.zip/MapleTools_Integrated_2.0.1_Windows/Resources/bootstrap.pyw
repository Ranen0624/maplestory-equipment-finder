# -*- coding: utf-8 -*-
import sys, os, importlib.util, threading, traceback, runpy, subprocess
from pathlib import Path
BASE=Path(__file__).resolve().parent
MAIN=BASE/'integrated_main.pyw'
ERROR_LOG=BASE/'startup_error.log'

def write_error(text):
    try: ERROR_LOG.write_text(text,encoding='utf-8',errors='replace')
    except Exception: pass

def show_error(title,message):
    try:
        import tkinter as tk
        from tkinter import messagebox
        r=tk.Tk(); r.withdraw(); messagebox.showerror(title,message); r.destroy()
    except Exception:
        pass

def run_main():
    try:
        if ERROR_LOG.exists():
            try: ERROR_LOG.unlink()
            except Exception: pass
        os.chdir(str(BASE))
        runpy.run_path(str(MAIN), run_name='__main__')
    except SystemExit:
        raise
    except Exception:
        tb=traceback.format_exc()
        write_error(tb)
        show_error('프로그램 시작 오류', '프로그램을 시작하는 중 오류가 발생했습니다.\n\n'+tb[-2600:]+'\n\n오류 기록: Resources\\startup_error.log')
        raise SystemExit(10)

if importlib.util.find_spec('PySide6') is not None:
    run_main(); raise SystemExit

import tkinter as tk
from tkinter import ttk, messagebox
root=tk.Tk(); root.title('Maple Tools · 첫 실행'); root.geometry('470x210'); root.resizable(False,False); root.configure(bg='#081426')
tk.Label(root,text='통합 UI 구성 요소를 준비합니다',bg='#081426',fg='white',font=('맑은 고딕',15,'bold')).pack(pady=(26,8))
tk.Label(root,text='PySide6 UI 런타임이 필요합니다.\n첫 실행에서 한 번만 자동 설치합니다.',bg='#081426',fg='#AFC4DD',font=('맑은 고딕',9),justify='center').pack()
bar=ttk.Progressbar(root,mode='indeterminate',length=360); bar.pack(pady=18); bar.start(12)
status=tk.Label(root,text='다운로드 및 설치 중...',bg='#081426',fg='#64E6B0',font=('맑은 고딕',9,'bold')); status.pack()
def install():
    try:
        p=subprocess.run([sys.executable,'-m','pip','install','--disable-pip-version-check','--no-input','PySide6-Essentials'],capture_output=True,text=True,creationflags=(0x08000000 if os.name=='nt' else 0))
        if p.returncode!=0: raise RuntimeError((p.stderr or p.stdout or 'pip install failed')[-1800:])
        root.after(0,done)
    except Exception as e:
        root.after(0,lambda:fail(str(e)))
def done():
    bar.stop(); status.config(text='설치 완료 · 프로그램을 시작합니다.')
    def go(): root.destroy(); run_main()
    root.after(350,go)
def fail(msg):
    bar.stop(); status.config(text='자동 설치에 실패했습니다.',fg='#FF8298')
    write_error(msg); messagebox.showerror('설치 실패','PySide6-Essentials 설치에 실패했습니다.\n\n'+msg[:1200]); root.destroy()
threading.Thread(target=install,daemon=True).start(); root.mainloop()
