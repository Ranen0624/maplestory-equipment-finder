# -*- coding: utf-8 -*-
from __future__ import annotations
import sys, webbrowser
from pathlib import Path
from PySide6.QtCore import Qt
from PySide6.QtGui import QIcon
from PySide6.QtWidgets import QApplication,QMainWindow,QWidget,QVBoxLayout,QStackedWidget
import union_ui
from equipment_module import EquipmentModule
from home_module import HomeWidget, CommonSettingsDialog, CommonGuideDialog
from common_shell import IntegratedTitleBar,SHELL_QSS
from shared_startup import STARTUP_STORE

BASE_DIR=Path(__file__).resolve().parent
APP_VERSION='2.0.1'
OFFICIAL_SITE='https://ranen0624.github.io/maplestory-equipment-finder/'

class IntegratedMainWindow(QMainWindow):
    META={
        'equipment':{'title':'메이플 장비 검색기','version':'v2.0.1','sub':'M A P L E   E Q U I P M E N T   F I N D E R','icon':BASE_DIR/'eq_app_icon.png','nav':EquipmentModule.NAV_LABELS,'keys':EquipmentModule.NAV_KEYS},
        'union':{'title':'메이플 유니온챔피언 검색기','version':'v2.0.1','sub':'M A P L E   U N I O N   C H A M P I O N   F I N D E R','icon':BASE_DIR/'app_icon.png','nav':['⌕  검색 조건','◷  검색 기록','▣  진행 로그','⚙  설정','?  도움말'],'keys':['home','history','logs','settings','help']}
    }
    def __init__(self):
        super().__init__()
        self.setWindowFlags(Qt.FramelessWindowHint|Qt.Window)
        self.resize(1536,930)
        self.setMinimumSize(1100,700)
        self.current_app='home'

        root=QWidget();root.setObjectName('shellRoot');self.setCentralWidget(root)
        self._root_layout=QVBoxLayout(root);self._root_layout.setContentsMargins(0,0,0,0);self._root_layout.setSpacing(0)
        self.titlebar=IntegratedTitleBar(self);self._root_layout.addWidget(self.titlebar)
        self.app_stack=QStackedWidget();self._root_layout.addWidget(self.app_stack,1)

        self.home=HomeWidget();self.home.actionRequested.connect(self._home_action);self.app_stack.addWidget(self.home)
        self.union=union_ui.MainWindow();self.union.titlebar.hide();self.union.setWindowFlags(Qt.Widget);self.union.setMinimumSize(0,0);self.union.setParent(self.app_stack);self.app_stack.addWidget(self.union)
        self.equipment=EquipmentModule();self.app_stack.addWidget(self.equipment)

        self.setStyleSheet(SHELL_QSS)
        startup=STARTUP_STORE.get_startup_view()
        self.switch_app(startup if startup in {'home','equipment','union'} else 'home')

    def toggle_maximize(self):
        self.showNormal() if self.isMaximized() else self.showMaximized()

    def _module(self):
        if self.current_app=='equipment': return self.equipment
        if self.current_app=='union': return self.union
        return None

    def switch_app(self,key):
        if key=='home':
            self.current_app='home'
            self.app_stack.setCurrentWidget(self.home)
            self.titlebar.hide()
            return
        if key not in self.META:
            return
        self.current_app=key
        self.titlebar.show()
        mod=self._module()
        self.app_stack.setCurrentWidget(mod)
        meta=self.META[key]
        idx=mod.page_index() if key=='equipment' else mod.stack.currentIndex()
        self.titlebar.set_module(meta['title'],meta['version'],meta['sub'],meta['icon'],meta['nav'],idx)
        self.titlebar.app_buttons[key].setChecked(True)

    def _home_action(self,action):
        if action=='open_equipment':
            self.switch_app('equipment');self.equipment.show_page('search');self.titlebar.nav[0].setChecked(True)
        elif action=='open_union':
            self.switch_app('union');self.union.show_page('home');self.titlebar.nav[0].setChecked(True)
        elif action=='settings':
            CommonSettingsDialog(self).exec()
        elif action=='guide':
            CommonGuideDialog(self).exec()
        elif action=='website':
            webbrowser.open(OFFICIAL_SITE)
        elif action=='minimize':
            self.showMinimized()
        elif action=='maximize':
            self.toggle_maximize()
        elif action=='close':
            self.close()

    def show_current_page(self,idx):
        if self.current_app=='home':
            return
        meta=self.META[self.current_app]
        if idx<0 or idx>=len(meta['keys']):
            return
        key=meta['keys'][idx]
        mod=self._module();mod.show_page(key);self.titlebar.nav[idx].setChecked(True)

    def nativeEvent(self,eventType,message):
        if sys.platform.startswith('win') and not self.isMaximized():
            try:
                import ctypes
                from ctypes import wintypes
                msg=wintypes.MSG.from_address(int(message))
                if msg.message==0x0084:
                    x=ctypes.c_short(msg.lParam & 0xFFFF).value
                    y=ctypes.c_short((msg.lParam >> 16) & 0xFFFF).value
                    g=self.frameGeometry();border=7
                    left=g.left()<=x<=g.left()+border;right=g.right()-border<=x<=g.right()
                    top=g.top()<=y<=g.top()+border;bottom=g.bottom()-border<=y<=g.bottom()
                    if top and left:return True,13
                    if top and right:return True,14
                    if bottom and left:return True,16
                    if bottom and right:return True,17
                    if left:return True,10
                    if right:return True,11
                    if top:return True,12
                    if bottom:return True,15
            except Exception:
                pass
        return super().nativeEvent(eventType,message)

    def closeEvent(self,e):
        try:self.equipment.stop()
        except:pass
        try:
            if self.union.search_thread and self.union.search_thread.isRunning():
                self.union.search_thread.stop();self.union.search_thread.wait(1500)
        except:pass
        e.accept()

if __name__=='__main__':
    app=QApplication(sys.argv)
    app.setApplicationName('MapleTools')
    app.setWindowIcon(QIcon(str(BASE_DIR/'MapleTools.ico')))
    w=IntegratedMainWindow();w.show();sys.exit(app.exec())
