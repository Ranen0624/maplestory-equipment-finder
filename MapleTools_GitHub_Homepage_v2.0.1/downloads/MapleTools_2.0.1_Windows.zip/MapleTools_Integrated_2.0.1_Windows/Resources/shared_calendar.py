# -*- coding: utf-8 -*-
"""Shared custom calendar/date picker for the integrated Maple tools.

This intentionally does NOT subclass QCalendarWidget.  Qt's internal calendar
view always reserves six week rows and date text formatting can leak across
pages, which made adjacent-month colouring fragile.  This widget owns every
visible day button, so the rendered rows and colours are deterministic.
"""
from __future__ import annotations
import math
from pathlib import Path

from PySide6.QtCore import Qt, QDate, Signal, QSize, QTimer
from PySide6.QtGui import QIcon
from PySide6.QtWidgets import (
    QWidget, QFrame, QLabel, QPushButton, QToolButton, QLineEdit,
    QHBoxLayout, QVBoxLayout, QGridLayout, QMenu, QWidgetAction,
)


class UnifiedCalendarWidget(QFrame):
    """A compact Sunday-first calendar made from ordinary Qt widgets.

    API intentionally mirrors the small QCalendarWidget subset used by the
    project: setMinimumDate / setMaximumDate / setSelectedDate / selectedDate,
    yearShown / monthShown and clicked/currentPageChanged signals.
    """

    clicked = Signal(QDate)
    currentPageChanged = Signal(int, int)

    TEXT = '#EAF3FF'
    DIM = '#52677F'
    DISABLED = '#3E5065'
    SUNDAY = '#FF5C70'
    SELECT_BG = '#5262E6'
    SELECT_TEXT = '#FFFFFF'

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName('customCalendar')
        self._minimum = QDate(1900, 1, 1)
        self._maximum = QDate(2999, 12, 31)
        self._selected = QDate.currentDate()
        self._shown_year = self._selected.year()
        self._shown_month = self._selected.month()
        self._day_buttons = []

        root = QVBoxLayout(self)
        root.setContentsMargins(7, 6, 7, 7)
        root.setSpacing(4)

        nav = QHBoxLayout()
        nav.setContentsMargins(0, 0, 0, 0)
        nav.setSpacing(4)
        self.prev_btn = QToolButton()
        self.prev_btn.setText('‹')
        self.prev_btn.setFixedSize(32, 30)
        self.prev_btn.clicked.connect(lambda: self._shift_month(-1))
        nav.addWidget(self.prev_btn)
        nav.addStretch(1)
        self.month_label = QLabel()
        self.month_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.month_label.setMinimumWidth(122)
        self.month_label.setFixedHeight(30)
        nav.addWidget(self.month_label)
        nav.addStretch(1)
        self.next_btn = QToolButton()
        self.next_btn.setText('›')
        self.next_btn.setFixedSize(32, 30)
        self.next_btn.clicked.connect(lambda: self._shift_month(1))
        nav.addWidget(self.next_btn)
        root.addLayout(nav)

        weekdays = QGridLayout()
        weekdays.setContentsMargins(0, 0, 0, 0)
        weekdays.setHorizontalSpacing(2)
        names = ['일', '월', '화', '수', '목', '금', '토']
        for col, name in enumerate(names):
            lab = QLabel(name)
            lab.setAlignment(Qt.AlignmentFlag.AlignCenter)
            lab.setFixedSize(36, 24)
            if col == 0:
                lab.setStyleSheet(f'color:{self.SUNDAY};font-weight:700;')
            else:
                lab.setStyleSheet(f'color:{self.TEXT};font-weight:700;')
            weekdays.addWidget(lab, 0, col)
        root.addLayout(weekdays)

        self.days_host = QWidget()
        self.days_grid = QGridLayout(self.days_host)
        self.days_grid.setContentsMargins(0, 0, 0, 0)
        self.days_grid.setHorizontalSpacing(2)
        self.days_grid.setVerticalSpacing(2)
        root.addWidget(self.days_host)

        self.setStyleSheet(f'''
            #customCalendar {{
                background:#08182B;
                border:1px solid #31577E;
                border-radius:8px;
            }}
            #customCalendar QToolButton {{
                background:#0E2743;
                color:#DCEAFF;
                border:none;
                border-radius:5px;
                font-size:18px;
                font-weight:700;
            }}
            #customCalendar QToolButton:hover {{ background:#173A60; }}
            #customCalendar QToolButton:disabled {{ color:#3E5065; background:#0A1C31; }}
        ''')
        self.setFixedWidth(282)
        self._render()

    def _grid_start_and_weeks(self):
        first = QDate(self._shown_year, self._shown_month, 1)
        # QDate: Monday=1 ... Sunday=7. Sunday-first => Sunday offset 0.
        offset = first.dayOfWeek() % 7
        start = first.addDays(-offset)
        weeks = max(4, min(6, int(math.ceil((offset + first.daysInMonth()) / 7.0))))
        return start, weeks

    def _clear_day_buttons(self):
        # deleteLater() alone leaves the old date buttons painted until the
        # event loop runs.  _render() can be called several times back-to-back
        # while setting min/max/selected dates, so those old buttons briefly
        # overlap the newly created ones and make the numbers look doubled.
        # Hide and detach immediately, then defer only the final destruction.
        while self.days_grid.count():
            item = self.days_grid.takeAt(0)
            w = item.widget()
            if w is not None:
                w.hide()
                w.setParent(None)
                w.deleteLater()
        self._day_buttons.clear()

    def _render(self):
        self.days_host.setUpdatesEnabled(False)
        self._clear_day_buttons()
        start, weeks = self._grid_start_and_weeks()
        self.month_label.setText(f'{self._shown_year}년 {self._shown_month}월')

        for idx in range(weeks * 7):
            qd = start.addDays(idx)
            row, col = divmod(idx, 7)
            btn = QPushButton(str(qd.day()))
            btn.setFixedSize(36, 30)
            btn.setCursor(Qt.CursorShape.PointingHandCursor)
            btn.setFocusPolicy(Qt.FocusPolicy.NoFocus)
            btn.setProperty('calendarDate', qd.toString('yyyy-MM-dd'))

            in_current_month = (qd.year() == self._shown_year and qd.month() == self._shown_month)
            in_range = (self._minimum <= qd <= self._maximum)
            selected = (qd == self._selected)

            if selected and in_range:
                fg = self.SELECT_TEXT
                bg = self.SELECT_BG
                border = '#7886FF'
            else:
                bg = 'transparent'
                border = 'transparent'
                if not in_range:
                    fg = self.DISABLED
                elif not in_current_month:
                    fg = self.DIM
                elif col == 0:
                    fg = self.SUNDAY
                else:
                    fg = self.TEXT

            btn.setStyleSheet(
                'QPushButton{'
                f'color:{fg};background:{bg};border:1px solid {border};'
                'border-radius:5px;padding:0;font-size:12px;'
                '}'
                'QPushButton:hover{background:#173A60;border:1px solid #31577E;}'
                f'QPushButton:disabled{{color:{self.DISABLED};background:transparent;border:1px solid transparent;}}'
            )
            btn.setEnabled(in_range)
            if in_range:
                btn.clicked.connect(lambda checked=False, d=QDate(qd): self._choose(d))
            self.days_grid.addWidget(btn, row, col)
            self._day_buttons.append(btn)

        # Only the weeks actually needed by the visible month exist.  Example:
        # Sep 2026 creates 5 rows: Aug 30-31, Sep 1-30, Oct 1-3.  There is no
        # synthetic Oct 4-10 sixth row to hide later.
        height = 6 + 30 + 4 + 24 + 4 + weeks * 32 + 7
        self.setFixedHeight(height)
        self._update_nav_enabled()
        self.days_host.setUpdatesEnabled(True)
        self.days_host.update()
        self.updateGeometry()
        try:
            if isinstance(self.parentWidget(), QMenu):
                self.parentWidget().adjustSize()
        except Exception:
            pass

    def _choose(self, qdate):
        if qdate < self._minimum or qdate > self._maximum:
            return
        self._selected = QDate(qdate)
        self._shown_year = qdate.year()
        self._shown_month = qdate.month()
        self._render()
        self.clicked.emit(QDate(qdate))

    def _month_intersects_range(self, qdate_first):
        last = QDate(qdate_first.year(), qdate_first.month(), qdate_first.daysInMonth())
        return last >= self._minimum and qdate_first <= self._maximum

    def _update_nav_enabled(self):
        first = QDate(self._shown_year, self._shown_month, 1)
        self.prev_btn.setEnabled(self._month_intersects_range(first.addMonths(-1)))
        self.next_btn.setEnabled(self._month_intersects_range(first.addMonths(1)))

    def _shift_month(self, delta):
        first = QDate(self._shown_year, self._shown_month, 1).addMonths(int(delta))
        if not self._month_intersects_range(first):
            return
        self._shown_year, self._shown_month = first.year(), first.month()
        self._render()
        self.currentPageChanged.emit(self._shown_year, self._shown_month)

    # --- Compatibility API ---
    def setMinimumDate(self, qdate):
        if isinstance(qdate, QDate) and qdate.isValid():
            self._minimum = QDate(qdate)
            if self._selected < self._minimum:
                self._selected = QDate(self._minimum)
            self._clamp_page_to_range()
            self._render()

    def setMaximumDate(self, qdate):
        if isinstance(qdate, QDate) and qdate.isValid():
            self._maximum = QDate(qdate)
            if self._selected > self._maximum:
                self._selected = QDate(self._maximum)
            self._clamp_page_to_range()
            self._render()

    def minimumDate(self):
        return QDate(self._minimum)

    def maximumDate(self):
        return QDate(self._maximum)

    def setSelectedDate(self, qdate):
        if not isinstance(qdate, QDate) or not qdate.isValid():
            return
        if qdate < self._minimum:
            qdate = self._minimum
        elif qdate > self._maximum:
            qdate = self._maximum
        self._selected = QDate(qdate)
        self._shown_year, self._shown_month = qdate.year(), qdate.month()
        self._render()

    def selectedDate(self):
        return QDate(self._selected)

    def yearShown(self):
        return int(self._shown_year)

    def monthShown(self):
        return int(self._shown_month)

    def setCurrentPage(self, year, month):
        q = QDate(int(year), int(month), 1)
        if q.isValid() and self._month_intersects_range(q):
            self._shown_year, self._shown_month = q.year(), q.month()
            self._render()
            self.currentPageChanged.emit(self._shown_year, self._shown_month)

    def showSelectedDate(self):
        self._shown_year, self._shown_month = self._selected.year(), self._selected.month()
        self._render()

    # No-op compatibility methods.  They exist so old helper code cannot break
    # if it happens to call QCalendarWidget-specific cosmetic methods.
    def setGridVisible(self, *args):
        pass

    def setNavigationBarVisible(self, *args):
        pass

    def updateCells(self):
        self._render()

    def _clamp_page_to_range(self):
        current = QDate(self._shown_year, self._shown_month, 1)
        if current > self._maximum:
            self._shown_year, self._shown_month = self._maximum.year(), self._maximum.month()
        else:
            last = QDate(current.year(), current.month(), current.daysInMonth())
            if last < self._minimum:
                self._shown_year, self._shown_month = self._minimum.year(), self._minimum.month()


class PopupDatePicker(QFrame):
    """Date field with the custom popup calendar, shared by every module."""

    dateChanged = Signal(QDate)

    def __init__(self, value='', minimum_qdate=None, maximum_qdate=None,
                 icon_path=None, parent=None):
        super().__init__(parent)
        self.setObjectName('datePicker')
        self.minimum_qdate = QDate(minimum_qdate) if isinstance(minimum_qdate, QDate) else QDate(1900,1,1)
        self.maximum_qdate = QDate(maximum_qdate) if isinstance(maximum_qdate, QDate) else QDate(2999,12,31)

        lay = QHBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(0)
        self.edit = QLineEdit(str(value or ''))
        self.edit.setObjectName('dateText')
        self.edit.setPlaceholderText('YYYY-MM-DD')
        self.edit.editingFinished.connect(self._normalize_text)
        lay.addWidget(self.edit, 1)

        self.button = QToolButton()
        self.button.setObjectName('dateButton')
        self.button.setFixedWidth(38)
        self.button.setCursor(Qt.CursorShape.PointingHandCursor)
        if icon_path:
            self.button.setIcon(QIcon(str(icon_path)))
            self.button.setIconSize(QSize(20, 20))
        else:
            self.button.setText('▣')
        lay.addWidget(self.button)

        self.menu = QMenu(self)
        self.menu.setObjectName('calendarMenu')
        self.calendar = UnifiedCalendarWidget(self.menu)
        self.calendar.setMinimumDate(self.minimum_qdate)
        self.calendar.setMaximumDate(self.maximum_qdate)
        action = QWidgetAction(self.menu)
        action.setDefaultWidget(self.calendar)
        self.menu.addAction(action)
        self.button.setMenu(self.menu)
        self.button.setPopupMode(QToolButton.ToolButtonPopupMode.InstantPopup)
        self.calendar.clicked.connect(self._picked)
        self.calendar.currentPageChanged.connect(lambda *_: self._sync_popup_size())
        self.menu.aboutToShow.connect(self._prepare_popup)

        q = QDate.fromString(self.edit.text().strip(), 'yyyy-MM-dd')
        if q.isValid():
            self.setDate(q)
        else:
            self.setDate(self.maximum_qdate if self.maximum_qdate.isValid() else QDate.currentDate())

    def _sync_popup_size(self):
        """Resize the actual popup whenever the visible month needs 5 or 6 rows.

        QMenu caches its QWidgetAction size on first show.  Without explicitly
        resizing the menu, a six-week month (e.g. May/Aug 2026) was clipped to
        the five-week height of the month that opened first.
        """
        # calendar is fixed-width and computes its own exact height in _render().
        # Leave a small allowance for QMenu contents margins/border.
        w = self.calendar.width() + 10
        h = self.calendar.height() + 10
        self.menu.setFixedSize(w, h)
        self.menu.updateGeometry()

    def _prepare_popup(self):
        # Always reopen on the currently selected/input date and size the menu
        # after the calendar has rendered that month.
        q = QDate.fromString(self.edit.text().strip(), 'yyyy-MM-dd')
        if q.isValid():
            self.calendar.setSelectedDate(q)
        self._sync_popup_size()
        # Some Windows styles apply menu margins one event-loop later.
        QTimer.singleShot(0, self._sync_popup_size)

    def _picked(self, qdate):
        if qdate < self.minimum_qdate or qdate > self.maximum_qdate:
            return
        self.edit.setText(qdate.toString('yyyy-MM-dd'))
        self.calendar.setSelectedDate(qdate)
        self._sync_popup_size()
        self.dateChanged.emit(QDate(qdate))
        self.menu.close()

    def _normalize_text(self):
        q = QDate.fromString(self.edit.text().strip(), 'yyyy-MM-dd')
        if not q.isValid():
            q = self.calendar.selectedDate()
        self.setDate(q)

    def text(self):
        return self.edit.text().strip()

    def setText(self, value):
        q = QDate.fromString(str(value or '').strip(), 'yyyy-MM-dd')
        if q.isValid():
            self.setDate(q)
        else:
            self.edit.setText(str(value or ''))

    def date(self):
        q = QDate.fromString(self.edit.text().strip(), 'yyyy-MM-dd')
        if not q.isValid():
            return self.calendar.selectedDate()
        return q

    def setDate(self, qdate):
        if not isinstance(qdate, QDate) or not qdate.isValid():
            return
        if qdate < self.minimum_qdate:
            qdate = self.minimum_qdate
        elif qdate > self.maximum_qdate:
            qdate = self.maximum_qdate
        self.edit.setText(qdate.toString('yyyy-MM-dd'))
        self.calendar.setSelectedDate(qdate)
        self._sync_popup_size()
        self.dateChanged.emit(QDate(qdate))

    def setMinimumDate(self, qdate):
        if isinstance(qdate, QDate) and qdate.isValid():
            self.minimum_qdate = QDate(qdate)
            self.calendar.setMinimumDate(qdate)
            if self.date() < qdate:
                self.setDate(qdate)

    def setMaximumDate(self, qdate):
        if isinstance(qdate, QDate) and qdate.isValid():
            self.maximum_qdate = QDate(qdate)
            self.calendar.setMaximumDate(qdate)
            if self.date() > qdate:
                self.setDate(qdate)
