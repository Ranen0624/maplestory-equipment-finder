﻿param(
    [switch]$Console
)

$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

$Base = Split-Path -Parent $MyInvocation.MyCommand.Path
$Root = Split-Path -Parent $Base
$Boot = Join-Path $Base 'bootstrap.pyw'
$PythonVersion = '3.12.10'
$PythonInstallerUrl = "https://www.python.org/ftp/python/$PythonVersion/python-$PythonVersion-amd64.exe"
$InstallerPath = Join-Path $env:TEMP "python-$PythonVersion-amd64.exe"

function Show-Info([string]$title, [string]$message) {
    try {
        Add-Type -AssemblyName PresentationFramework -ErrorAction SilentlyContinue | Out-Null
        [System.Windows.MessageBox]::Show($message, $title, 'OK', 'Information') | Out-Null
    } catch {}
}

function Show-ErrorBox([string]$title, [string]$message) {
    try {
        Add-Type -AssemblyName PresentationFramework -ErrorAction SilentlyContinue | Out-Null
        [System.Windows.MessageBox]::Show($message, $title, 'OK', 'Error') | Out-Null
    } catch {}
}

function Test-PythonExe([string]$exe) {
    if (-not $exe -or -not (Test-Path -LiteralPath $exe)) { return $false }
    if ($exe -match '\\WindowsApps\\') { return $false }
    try {
        & $exe -c "import sys; raise SystemExit(0 if sys.version_info >= (3,10) else 1)" 2>$null
        return ($LASTEXITCODE -eq 0)
    } catch { return $false }
}

function Find-Python {
    # 1) Known per-user install locations (most reliable after silent install)
    $known = @(
        (Join-Path $env:LOCALAPPDATA 'Programs\Python\Python313\python.exe'),
        (Join-Path $env:LOCALAPPDATA 'Programs\Python\Python312\python.exe'),
        (Join-Path $env:LOCALAPPDATA 'Programs\Python\Python311\python.exe'),
        (Join-Path $env:LOCALAPPDATA 'Programs\Python\Python310\python.exe')
    )
    foreach ($p in $known) { if (Test-PythonExe $p) { return $p } }

    # 2) Python launcher, if installed
    try {
        $py = Get-Command py.exe -ErrorAction SilentlyContinue
        if ($py) {
            foreach ($ver in @('-3.13','-3.12','-3.11','-3.10','-3')) {
                try {
                    $actual = & $py.Source $ver -c "import sys; print(sys.executable)" 2>$null | Select-Object -First 1
                    if (Test-PythonExe $actual) { return $actual }
                } catch {}
            }
        }
    } catch {}

    # 3) PATH python.exe, excluding Microsoft Store alias
    try {
        $cmd = Get-Command python.exe -ErrorAction SilentlyContinue
        if ($cmd -and (Test-PythonExe $cmd.Source)) { return $cmd.Source }
    } catch {}

    # 4) Program Files fallback
    foreach ($baseDir in @($env:ProgramFiles, ${env:ProgramFiles(x86)})) {
        if (-not $baseDir) { continue }
        foreach ($folder in @('Python313','Python312','Python311','Python310')) {
            $p = Join-Path $baseDir ("Python\$folder\python.exe")
            if (Test-PythonExe $p) { return $p }
        }
    }
    return $null
}

function Install-Python {
    Show-Info 'Maple Tools · 첫 실행' "Python이 설치되어 있지 않습니다.`n`n공식 Python $PythonVersion (64비트)을 자동 설치합니다.`n설치가 끝나면 프로그램이 자동으로 계속 실행됩니다."
    try {
        if (Test-Path -LiteralPath $InstallerPath) { Remove-Item -LiteralPath $InstallerPath -Force -ErrorAction SilentlyContinue }
        Invoke-WebRequest -Uri $PythonInstallerUrl -OutFile $InstallerPath -UseBasicParsing

        if (-not (Test-Path -LiteralPath $InstallerPath)) { throw 'Python 설치 파일 다운로드에 실패했습니다.' }
        if ((Get-Item -LiteralPath $InstallerPath).Length -lt 10000000) { throw '다운로드된 Python 설치 파일의 크기가 비정상적입니다.' }

        $sig = Get-AuthenticodeSignature -FilePath $InstallerPath
        if ($sig.Status -ne 'Valid') { throw "Python 설치 파일의 디지털 서명을 확인할 수 없습니다: $($sig.Status)" }
        if ($sig.SignerCertificate.Subject -notmatch 'Python Software Foundation') { throw 'Python Software Foundation 서명이 아닌 설치 파일입니다.' }

        $args = @(
            '/quiet',
            'InstallAllUsers=0',
            'PrependPath=1',
            'Include_launcher=1',
            'InstallLauncherAllUsers=0',
            'Include_pip=1',
            'Include_tcltk=1',
            'Include_test=0',
            'Include_doc=0',
            'Shortcuts=0'
        )
        $proc = Start-Process -FilePath $InstallerPath -ArgumentList $args -Wait -PassThru
        if ($proc.ExitCode -notin @(0,3010)) { throw "Python 설치 프로그램 종료 코드: $($proc.ExitCode)" }
    } finally {
        Remove-Item -LiteralPath $InstallerPath -Force -ErrorAction SilentlyContinue
    }
}

try {
    if (-not (Test-Path -LiteralPath $Boot)) { throw "실행 파일을 찾을 수 없습니다:`n$Boot" }

    $python = Find-Python
    if (-not $python) {
        Install-Python
        Start-Sleep -Milliseconds 700
        $python = Find-Python
    }
    if (-not $python) { throw 'Python 설치 후에도 python.exe를 찾지 못했습니다.' }

    $pythonDir = Split-Path -Parent $python
    $pythonw = Join-Path $pythonDir 'pythonw.exe'

    if ($Console) {
        & $python $Boot
        exit $LASTEXITCODE
    }

    if (Test-Path -LiteralPath $pythonw) {
        Start-Process -FilePath $pythonw -ArgumentList @($Boot) -WorkingDirectory $Base
    } else {
        Start-Process -FilePath $python -ArgumentList @($Boot) -WorkingDirectory $Base
    }
    exit 0
}
catch {
    $msg = $_.Exception.Message
    try { Set-Content -LiteralPath (Join-Path $Base 'launcher_error.log') -Value ($_ | Out-String) -Encoding UTF8 } catch {}
    Show-ErrorBox 'Maple Tools · 실행 오류' ("자동 준비 중 오류가 발생했습니다.`n`n" + $msg + "`n`n오류 기록: Resources\launcher_error.log")
    if ($Console) {
        Write-Host "[오류] $msg" -ForegroundColor Red
    }
    exit 10
}
