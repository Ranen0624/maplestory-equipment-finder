# -*- coding: utf-8 -*-
from __future__ import annotations

import sys, os, csv, threading, urllib.request, urllib.parse, hashlib, webbrowser
from pathlib import Path
from datetime import datetime, timedelta, timezone
from concurrent.futures import ThreadPoolExecutor, as_completed

from PySide6.QtCore import Qt, Signal, QThread, QSize, QPoint, QTimer, QDate, QUrl, QObject
from PySide6.QtGui import QIcon, QPixmap, QImage, QColor, QPainter, QPen, QFont, QFontMetrics, QIntValidator, QRegion, QLinearGradient, QRadialGradient, QPalette, QTextCharFormat
from PySide6.QtNetwork import QNetworkAccessManager, QNetworkRequest
from PySide6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QFrame, QLabel, QPushButton, QHBoxLayout,
    QVBoxLayout, QGridLayout, QStackedWidget, QLineEdit, QComboBox, QSpinBox,
    QCheckBox, QTableWidget, QTableWidgetItem, QHeaderView, QAbstractItemView,
    QFileDialog, QMessageBox, QPlainTextEdit, QSizePolicy, QDialog, QScrollArea,
    QToolButton, QMenu, QWidgetAction, QCalendarWidget,
    QGraphicsDropShadowEffect, QGraphicsOpacityEffect
)

import engine
from shared_calendar import PopupDatePicker
from shared_startup import STARTUP_STORE
from common_shell import show_notice
from shared_api import API_STORE

APP_VERSION = "2.0.1"
BASE_DIR = Path(__file__).resolve().parent


COLORS = {
    "bg":"#071223", "panel":"#0B1B31", "panel2":"#0E2542", "field":"#08182B",
    "line":"#1C4268", "line2":"#285785", "text":"#EEF5FF", "muted":"#94AAC5",
    "faint":"#607A9A", "blue":"#61A8FF", "purple":"#8B72FF", "cyan":"#46D6DE",
    "green":"#68E6A7", "gold":"#FFD05E", "danger":"#FF7793"
}

JOB_GLYPHS = ["✦","◆","✧","⬟","◈","✶","❖","✷"]
JOB_COLORS = ["#78B7FF","#FFD35C","#A77AFF","#FF708E","#61D7C2","#FF9A63","#8FE26A","#E68BFF"]

def job_style(name:str):
    h=int(hashlib.md5(name.encode('utf-8')).hexdigest()[:8],16)
    return JOB_GLYPHS[h%len(JOB_GLYPHS)], JOB_COLORS[h%len(JOB_COLORS)]

def esc(s):
    return str(s or "").replace('&','&amp;').replace('<','&lt;').replace('>','&gt;')

class SearchThread(QThread):
    log = Signal(str)
    status = Signal(str)
    candidate_total = Signal(int)
    result_found = Signal(object)
    progress = Signal(int, int, int)  # done,total,api calls
    completed = Signal(object)
    failed = Signal(str)

    def __init__(self, config, requests, parent=None):
        super().__init__(parent)
        self.config=config; self.requests=requests
        self.stop_event=threading.Event()

    def stop(self): self.stop_event.set()

    def run(self):
        try:
            cfg=self.config; reqs=self.requests
            main_req_idx=max(range(len(reqs)),key=lambda i:(reqs[i]['level'],-reqs[i]['row']))
            main_req=reqs[main_req_idx]
            api=engine.NexonAPI(cfg['api_key'],progress=lambda s:self.log.emit(s))
            self.status.emit(f"본캐 후보 수집 · Lv.{main_req['level']} {main_req['class']}")
            wt=cfg['world_type']
            if main_req.get('world'):
                world_types=[1] if main_req['world'] in ('에오스','핼리오스') else [0]
            elif wt=='일반': world_types=[0]
            elif wt=='에오스·핼리오스': world_types=[1]
            else: world_types=[0,1]

            candidates=[]; seen=set(); max_pages=max(1,cfg['max_pages'])
            main_job=engine.canonical_job(main_req['class'])
            api_class_filter=engine.JOB_API_FILTER.get(main_job)
            for world_type in world_types:
                if self.stop_event.is_set(): break
                page=1; found_target=False; class_filter=api_class_filter; retried=False
                self.log.emit(f"랭킹 후보 수집 · world_type={world_type} · 필터={class_filter or '전체'}")
                while page<=max_pages and not self.stop_event.is_set():
                    try:
                        rows=api.ranking_page(page,class_filter or '',main_req.get('world',''),world_type,cfg['date'])
                    except engine.ApiError as e:
                        emsg=str(e)
                        if page==1 and class_filter and 'OPENAPI00004' in emsg and not retried:
                            self.log.emit('직업 필터를 전체 랭킹 재필터 방식으로 전환합니다.')
                            class_filter=None; retried=True; page=1; continue
                        if page>1 and ('OPENAPI00003' in emsg or 'OPENAPI00004' in emsg): break
                        raise
                    if not rows: break
                    levels=[int(x.get('character_level') or 0) for x in rows]
                    mx,mn=max(levels),min(levels)
                    matches=[]
                    for x in rows:
                        if int(x.get('character_level') or 0)!=main_req['level']: continue
                        rc=engine.canonical_job(x.get('class_name') or '')
                        rs=engine.canonical_job(x.get('sub_class_name') or '')
                        if main_job not in (rc,rs): continue
                        matches.append(x)
                    for x in matches:
                        name=x.get('character_name')
                        if name and name not in seen:
                            seen.add(name)
                            candidates.append({
                                'name':name,'level':int(x.get('character_level') or 0),
                                'class':engine.canonical_job(x.get('sub_class_name') or x.get('class_name') or ''),
                                'world':x.get('world_name') or '', 'ranking':x.get('ranking')
                            })
                    if matches: found_target=True
                    if page==1 or page%10==0 or matches:
                        self.status.emit(f"랭킹 {page}p · 후보 {len(candidates)}명 · API {api.calls}회")
                    if mx<main_req['level']: break
                    if found_target and mn<main_req['level'] and not matches: break
                    page+=1

            self.candidate_total.emit(len(candidates))
            self.log.emit(f"본캐 후보 수집 완료 · {len(candidates)}명")
            if not candidates:
                self.completed.emit({'candidate_total':0,'perfect':0,'partial':0,'api_calls':api.calls,'stopped':False})
                return

            def inspect(cand):
                if self.stop_event.is_set(): return None
                try: champs=api.union_champions(cand['name'],cfg['date'])
                except Exception as e:
                    self.log.emit(f"{cand['name']} 챔피언 조회 실패 · {e}")
                    return None
                chars=[dict(cand)]
                names=[x['name'] for x in champs if x.get('name') and x['name']!=cand['name']]

                # 후보 검증 자체가 이미 병렬이므로 후보 한 명 안에서 다시 8개 스레드를
                # 생성하지 않습니다. 이전 구조는 12×8처럼 수십~백여 개의 HTTP 작업이
                # 순간적으로 생길 수 있어 중간 멈춤/429/메모리 급증의 원인이 될 수 있었습니다.
                for n in names:
                    if self.stop_event.is_set():
                        break
                    try:
                        chars.append(api.basic(n,cfg['date']))
                    except Exception as e:
                        self.log.emit(f"{cand['name']} → {n} 기본정보 조회 실패 · {e}")
                matched=engine.choose_matching(reqs,chars,fixed_main_req_idx=main_req_idx,fixed_main_char_name=cand['name'])
                detail=[]; matched_chars=[]
                for i,r in enumerate(reqs):
                    c=matched.get(i)
                    if c:
                        detail.append(f"{r['row']}:{c['name']}({c['class']} Lv.{c['level']})")
                        matched_chars.append({'row':r['row'],'requested_level':r['level'],'requested_class':r['class'],
                                              'name':c['name'],'search_level':int(c.get('level') or 0),
                                              'search_class':c.get('class') or '', 'search_world':c.get('world') or '',
                                              'image':c.get('image') or ''})
                    else:
                        detail.append(f"{r['row']}:불일치")
                        matched_chars.append({'row':r['row'],'requested_level':r['level'],'requested_class':r['class'],
                                              'name':'','search_level':0,'search_class':'','search_world':'','image':''})

                cand_view=dict(cand)
                if matched and not cand_view.get('image'):
                    try:
                        basic_main=api.basic(cand['name'], cfg['date'])
                        cand_view['image']=basic_main.get('image') or ''
                        cand_view['world']=basic_main.get('world') or cand_view.get('world','')
                        cand_view['class']=basic_main.get('class') or cand_view.get('class','')
                        cand_view['level']=int(basic_main.get('level') or cand_view.get('level') or 0)
                    except Exception as e:
                        self.log.emit(f"{cand['name']} 본캐 이미지 조회 실패 · {e}")

                # 본캐는 랭킹 후보 dict에서 시작하기 때문에 matched_chars 생성 시점에는
                # image 값이 비어 있을 수 있습니다. 본캐 이미지를 조회한 뒤 동일 닉네임의
                # 매칭 항목에도 다시 주입하여 보유 조합 첫 이미지가 비는 현상을 막습니다.
                if cand_view.get('image'):
                    for mc in matched_chars:
                        if mc.get('name') == cand_view.get('name'):
                            mc['image'] = cand_view.get('image') or ''

                # 과거 기준일의 basic 응답에서 이미지가 비어 있는 경우가 있으면
                # 해당 캐릭터만 최신 basic으로 한 번 보완합니다.
                for mc in matched_chars:
                    if not mc.get('name') or mc.get('image'):
                        continue
                    try:
                        latest = api.basic(mc['name'], None)
                        mc['image'] = latest.get('image') or ''
                    except Exception as e:
                        self.log.emit(f"{mc.get('name','')} 이미지 보완 조회 실패 · {e}")

                return {'candidate':cand_view,'score':len(matched),'total':len(reqs),'detail':detail,
                        'chars':chars,'matched_chars':matched_chars}

            done=0; perfect=0; partial=0
            requested_workers=max(1,int(cfg['workers']))
            actual_workers=min(20,requested_workers)
            if requested_workers>actual_workers:
                self.log.emit(
                    f"서비스 API 안정성을 위해 후보 동시 검증을 {actual_workers}개로 제한합니다. "
                    f"(설정값 {requested_workers})"
                )
            else:
                self.log.emit(f"후보 동시 검증 {actual_workers}개로 시작합니다.")

            with ThreadPoolExecutor(max_workers=actual_workers) as ex:
                futs={ex.submit(inspect,c):c for c in candidates}
                for f in as_completed(futs):
                    if self.stop_event.is_set(): break
                    try:r=f.result()
                    except Exception as e:
                        self.log.emit(f"후보 검증 오류 · {e}"); r=None
                    done+=1
                    if r:
                        if r['score']==r['total']: perfect+=1
                        else: partial+=1
                        if (not cfg['perfect_only']) or r['score']==r['total']:
                            self.result_found.emit(r)
                    self.progress.emit(done,len(candidates),api.calls)
                    if done%5==0 or done==len(candidates):
                        self.status.emit(f"후보 검증 {done}/{len(candidates)} · API {api.calls}회")

            self.completed.emit({'candidate_total':len(candidates),'perfect':perfect,'partial':partial,
                                 'api_calls':api.calls,'stopped':self.stop_event.is_set()})
        except Exception as e:
            self.failed.emit(str(e))

class DetailThread(QThread):
    loaded=Signal(object,int)
    failed=Signal(str)
    def __init__(self,key,items,parent=None):
        super().__init__(parent); self.key=key; self.items=items
    def run(self):
        try:
            api=engine.NexonAPI(self.key)
            def one(item):
                info=api.basic(item['name'],None)
                anchor_data=b''
                display_data=b''
                image_url=(info.get('image') or '').strip()

                if image_url:
                    try:
                        parts=urllib.parse.urlsplit(image_url)
                        base_params=dict(
                            urllib.parse.parse_qsl(
                                parts.query,
                                keep_blank_values=True
                            )
                        )
                        base_params['action']='A00.0'
                        base_params['emotion']='E00'

                        # 1) 위치/크기 계산 전용: 무기 제외
                        anchor_params=dict(base_params)
                        anchor_params['wmotion']='W04'
                        anchor_url=urllib.parse.urlunsplit((
                            parts.scheme,
                            parts.netloc,
                            parts.path,
                            urllib.parse.urlencode(anchor_params),
                            parts.fragment,
                        ))

                        # 2) 실제 화면 표시용: 무기 포함 기본 모션
                        display_params=dict(base_params)
                        display_params['wmotion']='W00'
                        display_url=urllib.parse.urlunsplit((
                            parts.scheme,
                            parts.netloc,
                            parts.path,
                            urllib.parse.urlencode(display_params),
                            parts.fragment,
                        ))

                        def download(url):
                            req=urllib.request.Request(
                                url,
                                headers={
                                    'User-Agent':
                                    'MapleUnionChampionFinder/2.1.16'
                                }
                            )
                            with urllib.request.urlopen(
                                req,
                                timeout=20
                            ) as r:
                                return r.read()

                        try:
                            anchor_data=download(anchor_url)
                        except Exception:
                            anchor_data=b''

                        try:
                            display_data=download(display_url)
                        except Exception:
                            display_data=b''

                        # 표시용 렌더링이 실패하면 원본 URL을 최종 폴백
                        if not display_data:
                            try:
                                display_data=download(image_url)
                            except Exception:
                                display_data=b''

                        # 위치 기준용 W04가 실패하면 표시용 이미지를 대신 사용
                        if not anchor_data:
                            anchor_data=display_data

                    except Exception:
                        pass

                return item,info,anchor_data,display_data
            out=[]
            with ThreadPoolExecutor(max_workers=min(6,len(self.items))) as ex:
                futs=[ex.submit(one,x) for x in self.items]
                for f in as_completed(futs): out.append(f.result())
            out.sort(key=lambda x:int(x[0].get('row') or 99))
            self.loaded.emit(out,api.calls)
        except Exception as e:self.failed.emit(str(e))


def _dim_unavailable_calendar_dates(calendar, minimum_qdate, maximum_qdate):
    disabled = QColor('#46566B')

    def refresh(year=None, month=None):
        year = int(year or calendar.yearShown())
        month = int(month or calendar.monthShown())
        first = QDate(year, month, 1)
        if not first.isValid():
            return
        d = first.addDays(-14)
        end = first.addMonths(1).addDays(14)
        while d <= end:
            fmt = QTextCharFormat()
            if (d < minimum_qdate or d > maximum_qdate
                    or d.year() != year or d.month() != month):
                fmt.setForeground(disabled)
            calendar.setDateTextFormat(d, fmt)
            d = d.addDays(1)

    calendar.currentPageChanged.connect(refresh)
    refresh(calendar.yearShown(), calendar.monthShown())





def _yesterday_kst_qdate():
    now_kst = datetime.now(timezone(timedelta(hours=9)))
    d = now_kst.date() - timedelta(days=1)
    return QDate(d.year, d.month, d.day)

class DatePicker(PopupDatePicker):
    """Union search date picker backed by the shared custom calendar."""
    def __init__(self, value=''):
        super().__init__(
            value=value, minimum_qdate=QDate(2023, 1, 1),
            maximum_qdate=_yesterday_kst_qdate(),
            icon_path=BASE_DIR/'calendar_picker.png'
        )


class TitleBar(QFrame):
    def __init__(self,window):
        super().__init__(); self.window=window; self.drag_pos=None
        self.setObjectName('titlebar'); self.setFixedHeight(60)
        lay=QHBoxLayout(self); lay.setContentsMargins(18,0,12,0); lay.setSpacing(9)

        icon=QLabel()
        pm=QPixmap(str(BASE_DIR/'app_icon.png'))
        if not pm.isNull():
            icon.setPixmap(pm.scaled(34,34,Qt.AspectRatioMode.KeepAspectRatio,Qt.TransformationMode.SmoothTransformation))
        else:
            icon.setText('✦')
        icon.setFixedSize(38,38); icon.setAlignment(Qt.AlignmentFlag.AlignCenter)
        lay.addWidget(icon)

        brand=QVBoxLayout(); brand.setSpacing(0)
        row=QHBoxLayout(); row.setSpacing(10)
        title=QLabel('메이플 유니온챔피언 검색기'); title.setObjectName('brandTitle'); row.addWidget(title)
        ver=QLabel('v2.1.19'); ver.setObjectName('version'); row.addWidget(ver); row.addStretch()
        brand.addLayout(row)
        sub=QLabel('M A P L E   U N I O N   C H A M P I O N   F I N D E R'); sub.setObjectName('brandSub'); brand.addWidget(sub)
        lay.addLayout(brand); lay.addStretch()

        self.nav={}
        for key,txt in [('home','⌕  검색 조건'),('history','◷  검색 기록'),('logs','▣  진행 로그'),('settings','⚙  설정'),('help','?  도움말')]:
            b=QPushButton(txt); b.setObjectName('navButton'); b.setCheckable(True)
            b.setCursor(Qt.CursorShape.PointingHandCursor)
            b.clicked.connect(lambda _,k=key:window.show_page(k))
            lay.addWidget(b); self.nav[key]=b

        sep=QFrame(); sep.setFrameShape(QFrame.Shape.VLine); sep.setObjectName('navSep'); sep.setFixedHeight(24); lay.addWidget(sep)
        for text,slot,obj in [('—',window.showMinimized,'windowButton'),('□',window.toggle_maximize,'windowButton'),('×',window.close,'closeButton')]:
            b=QPushButton(text); b.setObjectName(obj); b.setFixedSize(42,38); b.clicked.connect(slot); lay.addWidget(b)

    def mousePressEvent(self,e):
        if e.button()==Qt.MouseButton.LeftButton:
            self.drag_pos=e.globalPosition().toPoint()-self.window.frameGeometry().topLeft()
    def mouseMoveEvent(self,e):
        if self.drag_pos is not None and e.buttons() & Qt.MouseButton.LeftButton and not self.window.isMaximized():
            self.window.move(e.globalPosition().toPoint()-self.drag_pos)
    def mouseReleaseEvent(self,e): self.drag_pos=None
    def mouseDoubleClickEvent(self,e):
        if e.button()==Qt.MouseButton.LeftButton:self.window.toggle_maximize()


class ConditionCard(QFrame):
    changed=Signal()
    def __init__(self,index):
        super().__init__(); self.index=index; self.setObjectName('conditionCard')
        v=QVBoxLayout(self); v.setContentsMargins(12,9,12,11); v.setSpacing(8)

        head=QHBoxLayout()
        head.setContentsMargins(0,0,0,0)
        head.setSpacing(6)
        no=QLabel(f"#{index:02d}"); no.setObjectName('slotNo'); head.addWidget(no); head.addStretch()
        self.clear_btn=QPushButton('×')
        self.clear_btn.setObjectName('slotClearButton')
        self.clear_btn.setFixedSize(26,26)
        self.clear_btn.setToolTip(f'#{index:02d} 입력값 초기화')
        self.clear_btn.clicked.connect(self.clear)
        head.addWidget(self.clear_btn)
        v.addLayout(head)

        grid=QGridLayout(); grid.setContentsMargins(0,0,0,0); grid.setHorizontalSpacing(7); grid.setVerticalSpacing(8)
        l1=QLabel('레벨'); l1.setObjectName('fieldLabel'); grid.addWidget(l1,0,0)
        self.level=QLineEdit()
        self.level.setObjectName('cardLevelEdit')
        self.level.setPlaceholderText('입력')
        self.level.setValidator(QIntValidator(1,400,self.level))
        self.level.setAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter)
        grid.addWidget(self.level,0,1)
        l2=QLabel('직업'); l2.setObjectName('fieldLabel'); grid.addWidget(l2,1,0)
        self.job=QComboBox(); self.job.setObjectName('cardCombo'); self.job.addItem('직업 선택'); self.job.addItems(engine.CLASSES); grid.addWidget(self.job,1,1)
        v.addLayout(grid)

        self.level.textChanged.connect(self._changed); self.job.currentIndexChanged.connect(self._changed)

    def _changed(self): self.changed.emit()
    def clear(self):
        # Reset only this card. Block child signals so the parent refresh runs once.
        self.level.blockSignals(True)
        self.job.blockSignals(True)
        try:
            self.level.clear()
            self.job.setCurrentIndex(0)
        finally:
            self.level.blockSignals(False)
            self.job.blockSignals(False)
        self.changed.emit()
    def level_value(self):
        text=self.level.text().strip()
        return int(text) if text.isdigit() else 0
    def value(self):
        level=self.level_value()
        if level<=0 or self.job.currentIndex()<=0:return None
        return {'level':level,'class':engine.canonical_job(self.job.currentText()),'row':self.index}
    def set_main(self,on):
        self.setProperty('main',on); self.style().unpolish(self); self.style().polish(self)


class SidebarArt(QLabel):
    def __init__(self):
        super().__init__()
        self.src = QPixmap(str(BASE_DIR/'sidebar_art.png'))
        self.setFixedWidth(312)
        self.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Expanding)
        self.setStyleSheet('background:#07162A;')
        self._sync_banner_size()

    def _sync_banner_size(self):
        if self.src.isNull() or self.height() <= 0:
            return
        fitted = self.src.scaledToHeight(max(1, self.height()), Qt.TransformationMode.SmoothTransformation)
        target_w = max(312, int(round(self.height() * 683 / 1536)))
        if self.width() != target_w:
            self.setFixedWidth(target_w)
        self.setPixmap(fitted)

    def showEvent(self, e):
        super().showEvent(e)
        QTimer.singleShot(0, self._sync_banner_size)

    def resizeEvent(self, e):
        super().resizeEvent(e)
        self._sync_banner_size()


class ImageManager(QObject):
    _instance = None

    def __init__(self):
        super().__init__()
        self.net = QNetworkAccessManager(self)
        self.cache = {}
        self.waiters = {}

    @classmethod
    def instance(cls):
        if cls._instance is None:
            cls._instance = ImageManager()
        return cls._instance

    def request(self, url, label, size):
        if not url:
            label.show_placeholder()
            return
        label._current_url = url
        if url in self.cache:
            label.apply_pixmap(self.cache[url], size)
            return
        self.waiters.setdefault(url, []).append((label, size))
        if len(self.waiters[url]) > 1:
            return
        req = QNetworkRequest(QUrl(url))
        req.setRawHeader(b"User-Agent", b"MapleUnionChampionFinder/2.0.6")
        reply = self.net.get(req)
        reply.setProperty("image_url", url)
        reply.finished.connect(lambda r=reply: self._finished(r))

    def _finished(self, reply):
        url = reply.property("image_url")
        pix = None
        if reply.error() == reply.NetworkError.NoError:
            data = bytes(reply.readAll())
            if data:
                pm = QPixmap()
                if pm.loadFromData(data):
                    pix = pm
                    self.cache[url] = pm
        for label, size in self.waiters.pop(url, []):
            if getattr(label, "_current_url", "") != url:
                continue
            if pix is None:
                label.show_placeholder()
            else:
                label.apply_pixmap(pix, size)
        reply.deleteLater()


class CharacterImageLabel(QLabel):
    def __init__(self, size=48):
        super().__init__()
        self._size = size
        self._current_url = ""
        self.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.setFixedSize(size, size)
        self.show_placeholder()

    def show_placeholder(self):
        radius = max(6, self._size // 6)
        self.setText("")
        self.setPixmap(QPixmap())
        self.setStyleSheet(
            f"background:#0A1B2E;border:1px solid #274C73;border-radius:{radius}px;"
        )

    def _tight_crop(self, pix):
        # QPixmap.mask().boundingRect()는 bitmap 자체의 전체 영역을 반환할 수 있습니다.
        # QRegion(mask)의 실제 불투명 픽셀 영역을 이용해 투명 여백을 정확히 잘라냅니다.
        try:
            mask = pix.mask()
            if not mask.isNull():
                region = QRegion(mask)
                rect = region.boundingRect()
                if rect.isValid() and rect.width() > 4 and rect.height() > 4:
                    pad = max(2, int(max(rect.width(), rect.height()) * 0.025))
                    rect = rect.adjusted(-pad, -pad, pad, pad).intersected(pix.rect())
                    if rect.isValid():
                        return pix.copy(rect)
        except Exception:
            pass
        return pix

    def apply_pixmap(self, pix, size=None):
        size = size or self._size
        self._size = size
        radius = max(6, size // 6)
        self.setFixedSize(size, size)
        self.setStyleSheet(
            f"background:#08182B;border:1px solid #274C73;border-radius:{radius}px;"
        )
        tight = self._tight_crop(pix)
        self.setPixmap(
            tight.scaled(
                size - 4, size - 4,
                Qt.AspectRatioMode.KeepAspectRatio,
                Qt.TransformationMode.SmoothTransformation
            )
        )

    def set_remote(self, url, size=None):
        size = size or self._size
        self._size = size
        self.setFixedSize(size, size)
        ImageManager.instance().request(url or "", self, size)


class ResultTable(QTableWidget):
    rowActivated = Signal(object)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.results = []

        headers = ['순번', '대표 캐릭터', '유니온 캐릭터', '마지막 갱신']
        self.setColumnCount(len(headers))
        self.setHorizontalHeaderLabels(headers)
        self.setRowCount(0)

        self.verticalHeader().setVisible(False)
        self.setShowGrid(False)
        self.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.setVerticalScrollMode(QAbstractItemView.ScrollMode.ScrollPerPixel)

        h = self.horizontalHeader()
        h.setSectionResizeMode(0, QHeaderView.ResizeMode.Fixed)
        h.setSectionResizeMode(1, QHeaderView.ResizeMode.Fixed)
        h.setSectionResizeMode(2, QHeaderView.ResizeMode.Stretch)
        h.setSectionResizeMode(3, QHeaderView.ResizeMode.Fixed)

        self.setColumnWidth(0, 52)
        self.setColumnWidth(1, 270)
        self.setColumnWidth(3, 135)

        self.cellDoubleClicked.connect(self._dbl)

    def _dbl(self, row, col):
        if 0 <= row < len(self.results):
            self.rowActivated.emit(self.results[row])

    def clear_results(self):
        self.setRowCount(0)
        self.results = []

    def _representative(self, r):
        matches = [
            x for x in r.get('matched_chars', [])
            if x.get('name')
        ]

        if matches:
            rep = max(
                matches,
                key=lambda x: (
                    int(x.get('search_level') or 0),
                    -int(x.get('row') or 999)
                )
            )
            out = {
                'name': rep.get('name') or '-',
                'level': int(rep.get('search_level') or 0),
                'class': rep.get('search_class') or rep.get('requested_class') or '',
                'world': rep.get('search_world') or '',
                'image': rep.get('image') or '',
            }

            # 대표 캐릭터가 본캐 후보와 같다면 랭킹 후보에서 보완한 이미지/월드 정보 활용
            cand = r.get('candidate') or {}
            if out['name'] == cand.get('name'):
                out['image'] = out['image'] or cand.get('image') or ''
                out['world'] = out['world'] or cand.get('world') or ''
                out['class'] = out['class'] or cand.get('class') or ''
                out['level'] = out['level'] or int(cand.get('level') or 0)

            return out

        return dict(r.get('candidate') or {})

    def _representative_widget(self, c):
        box = QWidget()
        lay = QHBoxLayout(box)
        lay.setContentsMargins(7, 5, 4, 5)
        lay.setSpacing(12)

        # 기존보다 훨씬 큰 대표 캐릭터 이미지
        av = CharacterImageLabel(110)
        av.set_remote(c.get('image') or '', 110)
        lay.addWidget(av)

        tx = QVBoxLayout()
        tx.setSpacing(2)
        tx.setContentsMargins(0, 8, 0, 8)

        nm = QLabel(c.get('name', '-'))
        nm.setObjectName('resultName')
        tx.addWidget(nm)

        lv = QLabel(f"Lv. {c.get('level',0)}")
        lv.setObjectName('representativeLevel')
        tx.addWidget(lv)

        cls = QLabel(c.get('class', ''))
        cls.setObjectName('representativeClass')
        tx.addWidget(cls)

        world = QLabel(c.get('world', ''))
        world.setObjectName('resultMeta')
        tx.addWidget(world)

        tx.addStretch(1)
        lay.addLayout(tx, 1)
        return box

    def _union_widget(self, r, representative):
        wrap = QWidget()
        lay = QHBoxLayout(wrap)
        lay.setContentsMargins(5, 6, 5, 6)
        lay.setSpacing(7)
        lay.setAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter)

        # 대표 캐릭터는 좌측 칸에 이미 있으므로 중복 표시하지 않습니다.
        chars = [
            x for x in r.get('matched_chars', [])
            if x.get('name') and x.get('name') != representative.get('name')
        ]
        chars.sort(
            key=lambda x: (
                -int(x.get('search_level') or 0),
                int(x.get('row') or 999)
            )
        )

        # 입력 조건 최대 6개 - 대표 캐릭터 1개 = 최대 5개
        for x in chars[:5]:
            mini = QFrame()
            mini.setObjectName('comboMini')
            mini.setFixedSize(138, 112)

            ml = QHBoxLayout(mini)
            ml.setContentsMargins(5, 5, 6, 5)
            ml.setSpacing(6)

            # 부캐도 실제 캐릭터가 확실히 보이도록 크게 표시
            img = CharacterImageLabel(68)
            img.set_remote(x.get('image') or '', 68)
            ml.addWidget(img)

            tx = QVBoxLayout()
            tx.setSpacing(0)
            tx.setContentsMargins(0, 5, 0, 5)

            lv = QLabel(f"Lv.{x.get('search_level',0)}")
            lv.setObjectName('comboLevel')
            tx.addWidget(lv)

            nm = QLabel(x.get('name', ''))
            nm.setObjectName('comboName')
            nm.setMaximumWidth(52)
            nm.setToolTip(x.get('name', ''))
            tx.addWidget(nm)

            job = QLabel(
                x.get('search_class')
                or x.get('requested_class')
                or ''
            )
            job.setObjectName('comboClass')
            job.setMaximumWidth(52)
            job.setToolTip(job.text())
            tx.addWidget(job)

            tx.addStretch(1)
            ml.addLayout(tx, 1)
            lay.addWidget(mini, 0)

        # 캐릭터 수가 적다고 카드를 늘리지 않고 남는 공간은 그대로 둡니다.
        lay.addStretch(1)
        return wrap

    def add_result(self, r, rank=None):
        row = self.rowCount()
        self.insertRow(row)
        self.setRowHeight(row, 138)
        self.results.append(r)

        # 순위가 아니라 단순 순번
        seq = rank or row + 1
        item = QTableWidgetItem(str(seq))
        item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
        self.setItem(row, 0, item)

        representative = self._representative(r)
        self.setCellWidget(
            row, 1,
            self._representative_widget(representative)
        )
        self.setCellWidget(
            row, 2,
            self._union_widget(r, representative)
        )

        ts = (
            r.get('_display_time')
            or datetime.now().strftime('%Y-%m-%d\n%H:%M')
        )
        last = QTableWidgetItem(ts)
        last.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
        self.setItem(row, 3, last)


class DetailHeader(QFrame):
    def __init__(self, dialog):
        super().__init__()
        self.dialog = dialog
        self.drag_pos = None
        self.setObjectName("detailHeader")
        self.setFixedHeight(54)

        lay = QHBoxLayout(self)
        lay.setContentsMargins(16,0,10,0)
        lay.setSpacing(8)

        leaf = QLabel("✦")
        leaf.setObjectName("detailHeaderLeaf")
        lay.addWidget(leaf)

        title = QLabel("MAPLE UNION CHAMPION FINDER")
        title.setObjectName("detailHeaderBrand")
        lay.addWidget(title)
        lay.addStretch()

        slogan = QLabel("MORE THAN A GAME · MAPLESTORY")
        slogan.setObjectName("detailHeaderSlogan")
        lay.addWidget(slogan)

        close = QPushButton("×")
        close.setObjectName("detailCloseButton")
        close.setFixedSize(42,36)
        close.clicked.connect(dialog.close)
        lay.addWidget(close)

    def mousePressEvent(self, e):
        if e.button() == Qt.MouseButton.LeftButton:
            self.drag_pos = (
                e.globalPosition().toPoint()
                - self.dialog.frameGeometry().topLeft()
            )

    def mouseMoveEvent(self, e):
        if (
            self.drag_pos is not None
            and e.buttons() & Qt.MouseButton.LeftButton
        ):
            self.dialog.move(
                e.globalPosition().toPoint() - self.drag_pos
            )

    def mouseReleaseEvent(self, e):
        self.drag_pos = None



def _weaponless_anchor_transform(anchor_pix, canvas_w=300, canvas_h=205):
    """W04(무기 제외) 이미지를 기준으로 본체의 크기와 착지 위치를 계산합니다."""
    if anchor_pix.isNull():
        return 1.0, canvas_w / 2.0, canvas_h - 32, 150.0, 200.0

    source_anchor_x = anchor_pix.width() * 0.5
    source_anchor_y = anchor_pix.height() * (200.0 / 300.0)

    # W04 이미지의 실제 본체 높이를 참고하여 캐릭터 크기를 보정합니다.
    body_height = anchor_pix.height() * 0.50
    try:
        mask = anchor_pix.mask()
        if not mask.isNull():
            rect = QRegion(mask).boundingRect()
            if rect.isValid() and rect.height() > 12:
                body_height = float(rect.height())
    except Exception:
        pass

    # 이전 버전보다 다시 크게. 너무 큰 특수 외형은 상한으로 제한합니다.
    target_body_height = 170.0
    scale = target_body_height / max(1.0, body_height)
    scale = max(0.78, min(1.28, scale))

    target_anchor_x = canvas_w / 2.0

    # 배경의 발판 가장자리보다 중앙 문양 쪽에 서 보이도록 위쪽으로 이동.
    target_anchor_y = canvas_h - 42

    return (
        scale,
        target_anchor_x,
        target_anchor_y,
        source_anchor_x,
        source_anchor_y,
    )


def _compose_detail_pixmap(anchor_pix, display_pix, canvas_w=300, canvas_h=205):
    """무기 제외 이미지로 위치를 잡고, 무기 포함 이미지를 같은 변환으로 표시합니다."""
    if display_pix.isNull():
        display_pix = anchor_pix
    if display_pix.isNull():
        return display_pix

    (
        scale,
        target_x,
        target_y,
        source_x,
        source_y,
    ) = _weaponless_anchor_transform(
        anchor_pix if not anchor_pix.isNull() else display_pix,
        canvas_w,
        canvas_h,
    )

    scaled_w = max(1, int(round(display_pix.width() * scale)))
    scaled_h = max(1, int(round(display_pix.height() * scale)))
    scaled = display_pix.scaled(
        scaled_w,
        scaled_h,
        Qt.AspectRatioMode.IgnoreAspectRatio,
        Qt.TransformationMode.SmoothTransformation,
    )

    canvas = QPixmap(canvas_w, canvas_h)
    canvas.fill(Qt.GlobalColor.transparent)

    draw_x = int(round(target_x - source_x * scale))
    draw_y = int(round(target_y - source_y * scale))

    painter = QPainter(canvas)
    painter.setRenderHint(
        QPainter.RenderHint.SmoothPixmapTransform,
        True,
    )
    painter.drawPixmap(draw_x, draw_y, scaled)
    painter.end()
    return canvas


class DetailCard(QFrame):
    CARD_W = 402
    CARD_H = 294

    def __init__(self, req, info, anchor_data, display_data):
        super().__init__()
        self.setObjectName('detailCharacterCard')
        self.setFixedSize(self.CARD_W, self.CARD_H)
        self.bg = QPixmap(str(BASE_DIR / 'detail_card_bg.png'))

        stage_w = self.CARD_W - 26
        stage_h = 246

        root = QVBoxLayout(self)
        root.setContentsMargins(13, 10, 13, 10)
        root.setSpacing(0)

        visual = QFrame()
        visual.setObjectName('detailVisual')
        visual.setFixedHeight(stage_h)
        visual.setStyleSheet("QFrame#detailVisual{background:transparent;border:none;}")

        stage_bg = QLabel(visual)
        stage_bg.setObjectName('detailStageBg')
        stage_bg.setGeometry(0, 0, stage_w, stage_h)
        stage_bg.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents, True)
        stage_pm = QPixmap(str(BASE_DIR / 'detail_stage_bg.png'))
        if not stage_pm.isNull():
            stage_bg.setPixmap(
                stage_pm.scaled(
                    stage_bg.size(),
                    Qt.AspectRatioMode.KeepAspectRatioByExpanding,
                    Qt.TransformationMode.SmoothTransformation
                )
            )
            stage_bg.show()
        else:
            stage_bg.hide()

        overlay = QLabel(visual)
        overlay.setObjectName('detailStageOverlay')
        overlay.setGeometry(0, 0, stage_w, stage_h)
        overlay.setStyleSheet(
            "background:qlineargradient(x1:0, y1:0, x2:0, y2:1, "
            "stop:0 rgba(6,14,42,44), stop:0.32 rgba(8,18,50,10), "
            "stop:0.80 rgba(4,10,30,0), stop:1 rgba(4,10,28,0));"
            "border:none;"
        )
        overlay.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents, True)

        badge = QLabel(f"후보 {req.get('row','-')}", visual)
        badge.setObjectName('detailConditionBadge')
        badge.setFixedSize(70, 26)
        badge.setAlignment(Qt.AlignmentFlag.AlignCenter)
        badge.move(14, 13)

        # 후보 뱃지 오른쪽부터 카드 끝까지 한 줄 정보 바를 사용합니다.
        # 직업/레벨/닉네임이 한 줄에 들어가므로 긴 직업명과 6글자 닉네임도
        # 기존 작은 2단 박스보다 훨씬 안정적으로 표시됩니다.
        info_box = QFrame(visual)
        info_box.setObjectName('detailInfoBox')
        info_x = 92
        info_w = stage_w - info_x - 14
        info_box.setGeometry(info_x, 12, info_w, 30)
        info_box.setStyleSheet(
            "QFrame#detailInfoBox{background:rgba(6,18,48,150);"
            "border:1px solid rgba(190,220,255,54); border-radius:7px;}"
        )

        ib = QHBoxLayout(info_box)
        ib.setContentsMargins(10, 0, 10, 0)
        ib.setSpacing(0)

        job_text = (info.get('class') or '-').strip()
        level_text = f"Lv.{info.get('level',0)}"
        name_text = (info.get('name') or req.get('name','-')).strip()
        summary_text = f"{job_text}  ·  {level_text}  ·  {name_text}"

        summary = QLabel(summary_text)
        summary.setObjectName('detailCardSummary')
        summary.setAlignment(
            Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter
        )
        summary.setWordWrap(False)
        # 긴 직업명/닉네임 조합은 한 줄을 유지한 채 폰트만 소폭 줄입니다.
        for pt in (11, 10, 9):
            f = QFont('Malgun Gothic', pt)
            f.setBold(True)
            summary.setFont(f)
            if QFontMetrics(f).horizontalAdvance(summary_text) <= info_w - 20:
                break
        summary.setStyleSheet('color:#F1F5FF; background:transparent;')
        ib.addWidget(summary, 1)

        pic = QLabel(visual)
        pic.setFixedSize(300, 205)
        pic.setAlignment(Qt.AlignmentFlag.AlignHCenter | Qt.AlignmentFlag.AlignBottom)
        pic.setObjectName('detailCharacterImage')
        pic.move((stage_w - pic.width()) // 2, 35)
        info_box.raise_()
        badge.raise_()

        anchor_pm = QPixmap()
        display_pm = QPixmap()

        if anchor_data:
            anchor_pm.loadFromData(anchor_data)
        if display_data:
            display_pm.loadFromData(display_data)

        if not anchor_pm.isNull() or not display_pm.isNull():
            pic.setPixmap(
                _compose_detail_pixmap(
                    anchor_pm,
                    display_pm,
                    300,
                    205,
                )
            )
        else:
            pic.setText('이미지 없음')
            pic.setObjectName('detailImageMissing')

        root.addWidget(visual)

    def paintEvent(self, e):
        p = QPainter(self)
        if not self.bg.isNull():
            scaled = self.bg.scaled(
                self.size(),
                Qt.AspectRatioMode.KeepAspectRatioByExpanding,
                Qt.TransformationMode.SmoothTransformation
            )
            x = max(0, (scaled.width() - self.width()) // 2)
            y = max(0, (scaled.height() - self.height()) // 2)
            src = QRect(x, y, self.width(), self.height())
            p.drawPixmap(self.rect(), scaled, src)
        else:
            p.fillRect(self.rect(), QColor('#07152f'))
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        pen = QPen(QColor(118, 154, 255, 210), 1)
        p.setPen(pen)
        p.drawRoundedRect(self.rect().adjusted(0, 0, -1, -1), 12, 12)


class DetailHeader(QFrame):
    def __init__(self, dialog):
        super().__init__()
        self.dialog = dialog
        self.drag_pos = None
        self.setObjectName('detailHeader')
        self.setFixedHeight(52)

        lay = QHBoxLayout(self)
        lay.setContentsMargins(16, 0, 10, 0)
        lay.setSpacing(8)

        leaf = QLabel('✦')
        leaf.setObjectName('detailHeaderLeaf')
        lay.addWidget(leaf)

        title = QLabel('MAPLE UNION CHAMPION FINDER')
        title.setObjectName('detailHeaderBrand')
        lay.addWidget(title)
        lay.addStretch()

        slogan = QLabel('MORE THAN A GAME · MAPLESTORY')
        slogan.setObjectName('detailHeaderSlogan')
        lay.addWidget(slogan)

        close = QPushButton('×')
        close.setObjectName('detailCloseButton')
        close.setFixedSize(42, 36)
        close.clicked.connect(dialog.close)
        lay.addWidget(close)

    def mousePressEvent(self, e):
        if e.button() == Qt.MouseButton.LeftButton:
            self.drag_pos = (
                e.globalPosition().toPoint()
                - self.dialog.frameGeometry().topLeft()
            )

    def mouseMoveEvent(self, e):
        if (
            self.drag_pos is not None
            and e.buttons() & Qt.MouseButton.LeftButton
        ):
            self.dialog.move(
                e.globalPosition().toPoint() - self.drag_pos
            )

    def mouseReleaseEvent(self, e):
        self.drag_pos = None


class DetailDialog(QDialog):
    def __init__(self, app, result):
        super().__init__(app)
        self.app = app
        self.result = result
        self.worker = None

        self.setWindowFlags(
            Qt.WindowType.FramelessWindowHint
            | Qt.WindowType.Dialog
        )
        self.setObjectName('detailDialog')

        self.items = [
            x for x in result.get('matched_chars', [])
            if x.get('name')
        ][:6]

        # 카드 크기는 개수와 무관하게 항상 동일합니다.
        # 1~3개: 1행 / 4~6개: 2행
        rows = 1 if len(self.items) <= 3 else 2
        self.setFixedSize(1276, 505 if rows == 1 else 825)

        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        self.header = DetailHeader(self)
        root.addWidget(self.header)

        content = QFrame()
        content.setObjectName('detailContent')
        cl = QVBoxLayout(content)
        cl.setContentsMargins(22, 13, 22, 13)
        cl.setSpacing(9)
        root.addWidget(content, 1)

        hero = QHBoxLayout()
        left = QVBoxLayout()
        left.setSpacing(1)

        title = QLabel('✦  캐릭터 상세')
        title.setObjectName('detailHeroTitle')
        left.addWidget(title)

        c = result['candidate']
        sub = QLabel(
            f"유니온 챔피언 후보  ·  {c.get('name','-')}"
            f"  ·  일치 {result['score']}/{result['total']}"
        )
        sub.setObjectName('detailHeroSub')
        left.addWidget(sub)
        hero.addLayout(left)
        hero.addStretch()

        world_name = (c.get('world') or '').strip()
        if world_name:
            world_badge = QLabel(f'서버  ·  {world_name}')
            world_badge.setObjectName('detailGlobalWorld')
            world_badge.setStyleSheet(
                'background:rgba(51,76,145,0.46);'
                'border:1px solid rgba(121,158,255,0.60);'
                'border-radius:7px; padding:4px 10px;'
                'color:#dbe9ff; font-size:11px; font-weight:800;'
            )
            world_badge.setFixedHeight(34)
            hero.addWidget(
                world_badge,
                0,
                Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter
            )
            hero.addSpacing(8)

        scouter_btn = QPushButton('MapleScouter 열기')
        scouter_btn.setObjectName('detailActionButton')
        scouter_btn.setFixedSize(148, 34)
        representative_name = (c.get('name') or '').strip()
        scouter_btn.setEnabled(bool(representative_name))
        scouter_btn.clicked.connect(
            lambda checked=False, name=representative_name: webbrowser.open(
                f'https://maplescouter.com/ko/info?name={urllib.parse.quote(name)}'
            ) if name else None
        )
        hero.addWidget(
            scouter_btn,
            0,
            Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter
        )

        cl.addLayout(hero)

        # 스크롤 영역을 사용하지 않습니다.
        # 카드 컨테이너 자체가 최대 3×2를 고정 크기로 수용합니다.
        self.cards_host = QWidget()
        self.cards_host.setObjectName('detailCardsHost')
        self.cards_layout = QVBoxLayout(self.cards_host)
        self.cards_layout.setContentsMargins(0, 0, 0, 0)
        self.cards_layout.setSpacing(14)
        cl.addWidget(self.cards_host, 1)

        footer = QFrame()
        footer.setObjectName('detailFooter')
        fl = QHBoxLayout(footer)
        fl.setContentsMargins(12, 6, 10, 6)
        fl.setSpacing(8)

        self.footer_status = QLabel('●  현재 정보 조회 중...')
        self.footer_status.setObjectName('detailFooterStatus')
        fl.addWidget(self.footer_status)
        fl.addStretch()

        self.refresh_btn = QPushButton('↻  새로고침')
        self.refresh_btn.setObjectName('detailActionButton')
        self.refresh_btn.setFixedSize(98, 30)
        self.refresh_btn.clicked.connect(self.reload)
        fl.addWidget(self.refresh_btn, 0, Qt.AlignmentFlag.AlignVCenter)

        close = QPushButton('×  닫기')
        close.setObjectName('detailActionButton')
        close.setFixedSize(76, 30)
        close.clicked.connect(self.close)
        fl.addWidget(close, 0, Qt.AlignmentFlag.AlignVCenter)
        cl.addWidget(footer)

        self._show_loading()
        self.reload()

    def _clear_cards(self):
        while self.cards_layout.count():
            item = self.cards_layout.takeAt(0)
            widget = item.widget()
            layout = item.layout()
            if widget:
                widget.deleteLater()
            elif layout:
                while layout.count():
                    child = layout.takeAt(0)
                    if child.widget():
                        child.widget().deleteLater()

    def _show_loading(self):
        self._clear_cards()
        row = QHBoxLayout()
        row.addStretch()
        label = QLabel('캐릭터들의 현재 정보를 불러오는 중입니다...')
        label.setObjectName('detailLoading')
        label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        label.setFixedSize(520, 180)
        row.addWidget(label)
        row.addStretch()
        self.cards_layout.addStretch()
        self.cards_layout.addLayout(row)
        self.cards_layout.addStretch()

    def reload(self):
        if self.worker and self.worker.isRunning():
            return
        self.refresh_btn.setEnabled(False)
        self._show_loading()

        self.worker = DetailThread(
            self.app.api_key(),
            self.items,
            self
        )
        self.worker.loaded.connect(self.render)
        self.worker.failed.connect(self.error)
        self.worker.start()

    def error(self, msg):
        self.refresh_btn.setEnabled(True)
        self._clear_cards()
        lab = QLabel('상세 조회 중 오류가 발생했습니다.\n' + msg)
        lab.setAlignment(Qt.AlignmentFlag.AlignCenter)
        lab.setObjectName('dangerText')
        self.cards_layout.addStretch()
        self.cards_layout.addWidget(lab)
        self.cards_layout.addStretch()
        self.footer_status.setText('●  상세 조회 실패')

    def render(self, data, calls):
        self.refresh_btn.setEnabled(True)
        try:
            self._clear_cards()

            # 한 줄에 최대 3개. 카드가 1~2개만 있어도 가운데로 몰지 않고
            # 항상 왼쪽부터 순서대로 배치합니다.
            for row_start in range(0, len(data), 3):
                row_layout = QHBoxLayout()
                row_layout.setSpacing(12)
                row_layout.setContentsMargins(0, 0, 0, 0)

                for req, info, anchor_data, display_data in data[row_start:row_start + 3]:
                    card = DetailCard(
                        req,
                        info,
                        anchor_data,
                        display_data,
                    )
                    row_layout.addWidget(
                        card, 0, Qt.AlignmentFlag.AlignLeft
                    )

                row_layout.addStretch(1)
                self.cards_layout.addLayout(row_layout)

            self.footer_status.setText(
                f"●  현재 정보 조회 완료  ·  {len(data)}명  ·  API {calls}회"
            )
        except Exception as e:
            self.error(f"상세 화면 렌더링 오류: {e}")

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowFlags(Qt.WindowType.FramelessWindowHint|Qt.WindowType.Window)
        self.resize(1536,930); self.setMinimumSize(1366,780)
        self.results=[]; self.history=[]; self.search_thread=None

        self._build(); self._style(); self.show_page('home'); self.refresh_main_marker(); self.status('검색을 시작할 수 있습니다.')

    def _build(self):
        central=QWidget(); central.setObjectName('root'); self.setCentralWidget(central)
        outer=QVBoxLayout(central); outer.setContentsMargins(0,0,0,0); outer.setSpacing(0)

        self.titlebar=TitleBar(self); outer.addWidget(self.titlebar)

        body=QHBoxLayout(); body.setContentsMargins(0,0,0,0); body.setSpacing(0); outer.addLayout(body,1)
        self.sidebar=SidebarArt(); body.addWidget(self.sidebar)

        right=QWidget(); right.setObjectName('mainArea')
        rl=QVBoxLayout(right); rl.setContentsMargins(16,8,16,0); rl.setSpacing(8)
        body.addWidget(right,1)

        self.stack=QStackedWidget(); rl.addWidget(self.stack,1)
        self.pages={}
        for key in ['home','history','logs','settings','help']:
            w=QWidget(); self.pages[key]=w; self.stack.addWidget(w)

        self._build_home(); self._build_history(); self._build_logs(); self._build_settings(); self._build_help()

        self.footer=QFrame(); self.footer.setObjectName('footer')
        fl=QHBoxLayout(self.footer); fl.setContentsMargins(8,0,8,0)
        self.status_dot=QLabel('●'); self.status_dot.setObjectName('statusDot'); fl.addWidget(self.status_dot)
        self.status_label=QLabel(); self.status_label.setObjectName('statusLabel'); fl.addWidget(self.status_label)
        fl.addStretch()
        self.footer_meta=QLabel('데이터 출처: NEXON Open API'); self.footer_meta.setObjectName('footerMeta'); fl.addWidget(self.footer_meta)
        rl.addWidget(self.footer)

    def _build_home(self):
        p=self.pages['home']; lay=QVBoxLayout(p); lay.setContentsMargins(0,0,0,0); lay.setSpacing(8)

        # 장비검색기와 동일한 페이지 헤더 구조
        reset=QPushButton('↻  기본값으로 초기화')
        reset.setObjectName('ghostButton')
        reset.clicked.connect(self.reset_all)
        lay.addWidget(self._page_header('⌕  조합 검색','최대 6개의 캐릭터 조합으로 유니온 챔피언 후보를 검색합니다.',reset))

        # 1 검색 조건 설정
        settings=QFrame(); settings.setObjectName('sectionPanel')
        sg=QGridLayout(settings); sg.setContentsMargins(12,10,12,10); sg.setHorizontalSpacing(10); sg.setVerticalSpacing(8)
        badge=QLabel('1'); badge.setObjectName('sectionBadge'); badge.setFixedSize(34,30); badge.setAlignment(Qt.AlignmentFlag.AlignCenter); sg.addWidget(badge,0,0)
        title=QLabel('검색 조건 설정'); title.setObjectName('subSectionTitle'); sg.addWidget(title,0,1)
        hint=QLabel('검색할 월드와 기준일을 선택한 후, 캐릭터 정보를 입력하세요.'); hint.setObjectName('mutedText'); sg.addWidget(hint,0,2,1,8)

        sg.addWidget(QLabel('월드 유형'),1,0)
        self.world_type_combo=QComboBox()
        self.world_type_combo.addItems(['전체','일반','에오스·핼리오스'])
        self.world_type_combo.currentTextChanged.connect(self._sync_world_options)
        sg.addWidget(self.world_type_combo,1,1,1,2)

        sg.addWidget(QLabel('월드'),1,3)
        self.world_combo=QComboBox()
        sg.addWidget(self.world_combo,1,4,1,2)

        sg.addWidget(QLabel('기준일'),1,6)
        self.date_edit=DatePicker(_yesterday_kst_qdate().toString('yyyy-MM-dd'))
        sg.addWidget(self.date_edit,1,7,1,3)

        self._sync_world_options(self.world_type_combo.currentText())
        for c in (1,2,4,5,7,8,9): sg.setColumnStretch(c,1)
        settings.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Maximum)
        lay.addWidget(settings)

        # 2 캐릭터 조합
        chars=QFrame(); chars.setObjectName('sectionPanel')
        cv=QVBoxLayout(chars); cv.setContentsMargins(12,9,12,10); cv.setSpacing(8)
        ch=QHBoxLayout()
        badge2=QLabel('2'); badge2.setObjectName('sectionBadge'); badge2.setFixedSize(34,30); badge2.setAlignment(Qt.AlignmentFlag.AlignCenter); ch.addWidget(badge2)
        title2=QLabel('캐릭터 조합'); title2.setObjectName('subSectionTitle'); ch.addWidget(title2)
        hint2=QLabel('최대 6개의 캐릭터 레벨과 직업을 입력하세요. (정확히 일치하는 유저만 검색됩니다)'); hint2.setObjectName('mutedText'); ch.addWidget(hint2)
        ch.addStretch()
        self.condition_count=QLabel('0 / 6'); self.condition_count.setObjectName('conditionCount'); ch.addWidget(self.condition_count)
        cv.addLayout(ch)

        cards=QHBoxLayout(); cards.setSpacing(10); self.condition_cards=[]
        for i in range(1,7):
            c=ConditionCard(i); c.changed.connect(self.refresh_main_marker); cards.addWidget(c,1); self.condition_cards.append(c)
        cv.addLayout(cards)
        chars.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Maximum)
        lay.addWidget(chars)

        self.search_btn=QPushButton('⌕   검색 시작'); self.search_btn.setObjectName('searchButton'); self.search_btn.clicked.connect(self.start_search)
        lay.addWidget(self.search_btn)

        # 검색 결과 - 검색 영역에서 확보한 공간을 결과 영역에 사용
        result=QFrame(); result.setObjectName('bigPanel')
        result.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        rr=QVBoxLayout(result); rr.setContentsMargins(15,10,15,10); rr.setSpacing(7)
        hd=QHBoxLayout()
        t=QLabel('검색 결과'); t.setObjectName('sectionTitle'); hd.addWidget(t)
        self.count_badge=QLabel('0명'); self.count_badge.setObjectName('countBadge'); hd.addWidget(self.count_badge)
        expl=QLabel('입력한 조합과 매칭된 후보 목록입니다.'); expl.setObjectName('mutedText'); hd.addWidget(expl)
        hd.addStretch()
        self.sort_combo=QComboBox(); self.sort_combo.addItems(['일치 높은 순','레벨 높은 순']); self.sort_combo.currentIndexChanged.connect(self.rebuild_tables); hd.addWidget(self.sort_combo)
        csvb=QPushButton('↓  결과 내보내기 (CSV)'); csvb.setObjectName('ghostButton'); csvb.clicked.connect(self.export_csv); hd.addWidget(csvb)
        rr.addLayout(hd)

        self.home_table=ResultTable(); self.home_table.rowActivated.connect(self.open_detail); rr.addWidget(self.home_table,1)
        lay.addWidget(result,1)

    def _page_header(self, title, subtitle, right_widget=None):
        box=QFrame(); box.setObjectName('pageHeader')
        h=QHBoxLayout(box); h.setContentsMargins(0,0,0,0); h.setSpacing(10)
        t=QLabel(title); t.setObjectName('pageTitle'); h.addWidget(t)
        sub=QLabel(subtitle); sub.setObjectName('pageSub'); h.addWidget(sub)
        h.addStretch(1)
        if right_widget is not None:
            h.addWidget(right_widget)
        return box

    def _build_history(self):
        p=self.pages['history']; l=QVBoxLayout(p); l.setContentsMargins(6,4,6,10); l.setSpacing(8)
        l.addWidget(self._page_header('검색 기록','현재 실행 중 완료된 검색 기록을 확인합니다.'))
        card=QFrame(); card.setObjectName('sectionPanel')
        cv=QVBoxLayout(card); cv.setContentsMargins(10,10,10,10); cv.setSpacing(7)
        h=QHBoxLayout(); title=QLabel('검색 기록'); title.setObjectName('subSectionTitle'); h.addWidget(title); h.addStretch(1); cv.addLayout(h)
        self.history_table=QTableWidget(0,7)
        self.history_table.setHorizontalHeaderLabels(['시간','본캐 조건','조건 수','후보','완전 일치','일부 불일치','API 호출'])
        self.history_table.verticalHeader().setVisible(False)
        self.history_table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.history_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.history_table.setShowGrid(False)
        cv.addWidget(self.history_table,1); l.addWidget(card,1)

    def _build_logs(self):
        p=self.pages['logs']; l=QVBoxLayout(p); l.setContentsMargins(6,4,6,10); l.setSpacing(8)
        clear=QPushButton('로그 비우기'); clear.setObjectName('ghostButton'); clear.clicked.connect(lambda:self.log_box.clear())
        l.addWidget(self._page_header('진행 로그','검색 진행 상황과 API 상태를 실시간으로 확인합니다.',clear))
        card=QFrame(); card.setObjectName('sectionPanel')
        cv=QVBoxLayout(card); cv.setContentsMargins(10,10,10,10); cv.setSpacing(7)
        title=QLabel('실시간 진행 로그'); title.setObjectName('subSectionTitle'); cv.addWidget(title)
        self.log_box=QPlainTextEdit(); self.log_box.setReadOnly(True); self.log_box.setObjectName('logBox'); cv.addWidget(self.log_box,1)
        l.addWidget(card,1)

    def _build_settings(self):
        p=self.pages['settings']; l=QVBoxLayout(p); l.setContentsMargins(10,8,10,10); l.setSpacing(10)
        l.addWidget(self._page_header('설정','공통 NEXON Open API Key와 검색 옵션을 관리합니다.'))
        box=QFrame(); box.setObjectName('settingsCard')
        g=QGridLayout(box); g.setContentsMargins(20,18,20,18); g.setHorizontalSpacing(16); g.setVerticalSpacing(12)
        def lab(txt,r,c=0):
            x=QLabel(txt); x.setObjectName('settingLabel'); g.addWidget(x,r,c); return x
        lab('API 연결',0)
        self.api_state=QLabel(''); g.addWidget(self.api_state,0,1,1,4)
        lab('API Key',1)
        self.api_edit=QLineEdit(); self.api_edit.setEchoMode(QLineEdit.EchoMode.Password); self.api_edit.setPlaceholderText('NEXON Open API Key 입력')
        g.addWidget(self.api_edit,1,1,1,2)
        self.api_save_btn=QPushButton('저장'); self.api_save_btn.setObjectName('ghostButton'); self.api_save_btn.clicked.connect(self._save_shared_api_key); g.addWidget(self.api_save_btn,1,3)
        self.api_logout_btn=QPushButton('로그아웃'); self.api_logout_btn.setObjectName('ghostButton'); self.api_logout_btn.clicked.connect(self._logout_shared_api_key); g.addWidget(self.api_logout_btn,1,4)
        lab('동시 조회',2)
        self.worker_spin=QSpinBox(); self.worker_spin.setRange(1,48); self.worker_spin.setValue(20)
        self.worker_spin.setToolTip('안정성을 위해 실제 후보 검증은 최대 20개까지 병렬 처리됩니다.')
        g.addWidget(self.worker_spin,2,1)
        lab('최대 랭킹 페이지',2,2)
        self.page_spin=QSpinBox(); self.page_spin.setRange(1,5000); self.page_spin.setValue(800); self.page_spin.setSingleStep(50)
        g.addWidget(self.page_spin,2,3)
        self.perfect_check=QCheckBox('완전 일치 후보만 결과에 표시'); g.addWidget(self.perfect_check,3,1,1,3)
        lab('다음 실행 첫 화면',4)
        self.startup_combo=QComboBox(); self.startup_combo.addItem('MapleTools 홈','home'); self.startup_combo.addItem('장비 검색기','equipment'); self.startup_combo.addItem('유니온챔피언 검색기','union')
        self.startup_combo.setToolTip('프로그램을 다음에 실행할 때 처음 표시할 화면을 선택합니다.')
        self.startup_combo.currentIndexChanged.connect(self._save_startup_view); g.addWidget(self.startup_combo,4,1,1,2)
        note=QLabel('다음 실행부터 적용'); note.setObjectName('mutedText'); g.addWidget(note,4,3,1,2)
        g.setColumnStretch(1,1); g.setColumnStretch(3,1)
        l.addWidget(box); l.addStretch(1)
        API_STORE.changed.connect(self._sync_shared_api_ui)
        self._sync_shared_api_ui(API_STORE.get_key())
        STARTUP_STORE.changed.connect(self._sync_startup_ui)
        self._sync_startup_ui(STARTUP_STORE.get_startup_view())

    def _sync_shared_api_ui(self, key=''):
        if not hasattr(self, 'api_edit'): return
        key = str(key or API_STORE.get_key()).strip()
        if self.api_edit.text() != key: self.api_edit.setText(key)
        if key:
            self.api_state.setText('●  API Key 저장됨 · 장비/유니온 공통 적용')
            self.api_state.setStyleSheet('color:#62E7BD;font-weight:900;padding:8px 10px;background:#0B2B2D;border:1px solid #1E665D;border-radius:6px;')
        else:
            self.api_state.setText('●  API Key 미설정')
            self.api_state.setStyleSheet('color:#F4B85C;font-weight:900;padding:8px 10px;background:#2A2110;border:1px solid #6B5621;border-radius:6px;')

    def _save_shared_api_key(self):
        try:
            API_STORE.save_key(self.api_edit.text())
            self.status('API Key가 저장되었습니다. 두 검색기에 공통 적용됩니다.')
        except ValueError as e:
            QMessageBox.warning(self,'API Key',str(e))

    def _logout_shared_api_key(self):
        API_STORE.clear_key()
        self.api_edit.clear()
        self.status('저장된 API Key가 삭제되었습니다.')


    def _sync_startup_ui(self, value=''):
        if not hasattr(self, 'startup_combo'):
            return
        value = str(value or STARTUP_STORE.get_startup_view())
        idx = self.startup_combo.findData(value)
        if idx < 0:
            idx = self.startup_combo.findData('equipment')
        self.startup_combo.blockSignals(True)
        self.startup_combo.setCurrentIndex(max(0, idx))
        self.startup_combo.blockSignals(False)

    def _save_startup_view(self):
        if not hasattr(self, 'startup_combo'):
            return
        value = self.startup_combo.currentData()
        if value:
            STARTUP_STORE.set_startup_view(str(value))
            try:
                self.status('다음 실행 시 첫 화면 설정이 저장되었습니다.')
            except Exception:
                pass

    def _build_help(self):
        p=self.pages['help']; l=QVBoxLayout(p); l.setContentsMargins(10,8,10,10); l.setSpacing(10)
        l.addWidget(self._page_header('도움말','처음 사용하는 분을 위한 유니온챔피언 검색기 사용 방법입니다.'))
        card=QFrame(); card.setObjectName('settingsCard'); c=QVBoxLayout(card); c.setContentsMargins(18,14,18,14); c.setSpacing(0)
        text=QLabel('<b>메이플 유니온챔피언 검색기 v2.0.1</b><br><br><b>1. 검색 조건 설정</b><br>① 검색할 월드와 기준일을 선택합니다. 기본 기준일은 전날로 설정됩니다.<br>② 찾고 싶은 캐릭터의 정확한 레벨과 직업 조합을 입력합니다.<br>③ 최소 2개부터 최대 6개까지 캐릭터 조건을 입력할 수 있습니다.<br><br><b>2. 검색 방법</b><br>① 검색 시작을 누르면 입력한 조합과 일치하는 유니온 챔피언 후보를 찾습니다.<br>② 검색 결과는 확인되는 순서대로 목록에 표시됩니다.<br>③ 검색 중에는 진행 로그에서 처리 상황을 확인할 수 있습니다.<br><br><b>3. 결과 확인</b><br>① 검색 결과를 더블클릭하면 매칭된 캐릭터들의 현재 레벨·직업·외형 정보를 확인할 수 있습니다.<br>② 필요한 경우 검색 결과를 CSV 파일로 저장할 수 있습니다.<br><br>※ 입력한 레벨과 직업은 정확히 일치하는 조건으로 검색됩니다.<br>※ 유니온 챔피언에 등록되지 않은 캐릭터는 조합에 포함되어 있어도 매칭되지 않을 수 있습니다.<br>※ 오늘 데이터는 갱신 시점에 따라 정상적으로 조회되지 않을 수 있어 전날 기준 조회를 권장합니다.<br>※ API Key는 설정에서 한 번 저장하면 두 검색기에 공통 적용되며, 로그아웃하면 저장된 Key가 삭제됩니다.')
        text.setWordWrap(True); text.setObjectName('helpText'); c.addWidget(text); l.addWidget(card); l.addStretch(1)
    def _style(self):
        self.setStyleSheet(r"""
        QWidget{font-family:"Malgun Gothic";font-size:12px;color:#EEF5FF;}
        #root,#mainArea{background:#061225;}
        #titlebar{background:qlineargradient(x1:0,y1:0,x2:1,y2:0,stop:0 #0B1734,stop:1 #07111F);border-bottom:1px solid #1B3B61;}
        #brandTitle{font-size:16px;font-weight:800;} #version{color:#8EA2C4;font-size:11px;} #brandSub{color:#6F89B0;font-size:8px;letter-spacing:2px;}
        QPushButton{border:none;}
        #navButton{background:transparent;color:#B9C7E0;padding:10px 14px;border-radius:7px;font-weight:650;}
        #navButton:hover{background:#112849;color:#FFFFFF;}
        #navButton:checked{background:qlineargradient(x1:0,y1:0,x2:1,y2:1,stop:0 #2B3C9A,stop:1 #432BB3);border:1px solid #7B74FF;color:white;}
        #windowButton,#closeButton{background:transparent;color:#D5DEF0;font-size:18px;} #windowButton:hover{background:#132B4A;} #closeButton:hover{background:#C43B51;color:white;} #navSep{color:#203A5A;}

        #metricCaption{color:#91A8C4;font-size:9px;font-weight:600;background:transparent;border:none;}
        #footer{background:#08162A;border-top:1px solid #18395E;min-height:40px;} #statusDot{color:#6DF2A8;font-size:15px;} #statusLabel{color:#C1D2E9;} #footerMeta{color:#70AEE9;}

        #bigPanel,#settingsCard,#sectionPanel{background:qlineargradient(x1:0,y1:0,x2:1,y2:1,stop:0 #091A30,stop:1 #07172B);border:1px solid #17436D;border-radius:10px;}
        #pageHeader{background:transparent;}
        #pageTitle{font-size:24px;font-weight:900;color:#F1E9FF;} #pageSub{color:#96ACC8;}
        #sectionTitle{font-size:21px;font-weight:850;} #subSectionTitle{font-size:16px;font-weight:900;color:#63D6FF;}
        #sectionBadge{background:qlineargradient(x1:0,y1:0,x2:1,y2:1,stop:0 #63BAFF,stop:1 #8FB6FF);color:#061225;border-radius:5px;font-size:16px;font-weight:900;}
        #countBadge{background:#2A347E;color:#C7CBFF;border-radius:12px;padding:4px 11px;font-weight:800;} #conditionCount{color:#A7BCE0;font-size:13px;}
        #mutedText{color:#8EA7C8;}

        #conditionCard{background:#0B2038;border:1px solid #24537F;border-radius:8px;}
        #conditionCard[main="true"]{border:1px solid #776CFF;background:qlineargradient(x1:0,y1:0,x2:1,y2:1,stop:0 #102A4C,stop:1 #141D49);}
        #slotNo{color:#B9CBE5;font-size:13px;font-weight:700;} #slotClearButton{background:#0B1B30;border:1px solid #294E77;border-radius:5px;color:#A9BDD8;font-size:15px;font-weight:900;padding:0;} #slotClearButton:hover{background:#173251;border-color:#5987B7;color:white;} #fieldLabel{font-weight:700;color:#E0EBFA;}
        QComboBox,QSpinBox,QLineEdit{background:#08182B;border:1px solid #31577E;border-radius:5px;padding:7px 9px;color:white;min-height:24px;}
        QComboBox:hover,QSpinBox:hover,QLineEdit:hover{border-color:#6696CA;}
        QComboBox::drop-down,QSpinBox::up-button,QSpinBox::down-button{border:none;width:24px;}
        QComboBox QAbstractItemView{background:#0C1C31;color:white;selection-background-color:#263F72;border:1px solid #31577E;}


        #datePicker{background:#08182B;border:1px solid #31577E;border-radius:5px;}
        #dateText{border:none;border-radius:5px 0 0 5px;background:transparent;padding:7px 9px;}
        #dateButton{background:#0E2743;border:none;border-left:1px solid #31577E;border-radius:0 5px 5px 0;padding:4px;}
        #dateButton:hover{background:#173A60;}
        #calendarMenu{background:#0B1B31;border:1px solid #31577E;padding:4px;}
        QCalendarWidget QWidget{background:#0B1B31;color:#EAF3FF;}
        QCalendarWidget QToolButton{background:#102742;color:#EAF3FF;border:none;border-radius:4px;padding:5px;}
        QCalendarWidget QAbstractItemView{background:#08182B;color:#EAF3FF;selection-background-color:#3D4DCC;selection-color:white;}
        QCalendarWidget QSpinBox{background:#102742;color:white;border:1px solid #31577E;}
        #cardLevelEdit{font-weight:700;}
        #cardLevelEdit::placeholder{color:#6F88A6;}

        #searchButton{min-height:50px;border-radius:6px;background:qlineargradient(x1:0,y1:0,x2:1,y2:0,stop:0 #8A70FF,stop:.5 #3C47FF,stop:1 #9B54FF);color:white;font-size:21px;font-weight:900;}
        #searchButton:hover{border:1px solid #B8A8FF;}
        #ghostButton{background:#0D2139;border:1px solid #31577E;border-radius:6px;color:#DDE9FA;padding:8px 13px;font-weight:700;}
        #ghostButton:hover{background:#173251;border-color:#5987B7;}

        QTableWidget{background:#07172A;border:1px solid #173A5F;border-radius:7px;color:#DFEBFA;selection-background-color:#173B69;gridline-color:#143252;}
        QHeaderView::section{background:#0D2744;color:#C9D9ED;border:none;border-right:1px solid #193B60;border-bottom:1px solid #193B60;padding:8px 5px;font-weight:700;}
        QTableCornerButton::section{background:#0D2744;border:none;}
        QScrollBar:vertical{background:#071223;width:10px;margin:0;} QScrollBar::handle:vertical{background:#2E5279;border-radius:5px;min-height:30px;} QScrollBar::add-line,QScrollBar::sub-line{height:0;}

        #resultName{font-size:13px;font-weight:900;color:#F0F6FF;} #resultMeta{font-size:9px;color:#8FA9C9;} #representativeLevel{font-size:11px;color:#9ED6FF;font-weight:900;} #representativeClass{font-size:10px;color:#D3E2F7;font-weight:800;} #comboMini{background:#09192C;border:1px solid #173A5F;border-radius:7px;} #comboLevel{font-size:9px;color:#DDEBFB;font-weight:900;} #comboName{font-size:8px;color:#C5D5EA;font-weight:800;} #comboClass{font-size:8px;color:#70BFFF;font-weight:800;} #comboMissing{color:#4C6582;font-size:16px;}
        #settingLabel{color:#A9BDD4;font-weight:700;} QCheckBox{color:#DDE9F8;spacing:7px;} QCheckBox::indicator{width:16px;height:16px;}
        #logBox{background:#061321;border:1px solid #173A5F;border-radius:7px;color:#BBD0E8;padding:8px;font-family:Consolas,"Malgun Gothic";}
        #helpText{font-size:14px;color:#CFDCF0;}


        #detailDialog{background:#061126;border:1px solid #4E67FF;}
        #detailHeader{background:qlineargradient(x1:0,y1:0,x2:1,y2:0,stop:0 #0A1738,stop:1 #071128);border-bottom:1px solid #3356B9;}
        #detailHeaderLeaf{font-size:23px;color:#9C88FF;font-weight:900;}
        #detailHeaderBrand{font-size:11px;color:#C7CFFF;font-weight:800;letter-spacing:2px;}
        #detailHeaderSlogan{font-size:9px;color:#7087C4;letter-spacing:2px;}
        #detailCloseButton{background:transparent;color:#E8ECFF;font-size:22px;}
        #detailCloseButton:hover{background:#B63B55;color:white;}
        #detailContent{background:qlineargradient(x1:0,y1:0,x2:1,y2:1,stop:0 #071630,stop:1 #091231);}
        #detailHeroTitle{font-size:29px;font-weight:950;color:#EDF1FF;}
        #detailHeroSub{font-size:12px;color:#A9B6DB;}
        #detailHeroNote{font-size:11px;color:#57E7C1;font-weight:800;}
        #detailMetric{background:rgba(12,28,64,220);border:1px solid #304E96;border-radius:12px;}
        #detailMetricLabel{font-size:10px;color:#91A5D6;}
        #detailMetricValue{font-size:17px;color:#F1F4FF;font-weight:900;}
        #detailArea{background:transparent;}
        #detailCharacterCard{background:#0B1738;border:1px solid #586DFF;border-radius:12px;}
        #detailConditionBadge{background:qlineargradient(x1:0,y1:0,x2:1,y2:1,stop:0 #4354F6,stop:1 #725BFF);border:1px solid #8492FF;border-radius:6px;color:white;padding:4px 12px;font-weight:900;}
        #detailCardName{font-size:17px;color:#F4F6FF;font-weight:900;}
        #detailCardLevel{font-size:25px;color:#8CC7FF;font-weight:950;}
        #detailCardClass{font-size:13px;color:#B6C3EA;}
        #detailVisual{background:rgba(6,14,39,70);border-radius:8px;}
        #detailImageMissing{color:#6880B3;font-size:11px;}
        #detailInfoRow{background:rgba(8,20,54,205);border:1px solid #263F7F;border-radius:6px;}
        #detailInfoIcon{color:#8FA0FF;font-weight:900;}
        #detailInfoLabel{color:#AEBDE2;font-size:10px;}
        #detailInfoValue{color:#E1E7FA;font-size:10px;font-weight:750;}
        #detailInfoValueGreen{color:#5EE8C4;font-size:10px;font-weight:900;}
        #detailMatchButton{background:qlineargradient(x1:0,y1:0,x2:1,y2:0,stop:0 #243BB8,stop:.5 #4558FF,stop:1 #654CFF);border:1px solid #7C91FF;border-radius:7px;color:white;padding:8px;font-size:14px;font-weight:950;}
        #detailFooter{background:#0A1735;border:1px solid #274B8D;border-radius:8px;}
        #detailFooterStatus{color:#61E8C2;font-size:10px;font-weight:800;}
        #detailActionButton{background:#112B5A;border:1px solid #4069B5;border-radius:7px;color:#E7EDFF;padding:8px 15px;font-weight:800;}
        #detailActionButton:hover{background:#1A3D76;}
        #detailLoading{background:#08162E;color:#C9D7F6;font-size:14px;}
        #dangerText{color:#FF8196;font-size:14px;}

        #detailDialog{background:#061126;border:1px solid #3857CC;}
        #detailHeader{background:qlineargradient(x1:0,y1:0,x2:1,y2:0,stop:0 #0A1738,stop:1 #071128);border-bottom:1px solid #27499F;}
        #detailHeaderLeaf{font-size:22px;color:#9C88FF;font-weight:900;}
        #detailHeaderBrand{font-size:11px;color:#C7CFFF;font-weight:800;letter-spacing:2px;}
        #detailHeaderSlogan{font-size:9px;color:#7087C4;letter-spacing:2px;}
        #detailCloseButton{background:transparent;color:#E8ECFF;font-size:22px;border:none;}
        #detailCloseButton:hover{background:#B63B55;color:white;}
        #detailContent{background:qlineargradient(x1:0,y1:0,x2:1,y2:1,stop:0 #071630,stop:1 #091231);border:none;}
        #detailHeroTitle{font-size:27px;font-weight:950;color:#EDF1FF;}
        #detailHeroSub{font-size:11px;color:#9EADD2;}
        #detailHeroNote{font-size:10px;color:#57E7C1;font-weight:800;}
        #detailCardsHost{background:transparent;border:none;}
        #detailCharacterCard{background:#0B1738;border:1px solid #526AFF;border-radius:11px;}
        #detailConditionBadge{background:qlineargradient(x1:0,y1:0,x2:1,y2:1,stop:0 #4354F6,stop:1 #725BFF);border:1px solid #8492FF;border-radius:6px;color:white;padding:3px 11px;font-weight:900;}
        #detailCardName{font-size:15px;color:#F4F6FF;font-weight:900;}
        #detailCardLevel{font-size:23px;color:#8CC7FF;font-weight:950;}
        #detailCardClass{font-size:12px;color:#B6C3EA;}
        #detailVisual{background:transparent;border:none;}
        #detailCharacterImage{background:transparent;border:none;padding:0px;margin:0px;} #detailStageBg,#detailStageOverlay{border:none;} #detailDeco{background:transparent;border:none;}
        #detailImageMissing{color:#6880B3;font-size:11px;}
        #detailCompactInfo{background:#081632;border:1px solid #263F7F;border-radius:5px;color:#C8D4EF;padding:5px 8px;font-size:9px;}
        #detailWorld{background:#081632;border:1px solid #263F7F;border-radius:5px;color:#D9E4FF;padding:5px 8px;font-size:9px;font-weight:800;}
        #detailCurrentInfo{background:#081632;border:1px solid #263F7F;border-radius:5px;color:#5EE8C4;padding:5px 8px;font-size:9px;font-weight:900;}
        #detailMatchButton{background:qlineargradient(x1:0,y1:0,x2:1,y2:0,stop:0 #243BB8,stop:.5 #4558FF,stop:1 #654CFF);border:1px solid #7C91FF;border-radius:6px;color:white;padding:6px;font-size:12px;font-weight:950;}
        #detailFooter{background:#0A1735;border:1px solid #274B8D;border-radius:7px;}
        #detailFooterStatus{color:#61E8C2;font-size:9px;font-weight:800;}
        #detailActionButton{background:#112B5A;border:1px solid #4069B5;border-radius:6px;color:#E7EDFF;padding:7px 13px;font-weight:800;}
        #detailActionButton:hover{background:#1A3D76;}
        #detailLoading{background:#08162E;color:#C9D7F6;font-size:13px;border:none;}
        #dangerText{color:#FF8196;font-size:13px;}
        """)
        sh=QGraphicsDropShadowEffect(self); sh.setBlurRadius(28); sh.setColor(QColor(75,85,255,120)); sh.setOffset(0,4); self.search_btn.setGraphicsEffect(sh)

    def toggle_maximize(self): self.showNormal() if self.isMaximized() else self.showMaximized()

    def show_page(self,key):
        self.stack.setCurrentWidget(self.pages[key])
        for k,b in self.titlebar.nav.items():b.setChecked(k==key)

    def api_key(self): return API_STORE.get_key()

    def _sync_world_options(self, world_type):
        current=self.world_combo.currentData() if self.world_combo.count() else ''
        self.world_combo.blockSignals(True)
        self.world_combo.clear()

        worlds=[w for w in engine.WORLDS if w]
        special=('에오스','핼리오스')

        if world_type=='전체':
            self.world_combo.addItem('전체 월드','')
            self.world_combo.setCurrentIndex(0)
            self.world_combo.setEnabled(False)

        elif world_type=='에오스·핼리오스':
            self.world_combo.addItem('에오스','에오스')
            self.world_combo.addItem('핼리오스','핼리오스')
            self.world_combo.setEnabled(True)
            idx=self.world_combo.findData(current)
            self.world_combo.setCurrentIndex(idx if idx>=0 else 0)

        else:  # 일반
            self.world_combo.addItem('전체 일반 월드','')
            for w in worlds:
                if w not in special:
                    self.world_combo.addItem(w,w)
            self.world_combo.setEnabled(True)
            idx=self.world_combo.findData(current)
            self.world_combo.setCurrentIndex(idx if idx>=0 else 0)

        self.world_combo.blockSignals(False)

    def clear_conditions(self):
        for c in self.condition_cards:c.clear()

    def reset_all(self):
        self.clear_conditions()
        self.world_type_combo.setCurrentIndex(0)
        self._sync_world_options('전체')
        self.date_edit.setText(_yesterday_kst_qdate().toString('yyyy-MM-dd'))
        self.results.clear(); self.home_table.clear_results(); self.count_badge.setText('0명'); self.status('초기화되었습니다.')

    def refresh_main_marker(self):
        vals=[(c.level_value(),i) for i,c in enumerate(self.condition_cards) if c.value()]
        main=None
        if vals:
            mx=max(v for v,_ in vals); main=min(i for v,i in vals if v==mx)
        for i,c in enumerate(self.condition_cards):c.set_main(i==main)
        self.condition_count.setText(f"{len(vals)} / 6")

    def collect_requests(self):
        world=self.world_combo.currentData() or ''
        req=[]
        for c in self.condition_cards:
            v=c.value()
            if v:v['world']=world; req.append(v)
        return req

    def config(self):
        return {'api_key':self.api_key(),'world_type':self.world_type_combo.currentText(),
                'date':self.date_edit.text() or _yesterday_kst_qdate().toString('yyyy-MM-dd'),
                'workers':self.worker_spin.value(),'max_pages':self.page_spin.value(),
                'perfect_only':self.perfect_check.isChecked()}

    def start_search(self):
        if self.search_thread and self.search_thread.isRunning():
            self.search_thread.stop(); self.status('중지 요청됨...'); return
        if not self.api_key():
            self.show_page('settings'); show_notice(self, 'API Key 필요', '설정에서 NEXON Open API Key를 입력하세요.', level='info'); return
        req=self.collect_requests()
        if len(req)<2:
            show_notice(self, '검색 조건', '레벨과 직업 조건을 최소 2개 입력하세요.', level='info'); return

        self.results=[]; self.home_table.clear_results(); self.count_badge.setText('0명')
        self.search_btn.setText('■  검색 중지'); self.status('검색 준비 중...')
        self.log_box.appendPlainText('— 새 검색 시작 —')
        self.log_box.appendPlainText('안정화 검색: 후보 내부 중첩 병렬 제거 · API 429 전체 쿨다운 · 결과표 증분 갱신')
        cfg=self.config()
        self.search_thread=SearchThread(cfg,req,self)
        self.search_thread.log.connect(self.log); self.search_thread.status.connect(self.status)
        self.search_thread.candidate_total.connect(lambda n:self.log(f'본캐 후보 {n}명'))
        self.search_thread.result_found.connect(self.on_result); self.search_thread.progress.connect(self.on_progress)
        self.search_thread.completed.connect(lambda d:self.on_done(d,req)); self.search_thread.failed.connect(self.on_failed)
        self.search_thread.start()

    def on_result(self,r):
        r['_display_time']=datetime.now().strftime('%Y-%m-%d\n%H:%M')
        self.results.append(r)

        # 검색 중에는 새 결과 한 줄만 추가합니다.
        # 이전에는 결과가 하나 들어올 때마다 표 전체를 삭제하고 다시 만들었기 때문에
        # 결과가 많아질수록 GUI 작업량이 O(n²)로 증가해 중간에 멈춘 것처럼 보일 수 있었습니다.
        self.home_table.add_result(r, len(self.results))
        self.count_badge.setText(f"{len(self.results)}명")

    def on_progress(self,done,total,calls):
        self.status(f"후보 검증 {done}/{total} · API {calls}회")

    def on_done(self,d,req):
        self.search_btn.setText('⌕   검색 시작')
        msg='검색이 중지되었습니다.' if d.get('stopped') else f"검색이 완료되었습니다. ({len(self.results)}명)"
        self.status(msg)
        now=datetime.now()
        self.footer_meta.setText(f"데이터 출처: NEXON Open API   |   마지막 갱신: {now.strftime('%Y-%m-%d %H:%M')}")

        main=max(req,key=lambda x:x['level'])
        self.history.insert(0,{'time':now.strftime('%H:%M:%S'),'main':f"Lv.{main['level']} {main['class']}",
                               'conds':len(req),'cand':d.get('candidate_total',0),'perfect':d.get('perfect',0),
                               'partial':d.get('partial',0),'api':d.get('api_calls',0)})
        self.refresh_history(); self.rebuild_tables()

    def on_failed(self,msg):
        self.search_btn.setText('⌕   검색 시작'); self.status('오류가 발생했습니다.')
        self.log('오류 · '+msg); show_notice(self, '검색 오류', msg, level='error')

    def log(self,msg): self.log_box.appendPlainText(str(msg))
    def status(self,msg): self.status_label.setText(msg)

    def rebuild_tables(self):
        data=list(self.results); mode=self.sort_combo.currentIndex() if hasattr(self,'sort_combo') else 0
        if mode==0:
            data.sort(key=lambda r:(-r['score'],r['candidate'].get('ranking') or 10**9))
        else:
            data.sort(key=lambda r:(-int(r['candidate'].get('level') or 0),r['candidate'].get('ranking') or 10**9))
        self.home_table.clear_results()
        for i,r in enumerate(data,1):self.home_table.add_result(r,i)

    def refresh_history(self):
        self.history_table.setRowCount(len(self.history))
        for r,h in enumerate(self.history):
            for c,k in enumerate(['time','main','conds','cand','perfect','partial','api']):
                it=QTableWidgetItem(str(h[k])); it.setTextAlignment(Qt.AlignmentFlag.AlignCenter); self.history_table.setItem(r,c,it)

    def export_csv(self):
        if not self.results:
            show_notice(self, 'CSV 저장', '저장할 검색 결과가 없습니다.', level='info'); return
        path,_=QFileDialog.getSaveFileName(self,'결과 CSV 저장','union_champion_results.csv','CSV (*.csv)')
        if not path:return
        with open(path,'w',newline='',encoding='utf-8-sig') as f:
            w=csv.writer(f); w.writerow(['일치','본캐 후보','월드','본캐 직업','본캐 레벨','랭킹','매칭 상세'])
            for r in self.results:
                c=r['candidate']; w.writerow([f"{r['score']}/{r['total']}",c['name'],c.get('world',''),c.get('class',''),c.get('level',0),c.get('ranking',''),' | '.join(r.get('detail',[]))])
        self.status('CSV 저장이 완료되었습니다.')

    def open_detail(self,r):
        if not self.api_key():
            show_notice(self, 'API Key 필요', '현재 캐릭터 정보를 다시 조회하려면 설정의 API Key가 필요합니다.', level='info'); return
        d=DetailDialog(self,r); d.exec()

    def closeEvent(self,e):
        if self.search_thread and self.search_thread.isRunning():
            self.search_thread.stop(); self.search_thread.wait(1500)
        super().closeEvent(e)


if __name__=='__main__':
    app=QApplication(sys.argv)
    app.setApplicationName('메이플 유니온챔피언 검색기')
    app.setWindowIcon(QIcon(str(BASE_DIR/'app_icon.png')))
    w=MainWindow(); w.show(); sys.exit(app.exec())
