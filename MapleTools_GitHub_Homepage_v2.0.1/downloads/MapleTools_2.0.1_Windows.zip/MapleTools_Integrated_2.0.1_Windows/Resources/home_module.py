# -*- coding: utf-8 -*-
from __future__ import annotations

from pathlib import Path
from PySide6.QtCore import Qt, QRect, QRectF, QPointF, Signal, QTimer, QUrl
from PySide6.QtGui import (
    QColor, QPainter, QPen, QPixmap, QFont, QLinearGradient, QPainterPath,
    QDesktopServices, QIcon
)
from PySide6.QtWidgets import (
    QWidget, QPushButton, QDialog, QLabel, QVBoxLayout, QHBoxLayout, QFormLayout,
    QLineEdit, QComboBox, QFrame, QSizePolicy, QScrollArea
)

from shared_startup import STARTUP_STORE

try:
    from shared_api import API_STORE
except Exception:
    API_STORE = None

BASE_DIR = Path(__file__).resolve().parent
HOME_DIR = BASE_DIR / 'home_assets'


DIALOG_QSS = r"""
QDialog{background:#07142B;color:#EEF5FF;}
QLabel{color:#EAF2FF;background:transparent;}
#dlgTitle{font-size:22px;font-weight:900;color:#F6F8FF;}
#dlgSub{color:#8FA8C9;font-size:11px;}
#card{background:#091B34;border:1px solid #244E7D;border-radius:10px;}
#section{font-size:14px;font-weight:900;color:#73D9FF;}
QLineEdit,QComboBox{background:#08182B;border:1px solid #31577E;border-radius:6px;padding:7px 9px;color:white;min-height:24px;}
QLineEdit:focus,QComboBox:focus{border-color:#7F77FF;}
QPushButton{background:#102842;color:#EAF3FF;border:1px solid #31577E;border-radius:7px;padding:8px 16px;font-weight:800;}
QPushButton:hover{background:#173A60;border-color:#6696CA;}
#primary{background:qlineargradient(x1:0,y1:0,x2:1,y2:0,stop:0 #576CFF,stop:1 #8455FF);border:1px solid #9C8DFF;color:white;}
#danger{background:#2A1730;border:1px solid #70405C;color:#FFDDE7;}
#statusOk{color:#61E5AA;font-weight:800;}
#statusWarn{color:#F4B85C;font-weight:800;}
QScrollArea{border:none;background:transparent;} QScrollArea>QWidget>QWidget{background:transparent;}
"""


class CommonSettingsDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle('MapleTools 공통 설정')
        self.setModal(True)
        self.resize(620, 360 if API_STORE is not None else 285)
        self.setStyleSheet(DIALOG_QSS)

        root = QVBoxLayout(self)
        root.setContentsMargins(22, 20, 22, 20)
        root.setSpacing(14)

        t = QLabel('공통 설정'); t.setObjectName('dlgTitle'); root.addWidget(t)
        s = QLabel('장비 검색기와 유니온챔피언 검색기에 함께 적용되는 설정입니다.')
        s.setObjectName('dlgSub'); root.addWidget(s)

        card = QFrame(); card.setObjectName('card')
        cv = QVBoxLayout(card); cv.setContentsMargins(18, 16, 18, 16); cv.setSpacing(12)
        st = QLabel('시작 화면'); st.setObjectName('section'); cv.addWidget(st)
        row = QHBoxLayout(); row.setSpacing(10)
        row.addWidget(QLabel('다음 실행 시 첫 화면'))
        self.startup = QComboBox()
        self.startup.addItem('MapleTools 홈', 'home')
        self.startup.addItem('장비 검색기', 'equipment')
        self.startup.addItem('유니온챔피언 검색기', 'union')
        cur = STARTUP_STORE.get_startup_view()
        idx = self.startup.findData(cur)
        self.startup.setCurrentIndex(idx if idx >= 0 else 0)
        row.addWidget(self.startup, 1)
        cv.addLayout(row)
        root.addWidget(card)

        api_card = QFrame(); api_card.setObjectName('card')
        av = QVBoxLayout(api_card); av.setContentsMargins(18, 16, 18, 16); av.setSpacing(10)
        at = QLabel('NEXON Open API'); at.setObjectName('section'); av.addWidget(at)
        if API_STORE is None:
            status = QLabel('● 개인용 API 연결됨')
            status.setObjectName('statusOk')
            av.addWidget(status)
            av.addWidget(QLabel('PERSONAL 버전은 별도 API Key 입력 없이 두 검색기에 공통 적용됩니다.'))
        else:
            self.api_status = QLabel()
            av.addWidget(self.api_status)
            ar = QHBoxLayout(); ar.setSpacing(8)
            self.api_edit = QLineEdit(); self.api_edit.setEchoMode(QLineEdit.Password)
            self.api_edit.setPlaceholderText('NEXON Open API Key 입력')
            self.api_edit.setText(API_STORE.get_key())
            ar.addWidget(self.api_edit, 1)
            save = QPushButton('API 저장'); save.clicked.connect(self._save_api); ar.addWidget(save)
            logout = QPushButton('로그아웃'); logout.setObjectName('danger'); logout.clicked.connect(self._clear_api); ar.addWidget(logout)
            av.addLayout(ar)
            self._refresh_api()
            try: API_STORE.changed.connect(lambda _k: self._refresh_api())
            except Exception: pass
        root.addWidget(api_card)

        br = QHBoxLayout(); br.addStretch(1)
        save_all = QPushButton('설정 저장'); save_all.setObjectName('primary'); save_all.clicked.connect(self._save)
        close = QPushButton('닫기'); close.clicked.connect(self.accept)
        br.addWidget(save_all); br.addWidget(close); root.addLayout(br)

    def _refresh_api(self):
        if API_STORE is None: return
        if API_STORE.get_key():
            self.api_status.setText('● API Key 저장됨 · 두 검색기에 공통 적용')
            self.api_status.setObjectName('statusOk')
        else:
            self.api_status.setText('● API Key 미설정')
            self.api_status.setObjectName('statusWarn')
        self.api_status.style().unpolish(self.api_status); self.api_status.style().polish(self.api_status)

    def _save_api(self):
        if API_STORE is None: return
        try: API_STORE.save_key(self.api_edit.text())
        except Exception as e:
            self.api_status.setText(str(e)); self.api_status.setObjectName('statusWarn')
            self.api_status.style().unpolish(self.api_status); self.api_status.style().polish(self.api_status)

    def _clear_api(self):
        if API_STORE is None: return
        API_STORE.clear_key(); self.api_edit.clear(); self._refresh_api()

    def _save(self):
        STARTUP_STORE.set_startup_view(str(self.startup.currentData()))
        self.accept()


class CommonGuideDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle('MapleTools 이용 안내')
        self.setModal(True)
        self.resize(720, 610)
        self.setStyleSheet(DIALOG_QSS)
        root = QVBoxLayout(self); root.setContentsMargins(22,20,22,20); root.setSpacing(12)
        t=QLabel('공통 이용 안내'); t.setObjectName('dlgTitle'); root.addWidget(t)
        s=QLabel('처음 사용하는 분을 위한 MapleTools 사용 방법입니다.'); s.setObjectName('dlgSub'); root.addWidget(s)

        scroll=QScrollArea(); scroll.setWidgetResizable(True)
        host=QWidget(); hv=QVBoxLayout(host); hv.setContentsMargins(0,0,8,0); hv.setSpacing(12)
        text = (
            '<b>1. 시작하기</b><br>'
            '• 홈에서 장비 검색기 또는 유니온챔피언 검색기를 선택합니다.<br>'
            '• 배포용은 공통 설정에서 NEXON Open API Key를 한 번 저장하면 두 검색기에 함께 적용됩니다.<br><br>'
            '<b>2. 장비 검색기</b><br>'
            '• 기준일·레벨·직업·월드를 설정한 뒤 장비명/스타포스, 잠재능력, 에디셔널 잠재능력, 추가옵션 중 필요한 조건을 입력합니다.<br>'
            '• 2~5번 검색 조건 중 최소 하나를 설정해야 검색할 수 있습니다.<br>'
            '• 결과는 확인되는 순서대로 표시되며, 선택하면 우측 상세정보와 상세창에서 타임라인·코디 기록을 확인할 수 있습니다.<br>'
            '• 필요한 결과는 CSV로 저장할 수 있습니다.<br><br>'
            '<b>3. 유니온챔피언 검색기</b><br>'
            '• 월드와 기준일을 정하고, 찾을 캐릭터의 정확한 레벨·직업 조합을 2~6개 입력합니다.<br>'
            '• 검색 결과를 더블클릭하면 매칭된 캐릭터들의 현재 정보와 외형을 확인할 수 있습니다.<br>'
            '• 유니온 챔피언에 등록되지 않은 캐릭터는 조합에 포함되어 있어도 매칭되지 않을 수 있습니다.<br><br>'
            '<b>4. 날짜</b><br>'
            '• 당일 데이터는 갱신 시점에 따라 불안정할 수 있어 기본 기준일은 전날로 설정됩니다.<br><br>'
            '<b>5. 프로그램 전환</b><br>'
            '• 검색기 화면 상단의 APP 버튼으로 홈·장비 검색기·유니온챔피언 검색기를 바로 전환할 수 있습니다.'
        )
        lab=QLabel(text); lab.setWordWrap(True); lab.setTextFormat(Qt.RichText); lab.setStyleSheet('font-size:13px;line-height:1.55;color:#DCE8FA;')
        card=QFrame(); card.setObjectName('card'); cv=QVBoxLayout(card); cv.setContentsMargins(18,16,18,16); cv.addWidget(lab)
        hv.addWidget(card); hv.addStretch(1); scroll.setWidget(host); root.addWidget(scroll,1)
        br=QHBoxLayout(); br.addStretch(1); b=QPushButton('닫기'); b.setObjectName('primary'); b.clicked.connect(self.accept); br.addWidget(b); root.addLayout(br)


class HomeWidget(QWidget):
    actionRequested = Signal(str)
    CANVAS_W = 1612
    CANVAS_H = 976

    # All coordinates are in the uploaded 1612x976 home-background coordinate space.
    EQUIPMENT_CARD = QRect(500, 305, 284, 332)
    UNION_CARD = QRect(828, 305, 284, 332)
    SETTINGS_BUTTON = QRect(500, 655, 188, 91)
    GUIDE_BUTTON = QRect(712, 655, 188, 91)
    WEBSITE_BUTTON = QRect(924, 655, 188, 91)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMouseTracking(True)
        self.setObjectName('mapleToolsHome')
        self.setStyleSheet('#mapleToolsHome{background:#040A24;}')
        self._hover = None
        self._phase = 0.0
        self._drag_pos = None
        self._scale = 1.0
        self._ox = 0.0
        self._oy = 0.0

        self.bg = QPixmap(str(HOME_DIR/'home_background.png'))
        self.logo = QPixmap(str(HOME_DIR/'home_logo.png'))
        self.eq_icon = QPixmap(str(HOME_DIR/'home_equipment_icon.png'))
        self.un_icon = QPixmap(str(HOME_DIR/'home_union_icon.png'))

        self.anim = QTimer(self)
        self.anim.setInterval(28)
        self.anim.timeout.connect(self._tick)

        self._min_btn = self._window_button('—', 'minimize')
        self._max_btn = self._window_button('□', 'maximize')
        self._close_btn = self._window_button('×', 'close', True)

    def _window_button(self, text, action, close=False):
        b=QPushButton(text,self); b.setFixedSize(36,30); b.setCursor(Qt.PointingHandCursor)
        if close:
            b.setStyleSheet('QPushButton{background:rgba(5,12,35,135);color:#EEF5FF;border:none;border-radius:5px;font-size:16px;}QPushButton:hover{background:#C43B51;}')
        else:
            b.setStyleSheet('QPushButton{background:rgba(5,12,35,135);color:#EEF5FF;border:none;border-radius:5px;font-size:15px;}QPushButton:hover{background:rgba(32,65,112,225);}')
        b.clicked.connect(lambda _=False,a=action:self.actionRequested.emit(a)); b.raise_(); return b

    def _tick(self):
        self._phase = (self._phase + 0.012) % 1.0
        self.update()

    def _update_transform(self):
        if self.width() <= 0 or self.height() <= 0: return
        # Cover, not contain: no black bars. Aspect ratio is preserved and only the
        # minimum unavoidable edge crop is allowed on unusually wide/tall windows.
        self._scale=max(self.width()/self.CANVAS_W,self.height()/self.CANVAS_H)
        dw=self.CANVAS_W*self._scale; dh=self.CANVAS_H*self._scale
        self._ox=(self.width()-dw)/2.0; self._oy=(self.height()-dh)/2.0

    def _logical_point(self,pos):
        return QPointF((pos.x()-self._ox)/self._scale,(pos.y()-self._oy)/self._scale)

    def _hit_action(self,pos):
        p=self._logical_point(pos)
        if self.EQUIPMENT_CARD.contains(int(p.x()),int(p.y())): return 'open_equipment'
        if self.UNION_CARD.contains(int(p.x()),int(p.y())): return 'open_union'
        if self.SETTINGS_BUTTON.contains(int(p.x()),int(p.y())): return 'settings'
        if self.GUIDE_BUTTON.contains(int(p.x()),int(p.y())): return 'guide'
        if self.WEBSITE_BUTTON.contains(int(p.x()),int(p.y())): return 'website'
        return None

    @staticmethod
    def _fit_pixmap(p, pix, rect):
        if pix.isNull(): return
        pm=pix.scaled(int(rect.width()),int(rect.height()),Qt.KeepAspectRatio,Qt.SmoothTransformation)
        x=rect.x()+(rect.width()-pm.width())/2; y=rect.y()+(rect.height()-pm.height())/2
        p.drawPixmap(int(x),int(y),pm)

    def _draw_card(self,p,rect,kind,title,desc,icon,accent1,accent2):
        hovered=self._hover==kind
        rr=QRectF(rect)
        fill=QColor(5,17,49,222 if not hovered else 238)
        p.setBrush(fill); p.setPen(QPen(QColor(accent1 if hovered else '#345A93'),2.2 if hovered else 1.25))
        p.drawRoundedRect(rr,16,16)
        if hovered:
            # Inset glow only: never spills away from the actual card border.
            for inset,alpha,width in [(3,115,3.0),(7,55,5.0)]:
                r=rr.adjusted(inset,inset,-inset,-inset)
                c=QColor(accent1); c.setAlpha(alpha)
                p.setBrush(Qt.NoBrush); p.setPen(QPen(c,width)); p.drawRoundedRect(r,14,14)
            path=QPainterPath(); path.addRoundedRect(rr.adjusted(4,4,-4,-4),13,13)
            pt=path.pointAtPercent(self._phase)
            for radius,alpha in [(11,32),(7,75),(3.5,235)]:
                c=QColor(accent1); c.setAlpha(alpha); p.setBrush(c); p.setPen(Qt.NoPen); p.drawEllipse(pt,radius,radius)

        icon_rect=QRectF(rect.x()+72,rect.y()+20,140,140)
        self._fit_pixmap(p,icon,icon_rect)

        p.setPen(QColor('#F6F8FF')); f=QFont('Malgun Gothic'); f.setPixelSize(26); f.setBold(True); p.setFont(f)
        p.drawText(QRectF(rect.x()+18,rect.y()+158,rect.width()-36,40),Qt.AlignHCenter|Qt.AlignVCenter,title)
        p.setPen(QColor('#D2DDF2')); f.setPixelSize(16); f.setBold(False); p.setFont(f)
        p.drawText(QRectF(rect.x()+26,rect.y()+199,rect.width()-52,58),Qt.AlignHCenter|Qt.AlignVCenter|Qt.TextWordWrap,desc)

        btn=QRectF(rect.x()+22,rect.bottom()-69,rect.width()-44,50)
        grad=QLinearGradient(btn.topLeft(),btn.topRight()); grad.setColorAt(0,QColor(accent1)); grad.setColorAt(1,QColor(accent2))
        p.setBrush(grad); p.setPen(QPen(QColor('#9FD8FF' if kind=='open_equipment' else '#C7A5FF'),1.4)); p.drawRoundedRect(btn,12,12)
        p.setPen(QColor('white')); f.setPixelSize(20); f.setBold(True); p.setFont(f); p.drawText(btn,Qt.AlignCenter,'시작하기  ›')

    def _draw_small_button(self,p,rect,title,glyph):
        hovered=self._hover in {'settings','guide','website'} and {
            self.SETTINGS_BUTTON:'settings',self.GUIDE_BUTTON:'guide',self.WEBSITE_BUTTON:'website'
        }.get(rect)==self._hover
        rr=QRectF(rect); p.setBrush(QColor(7,24,54,232 if hovered else 215)); p.setPen(QPen(QColor('#6287C7' if hovered else '#365680'),1.5)); p.drawRoundedRect(rr,12,12)
        p.setPen(QColor('#F0F5FF')); f=QFont('Malgun Gothic'); f.setPixelSize(28); f.setBold(True); p.setFont(f); p.drawText(QRectF(rect.x(),rect.y()+7,rect.width(),36),Qt.AlignCenter,glyph)
        f.setPixelSize(16); p.setFont(f); p.drawText(QRectF(rect.x(),rect.y()+46,rect.width(),34),Qt.AlignCenter,title)

    def paintEvent(self,event):
        self._update_transform()
        p=QPainter(self); p.setRenderHint(QPainter.Antialiasing,True); p.setRenderHint(QPainter.SmoothPixmapTransform,True)
        p.fillRect(self.rect(),QColor('#03091F'))
        p.save(); p.translate(self._ox,self._oy); p.scale(self._scale,self._scale)
        if not self.bg.isNull(): p.drawPixmap(QRect(0,0,self.CANVAS_W,self.CANVAS_H),self.bg)

        # Branding
        self._fit_pixmap(p,self.logo,QRectF(575,35,462,214))
        p.setPen(QColor('#ECF3FF')); f=QFont('Malgun Gothic'); f.setPixelSize(20); f.setBold(True); p.setFont(f)
        p.drawText(QRectF(520,242,572,36),Qt.AlignCenter,'필요한 정보를, 더 빠르고 쉽게.')

        self._draw_card(p,self.EQUIPMENT_CARD,'open_equipment','메이플 장비 검색기','원하는 장비 스펙으로\n유저를 찾아보세요.',self.eq_icon,'#118BFF','#2154D9')
        self._draw_card(p,self.UNION_CARD,'open_union','유니온챔피언 검색기','전서버 유니온챔피언\n유저를 빠르게 검색해보세요.',self.un_icon,'#914CFF','#5A20D6')
        self._draw_small_button(p,self.SETTINGS_BUTTON,'공통 설정','⚙')
        self._draw_small_button(p,self.GUIDE_BUTTON,'공통 이용안내','ⓘ')
        self._draw_small_button(p,self.WEBSITE_BUTTON,'공식 사이트','⌁')

        p.setPen(QColor('#FFFFFF')); f.setPixelSize(18); f.setBold(True); p.setFont(f); p.drawText(QRectF(585,790,440,32),Qt.AlignCenter,'MapleTools')
        p.setPen(QColor('#A9BCE3')); f.setPixelSize(14); f.setBold(False); p.setFont(f); p.drawText(QRectF(585,819,440,28),Qt.AlignCenter,'Maple Live, More Fun.')
        p.restore(); p.end()

    def resizeEvent(self,event):
        self._update_transform(); gap=4; y=8; x=self.width()-10-self._close_btn.width(); self._close_btn.move(x,y); x-=gap+self._max_btn.width(); self._max_btn.move(x,y); x-=gap+self._min_btn.width(); self._min_btn.move(x,y); super().resizeEvent(event)

    def mouseMoveEvent(self,event):
        if self._drag_pos is not None and event.buttons() & Qt.LeftButton:
            w=self.window()
            if not w.isMaximized(): w.move(event.globalPosition().toPoint()-self._drag_pos)
            return
        action=self._hit_action(event.position().toPoint())
        if action!=self._hover:
            self._hover=action; self.setCursor(Qt.PointingHandCursor if action else Qt.ArrowCursor)
            if action in {'open_equipment','open_union'}:
                if not self.anim.isActive(): self.anim.start()
            else:
                self.anim.stop(); self._phase=0.0
            self.update()
        super().mouseMoveEvent(event)

    def leaveEvent(self,event):
        self._hover=None; self.anim.stop(); self._phase=0.0; self.setCursor(Qt.ArrowCursor); self.update(); super().leaveEvent(event)

    def mousePressEvent(self,event):
        if event.button()==Qt.LeftButton:
            action=self._hit_action(event.position().toPoint())
            if action is None and event.position().y()<=54:
                self._drag_pos=event.globalPosition().toPoint()-self.window().frameGeometry().topLeft()
        super().mousePressEvent(event)

    def mouseReleaseEvent(self,event):
        if event.button()==Qt.LeftButton:
            if self._drag_pos is not None: self._drag_pos=None
            else:
                action=self._hit_action(event.position().toPoint())
                if action: self.actionRequested.emit(action)
        super().mouseReleaseEvent(event)

    def mouseDoubleClickEvent(self,event):
        if event.button()==Qt.LeftButton and event.position().y()<=54: self.actionRequested.emit('maximize')
        super().mouseDoubleClickEvent(event)
