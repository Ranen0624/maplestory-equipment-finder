# -*- coding: utf-8 -*-
from __future__ import annotations
from PySide6.QtCore import QObject, Signal, QSettings

class SharedApiStore(QObject):
    changed = Signal(str)

    def __init__(self):
        super().__init__()
        self.settings = QSettings('MapleTools', 'Integrated')

    def get_key(self) -> str:
        return str(self.settings.value('nexon/api_key', '') or '').strip()

    def save_key(self, key: str):
        key = str(key or '').strip()
        if not key:
            raise ValueError('API Key를 입력하세요.')
        self.settings.setValue('nexon/api_key', key)
        self.settings.sync()
        self.changed.emit(key)

    def clear_key(self):
        self.settings.remove('nexon/api_key')
        self.settings.sync()
        self.changed.emit('')

API_STORE = SharedApiStore()
