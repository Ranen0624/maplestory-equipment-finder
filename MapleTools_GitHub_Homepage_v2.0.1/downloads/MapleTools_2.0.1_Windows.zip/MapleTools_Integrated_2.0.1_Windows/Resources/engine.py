# -*- coding: utf-8 -*-
import json
import threading
import time
import queue
import urllib.parse
import urllib.request
import urllib.error
import csv
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import date, timedelta, datetime, timezone

BASE = "https://open.api.nexon.com"
UA = "MapleUnionChampionFinder/2.0.1"

# 편집 가능한 직업 목록. 목록에 없어도 직접 입력 가능.
CLASSES = [
    "히어로","팔라딘","다크나이트",
    "아크메이지(불,독)","아크메이지(썬,콜)","비숍",
    "보우마스터","신궁","패스파인더",
    "나이트로드","섀도어","듀얼블레이더",
    "바이퍼","캡틴","캐논마스터",
    "소울마스터","미하일","플레임위자드","윈드브레이커","나이트워커","스트라이커",
    "아란","에반","루미너스","메르세데스","팬텀","은월",
    "데몬슬레이어","데몬어벤져","블래스터","배틀메이지","와일드헌터","메카닉","제논",
    "카이저","카인","카데나","엔젤릭버스터",
    "아델","일리움","칼리","아크",
    "라라","호영","렌","레테",
    "제로","키네시스"
]

WORLDS = ["", "스카니아","베라","루나","제니스","크로아","유니온","엘리시움","이노시스","레드",
          "오로라","아케인","노바","에오스","핼리오스"]

JOB_API_FILTER = {
    "히어로": "전사-히어로",
    "팔라딘": "전사-팔라딘",
    "다크나이트": "전사-다크나이트",
    "아크메이지(불,독)": "마법사-아크메이지(불독)",
    "아크메이지(썬,콜)": "마법사-아크메이지(썬콜)",
    "비숍": "마법사-비숍",
    "보우마스터": "궁수-보우마스터",
    "신궁": "궁수-신궁",
    "패스파인더": "궁수-패스파인더",
    "나이트로드": "도적-나이트로드",
    "섀도어": "도적-섀도어",
    "듀얼블레이더": "도적-듀얼블레이더",
    "바이퍼": "해적-바이퍼",
    "캡틴": "해적-캡틴",
    "캐논마스터": "해적-캐논마스터",
    "소울마스터": "기사단-소울마스터",
    "미하일": "기사단-미하일",
    "플레임위자드": "기사단-플레임위자드",
    "윈드브레이커": "기사단-윈드브레이커",
    "나이트워커": "기사단-나이트워커",
    "스트라이커": "기사단-스트라이커",
    "아란": "아란-전체 전직",
    "에반": "에반-전체 전직",
    "루미너스": "루미너스-전체 전직",
    "메르세데스": "메르세데스-전체 전직",
    "팬텀": "팬텀-전체 전직",
    "은월": "은월-전체 전직",
    "데몬슬레이어": "레지스탕스-데몬슬레이어",
    "데몬어벤져": "레지스탕스-데몬어벤져",
    "블래스터": "레지스탕스-블래스터",
    "배틀메이지": "레지스탕스-배틀메이지",
    "와일드헌터": "레지스탕스-와일드헌터",
    "메카닉": "레지스탕스-메카닉",
    "제논": "레지스탕스-제논",
    "카이저": "카이저-전체 전직",
    "카인": "카인-전체 전직",
    "카데나": "카데나-전체 전직",
    "엔젤릭버스터": "엔젤릭버스터-전체 전직",
    "아델": "아델-전체 전직",
    "일리움": "일리움-전체 전직",
    "칼리": "칼리-전체 전직",
    "아크": "아크-전체 전직",
    "라라": "라라-전체 전직",
    "호영": "호영-전체 전직",
    "렌": "렌-전체 전직",
    "레테": "레테-전체 전직",
    "제로": "초월자-제로",
    "키네시스": "프렌즈 월드-키네시스",
}

JOB_ALIASES = {
    "듀얼블레이드": "듀얼블레이더",
    "아크메이지(불독)": "아크메이지(불,독)",
    "아크메이지(썬콜)": "아크메이지(썬,콜)",
}

def canonical_job(value):
    v = str(value or "").strip()
    return JOB_ALIASES.get(v, v)

def default_snapshot_date():
    kst = timezone(timedelta(hours=9))
    return (datetime.now(kst).date() - timedelta(days=1)).isoformat()

def norm(s):
    return "".join(str(s or "").strip().lower().split())

class ApiError(Exception):
    pass

class NexonAPI:
    def __init__(self, key, progress=None, max_retries=6):
        self.key = key.strip()
        self.progress = progress or (lambda *_: None)
        self.max_retries = max_retries
        self._lock = threading.Lock()
        self.calls = 0
        self.ocid_cache = {}
        self.basic_cache = {}
        self.champion_cache = {}

        # 여러 후보를 동시에 검사하더라도 HTTP 요청이 한꺼번에 폭발하지 않도록
        # 실제 네트워크 동시 요청 수를 제한합니다.
        self._http_semaphore = threading.BoundedSemaphore(12)

        # 한 스레드에서 429를 받으면 모든 검색 스레드가 같은 쿨다운을 공유합니다.
        # 각 스레드가 제각각 재시도하면서 429 폭풍이 나는 것을 방지합니다.
        self._cooldown_lock = threading.Lock()
        self._cooldown_until = 0.0

    def _inc(self):
        with self._lock:
            self.calls += 1
            return self.calls

    def _wait_global_cooldown(self):
        while True:
            with self._cooldown_lock:
                remain = self._cooldown_until - time.monotonic()
            if remain <= 0:
                return
            time.sleep(min(remain, 0.25))

    def _extend_global_cooldown(self, seconds):
        seconds = max(0.2, float(seconds))
        with self._cooldown_lock:
            self._cooldown_until = max(
                self._cooldown_until,
                time.monotonic() + seconds
            )

    def get(self, path, params=None):
        params = {k: v for k, v in (params or {}).items() if v not in (None, "")}
        url = f"{BASE}/{path}"
        if params:
            url += "?" + urllib.parse.urlencode(params)
        headers = {
            "x-nxopen-api-key": self.key,
            "User-Agent": UA,
            "Accept": "application/json"
        }
        wait = 0.6
        for attempt in range(self.max_retries):
            self._wait_global_cooldown()
            req = urllib.request.Request(url, headers=headers, method="GET")
            self._inc()
            try:
                with self._http_semaphore:
                    with urllib.request.urlopen(req, timeout=20) as r:
                        raw = r.read().decode("utf-8")
                        return json.loads(raw)
            except urllib.error.HTTPError as e:
                body = ""
                try:
                    body = e.read().decode("utf-8", "replace")
                except Exception:
                    pass
                if e.code == 429:
                    retry_after = e.headers.get("Retry-After")
                    try:
                        sleep_for = float(retry_after)
                    except Exception:
                        sleep_for = wait
                    self._extend_global_cooldown(sleep_for)
                    self.progress(
                        f"API 호출 제한(429) · 전체 요청 {sleep_for:.1f}초 쿨다운 후 재시도"
                    )
                    self._wait_global_cooldown()
                    wait = min(wait * 1.8, 8.0)
                    continue
                if e.code in (500, 502, 503, 504) and attempt + 1 < self.max_retries:
                    time.sleep(wait)
                    wait = min(wait * 1.8, 8.0)
                    continue
                raise ApiError(f"HTTP {e.code}: {body[:300] or e.reason}")
            except urllib.error.URLError as e:
                if attempt + 1 >= self.max_retries:
                    raise ApiError(f"네트워크 오류: {e}")
                time.sleep(wait)
                wait = min(wait * 1.8, 8.0)
        raise ApiError("API 재시도 횟수를 초과했습니다.")

    def ocid(self, name):
        key = name.strip()
        if key in self.ocid_cache:
            return self.ocid_cache[key]
        d = self.get("maplestory/v1/id", {"character_name": key})
        ocid = d.get("ocid")
        if not ocid:
            raise ApiError(f"OCID를 찾지 못했습니다: {key}")
        self.ocid_cache[key] = ocid
        return ocid

    def basic(self, name, query_date=None):
        ck = (name.strip(), query_date or "")
        if ck in self.basic_cache:
            return self.basic_cache[ck]
        ocid = self.ocid(name)
        params = {"ocid": ocid}
        if query_date:
            params["date"] = query_date
        d = self.get("maplestory/v1/character/basic", params)
        out = {
            "name": d.get("character_name") or name,
            "level": int(d.get("character_level") or 0),
            "class": d.get("character_class") or "",
            "world": d.get("world_name") or "",
            "image": d.get("character_image") or "",
            "gender": d.get("character_gender") or "",
            "guild": d.get("character_guild_name") or "",
        }
        self.basic_cache[ck] = out
        return out

    def union_champions(self, candidate_name, query_date=None):
        ck = (candidate_name.strip(), query_date or "")
        if ck in self.champion_cache:
            return self.champion_cache[ck]
        ocid = self.ocid(candidate_name)
        params = {"ocid": ocid}
        if query_date:
            params["date"] = query_date
        d = self.get("maplestory/v1/user/union-champion", params)

        found = []
        seen = set()

        def walk(x):
            if isinstance(x, dict):
                cname = x.get("champion_name")
                cclass = x.get("champion_class")
                if cname and cname not in seen:
                    seen.add(cname)
                    found.append({"name": cname, "class_hint": cclass or ""})
                for v in x.values():
                    walk(v)
            elif isinstance(x, list):
                for v in x:
                    walk(v)
        walk(d)
        self.champion_cache[ck] = found
        return found

    def ranking_page(self, page, class_name, world_name="", world_type=0, query_date=None):
        params = {
            "page": page,
            "class": class_name,
            "world_type": world_type,
        }
        if world_name:
            params["world_name"] = world_name
        if query_date:
            params["date"] = query_date
        return self.get("maplestory/v1/ranking/overall", params).get("ranking") or []


def choose_matching(requests, chars, fixed_main_req_idx=None, fixed_main_char_name=None):
    """요청조건과 실제 캐릭터를 1:1 매칭. 최대 일치수를 반환."""
    reqs = list(enumerate(requests))
    chars = list(chars)

    fixed = {}
    used_names = set()
    if fixed_main_req_idx is not None and fixed_main_char_name:
        target = next((c for c in chars if c["name"] == fixed_main_char_name), None)
        if target is not None:
            r = requests[fixed_main_req_idx]
            if char_matches_req(target, r):
                fixed[fixed_main_req_idx] = target
                used_names.add(target["name"])

    remain = [(i, r) for i, r in reqs if i not in fixed]
    # 후보 수가 적은 조건부터 배치하면 백트래킹이 빨라짐.
    cand_map = {}
    for i, r in remain:
        cand_map[i] = [c for c in chars if c["name"] not in used_names and char_matches_req(c, r)]
    remain.sort(key=lambda ir: len(cand_map[ir[0]]))

    best = dict(fixed)

    def dfs(pos, cur, used):
        nonlocal best
        if len(cur) > len(best):
            best = dict(cur)
        if pos >= len(remain):
            return
        # 남은 조건을 전부 맞춰도 best를 못 넘으면 가지치기
        if len(cur) + (len(remain) - pos) <= len(best):
            return
        i, r = remain[pos]
        # 매칭 시도
        for c in cand_map[i]:
            if c["name"] in used:
                continue
            cur[i] = c
            used.add(c["name"])
            dfs(pos + 1, cur, used)
            used.remove(c["name"])
            cur.pop(i, None)
        # 이 조건을 건너뛰는 경우
        dfs(pos + 1, cur, used)

    dfs(0, dict(fixed), set(used_names))
    return best

def char_matches_req(c, r):
    if int(c.get("level") or 0) != int(r["level"]):
        return False
    if norm(canonical_job(c.get("class"))) != norm(canonical_job(r["class"])):
        return False
    if r.get("world") and norm(c.get("world")) != norm(r["world"]):
        return False
    return True



