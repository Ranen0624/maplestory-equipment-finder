﻿@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
echo [Maple Tools 0.4.3e] 실행 준비 중...
echo Python이 없으면 공식 Python 3.12.10을 자동 설치합니다.
echo.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Resources\launch.ps1"
set "RC=%errorlevel%"
if not "%RC%"=="0" (
  echo.
  echo [오류] 실행 준비에 실패했습니다. 종료 코드: %RC%
  if exist "Resources\launcher_error.log" (
    echo.
    echo ===== Resources\launcher_error.log =====
    type "Resources\launcher_error.log"
  )
  echo.
  pause
)
exit /b %RC%
