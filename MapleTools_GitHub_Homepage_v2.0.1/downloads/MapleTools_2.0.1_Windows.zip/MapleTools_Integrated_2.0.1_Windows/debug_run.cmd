﻿@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
echo [Maple Tools 0.4.3e] 진단 실행
echo Python이 없으면 자동 설치 후 콘솔 모드로 실행합니다.
echo.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Resources\launch.ps1" -Console
set "RC=%errorlevel%"
echo.
echo 종료 코드: %RC%
if exist "Resources\launcher_error.log" (
  echo.
  echo ===== Resources\launcher_error.log =====
  type "Resources\launcher_error.log"
)
if exist "Resources\startup_error.log" (
  echo.
  echo ===== Resources\startup_error.log =====
  type "Resources\startup_error.log"
)
echo.
pause
exit /b %RC%
